package com.hezpor.mousetool

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.database.ContentObserver
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

class MouseService : Service() {

    companion object {
        const val CH = "hezpor_service"
        const val NID = 1001
        const val ACTION_STOP = "com.hezpor.mousetool.STOP"
        const val ACTION_FPS_OFF = "com.hezpor.mousetool.FPS_OFF"
        const val ACTION_MENU = "com.hezpor.mousetool.MENU"

        fun start(c: Context) {
            val i = Intent(c, MouseService::class.java)
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, MouseService::class.java))
        }

        /** Mở menu nổi ngay (khởi động dịch vụ nếu chưa chạy). */
        fun openMenu(c: Context) {
            val i = Intent(c, MouseService::class.java).setAction(ACTION_MENU)
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
        }
    }

    private val h = Handler(Looper.getMainLooper())
    private val bg = Executors.newSingleThreadExecutor()
    private var wm: WindowManager? = null
    private var hud: TextView? = null
    private var monitor: EventMonitor? = null
    private var wake: PowerManager.WakeLock? = null
    private var tickCount = 0
    private var hdMiss = 0
    private var overlays: OverlayManager? = null
    private var menu: FloatingMenu? = null
    private val fpsExec = Executors.newSingleThreadScheduledExecutor()
    private var vsyncOn = false
    private var vFrames = 0
    private var vStart = 0L

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!vsyncOn) return
            vFrames++
            if (vStart == 0L) vStart = frameTimeNanos
            val el = frameTimeNanos - vStart
            if (el >= 1_000_000_000L) {
                LiveState.vsyncFps = Math.round(vFrames * 1e9 / el).toInt()
                vFrames = 0
                vStart = frameTimeNanos
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private val fpsTick = object : Runnable {
        override fun run() {
            overlays?.updateFps()
            val fake = Prefs.getBool(this@MouseService, K.FPS_FAKE, false)
            val d = if (fake) Prefs.getFloat(this@MouseService, K.FPS_SPEED, 500f).toLong().coerceAtLeast(50L) else 500L
            h.postDelayed(this, d)
        }
    }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        h.post { refresh() }
    }
    private val binderListener = Shizuku.OnBinderReceivedListener { h.post { refresh() } }
    private val speedObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            bg.execute { enforceSpeed() }
        }
    }
    private val tick = object : Runnable {
        override fun run() {
            tickCount++
            val fresh = System.currentTimeMillis() - LiveState.sysHzTime < 1500
            hud?.text = if (fresh) "${LiveState.sysHz} Hz" else "-- Hz"
            if (tickCount % 6 == 0) {
                bg.execute { enforceSpeed() }
                refresh()
                updateNotification()
            }
            h.postDelayed(this, 500)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        LiveState.serviceRunning = true
        createChannel()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        overlays = OverlayManager(this, wm!!)
        menu = FloatingMenu(this, wm!!)
        fpsExec.scheduleWithFixedDelay({ sampleFps() }, 1, 1, TimeUnit.SECONDS)
        fpsExec.scheduleWithFixedDelay({ hdWatch() }, 3, 2, TimeUnit.SECONDS)
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefListener)
        try { Shizuku.addBinderReceivedListenerSticky(binderListener) } catch (e: Throwable) { }
        try {
            contentResolver.registerContentObserver(
                Settings.System.getUriFor("pointer_speed"), false, speedObserver
            )
        } catch (e: Throwable) { }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Prefs.setBool(this, K.SERVICE_ON, false)
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_FPS_OFF) {
            Prefs.setBool(this, K.FPS_ON, false)
            refresh()
            return START_STICKY
        }
        val n = buildNotification("Đang chạy nền")
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NID, n)
            }
        } catch (e: Throwable) {
            try { startForeground(NID, n) } catch (e2: Throwable) { }
        }
        Prefs.setBool(this, K.SERVICE_ON, true)
        h.removeCallbacks(tick)
        h.post(tick)
        h.removeCallbacks(fpsTick)
        h.post(fpsTick)
        refresh()
        bg.execute { enforceSpeed() }
        if (intent?.action == ACTION_MENU) h.post { menu?.openPanel() }
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        menu?.onConfigChanged()
    }

    override fun onDestroy() {
        LiveState.serviceRunning = false
        h.removeCallbacks(tick)
        try { Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefListener) } catch (e: Throwable) { }
        try { Shizuku.removeBinderReceivedListener(binderListener) } catch (e: Throwable) { }
        try { contentResolver.unregisterContentObserver(speedObserver) } catch (e: Throwable) { }
        monitor?.stop()
        monitor = null
        hideHud()
        h.removeCallbacks(fpsTick)
        vsyncOn = false
        fpsExec.shutdownNow()
        overlays?.destroy()
        menu?.destroy()
        menu = null
        try { wake?.let { if (it.isHeld) it.release() } } catch (e: Throwable) { }
        bg.shutdown()
        super.onDestroy()
    }

    // ---------- logic ----------

    private fun refresh() {
        // WakeLock
        try {
            if (Prefs.getBool(this, K.WAKE_ON, true)) {
                if (wake == null) {
                    val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                    wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "hezpor:svc").apply {
                        setReferenceCounted(false)
                    }
                }
                if (wake?.isHeld == false) wake?.acquire()
            } else {
                wake?.let { if (it.isHeld) it.release() }
            }
        } catch (e: Throwable) { }

        // FPS + văn bản nổi
        overlays?.syncFps()
        overlays?.syncTexts()
        menu?.sync()
        val needV = Prefs.getBool(this, K.FPS_ON, false) && !Prefs.getBool(this, K.FPS_FAKE, false)
        if (needV && !vsyncOn) {
            vsyncOn = true; vFrames = 0; vStart = 0L
            Choreographer.getInstance().removeFrameCallback(frameCb)
            Choreographer.getInstance().postFrameCallback(frameCb)
        } else if (!needV && vsyncOn) {
            vsyncOn = false
        }

        // HUD
        val hudOn = Prefs.getBool(this, K.HUD_ON, false)
        if (hudOn) showHud() else hideHud()

        // Đo Hz hệ thống
        val needMonitor = (Prefs.getBool(this, K.SYS_HZ_ON, false) || hudOn) && ShizukuHelper.granted()
        if (needMonitor) {
            if (monitor == null) {
                monitor = EventMonitor { hz, dev ->
                    LiveState.sysHz = hz
                    LiveState.sysDev = dev
                    LiveState.sysHzTime = System.currentTimeMillis()
                }
            }
            monitor?.start()
        } else {
            monitor?.stop()
            monitor = null
        }
    }

    /** FPS thật của app đang mở: đọc SurfaceFlinger --latency qua Shizuku. */
    private fun sampleFps() {
        try {
            if (!Prefs.getBool(this, K.FPS_ON, false) || Prefs.getBool(this, K.FPS_FAKE, false)) return
            if (!ShizukuHelper.granted()) { LiveState.realFps = 0; return }
            val script = """
P=@(dumpsys window | grep -m1 mCurrentFocus | grep -o -E '[A-Za-z0-9_.]+/[A-Za-z0-9_.@]+' | head -1 | cut -d/ -f1)
[ -z "@P" ] && P=@(dumpsys window | grep -m1 mFocusedApp | grep -o -E '[A-Za-z0-9_.]+/[A-Za-z0-9_.@]+' | head -1 | cut -d/ -f1)
[ -z "@P" ] && exit 0
L=@(dumpsys SurfaceFlinger --list | grep -F "@P" | grep -i SurfaceView | head -1)
[ -z "@L" ] && L=@(dumpsys SurfaceFlinger --list | grep -F "@P" | head -1)
[ -z "@L" ] && exit 0
dumpsys SurfaceFlinger --latency "@L"
""".replace('@', '$')
            val out = ShizukuHelper.exec(script, 6) ?: return
            LiveState.realFps = parseFps(out)
        } catch (e: Throwable) { }
    }

    private fun parseFps(out: String): Int {
        val ts = ArrayList<Long>()
        for (line in out.lines()) {
            val t = line.trim().split(Regex("\\s+"))
            if (t.size == 3 && t.all { it.toLongOrNull() != null }) {
                val v = t[1].toLong()
                if (v > 0L && v < Long.MAX_VALUE / 2) ts.add(v)
            }
        }
        if (ts.size < 3) return 0
        ts.sort()
        val mx = ts.last()
        var w = ts.filter { it > mx - 1_000_000_000L }
        if (w.size < 3) w = ts
        val span = w.last() - w.first()
        if (span <= 0L) return 0
        return Math.round((w.size - 1) * 1e9 / span).toInt().coerceIn(0, 1000)
    }

    /** Khi game HD đóng (không còn ở foreground) thì khôi phục phân giải/màu. */
    private fun hdWatch() {
        try {
            if (!Prefs.getBool(this, K.HD_ACTIVE, false)) { hdMiss = 0; return }
            if (!ShizukuHelper.granted()) return
            val pkg = Prefs.sp(this).getString(K.HD_PKG, "") ?: ""
            if (pkg.isEmpty()) return
            val start = Prefs.sp(this).getLong(K.HD_START, 0L)
            if (System.currentTimeMillis() - start < 20000L) return
            val out = ShizukuHelper.exec("dumpsys window | grep -m1 mCurrentFocus") ?: return
            if (out.contains(pkg)) {
                hdMiss = 0
            } else {
                hdMiss++
                if (hdMiss >= 5) { hdMiss = 0; DisplayCtl.restore(this) }
            }
        } catch (e: Throwable) { }
    }

    private fun enforceHz() {
        try {
            if (!Prefs.getBool(this, K.HZ_LOCK, false)) return
            val want = Prefs.getFloat(this, K.HZ_VAL, 0f).roundToInt()
            if (want > 0 && Math.round(Sys.getFloat(this, "min_refresh_rate")) != want) Sys.setRefresh(this, want)
        } catch (e: Throwable) { }
    }

    private fun enforceSpeed() {
        enforceHz()
        try {
            if (!Prefs.getBool(this, K.SPEED_LOCK, false)) return
            val want = Prefs.getFloat(this, K.SPEED_VAL, 0f).roundToInt().coerceIn(-7, 7)
            if (Sys.getPointerSpeed(this) != want) Sys.setPointerSpeed(this, want)
        } catch (e: Throwable) { }
    }

    private fun showHud() {
        if (hud != null) return
        if (!Settings.canDrawOverlays(this)) return
        val tv = TextView(this)
        tv.text = "-- Hz"
        tv.setTextColor(Th.GOLD)
        tv.textSize = 16f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setPadding(dp(12), dp(6), dp(12), dp(6))
        val bgd = GradientDrawable()
        bgd.setColor(0xCC000000.toInt())
        bgd.cornerRadius = dp(14).toFloat()
        bgd.setStroke(dp(1), Th.GOLD)
        tv.background = bgd

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(16)
        lp.y = dp(120)

        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    try { wm?.updateViewLayout(tv, lp) } catch (ex: Throwable) { }
                }
            }
            true
        }
        try {
            wm?.addView(tv, lp)
            hud = tv
        } catch (e: Throwable) { }
    }

    private fun hideHud() {
        val v = hud ?: return
        try { wm?.removeView(v) } catch (e: Throwable) { }
        hud = null
    }

    // ---------- notification ----------

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(CH, "Hezpor Mouse chạy nền", NotificationManager.IMPORTANCE_LOW)
            ch.setShowBadge(false)
            nm.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, MouseService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_stat), "Tắt", stop
        ).build()
        val fpsOff = PendingIntent.getService(
            this, 2, Intent(this, MouseService::class.java).setAction(ACTION_FPS_OFF),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val action2 = Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_stat), "Tắt FPS", fpsOff
        ).build()
        val menuPi = PendingIntent.getService(
            this, 3, Intent(this, MouseService::class.java).setAction(ACTION_MENU),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val action3 = Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_stat), "Menu", menuPi
        ).build()
        return Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Hezpor Mouse")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(action)
            .addAction(action2)
            .addAction(action3)
            .build()
    }

    private fun updateNotification() {
        try {
            val fresh = System.currentTimeMillis() - LiveState.sysHzTime < 1500
            val hz = if (fresh) "${LiveState.sysHz} Hz" else "-- Hz"
            val speed = Sys.getPointerSpeed(this)
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NID, buildNotification("Hz: $hz  |  Tốc độ chuột: $speed"))
        } catch (e: Throwable) { }
    }
}
