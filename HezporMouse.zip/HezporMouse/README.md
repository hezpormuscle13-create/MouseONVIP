# Hezpor Mouse
App Android: đo Hz chuột (trong app + toàn hệ thống qua Shizuku), chỉnh/khóa tốc độ con trỏ,
HUD Hz/FPS nổi, Optimizer, đổi độ phân giải/màu, **bóng nổi + menu nhanh trên mọi app**, video nền có âm thanh.

Giao diện chia tab: Tổng quan • Hiệu suất • Chuột • Hình ảnh • HUD • Ghi chú.

Bóng nổi: bật ở tab Tổng quan (cần quyền Lớp phủ). Chạm bóng để mở menu, kéo để di chuyển.
Menu nhanh: Hiệu suất (Tăng tốc 1 chạm, Optimizer, Hz) • Công cụ (tốc độ chuột, HUD, điểm chạm) •
Hình ảnh (phân giải, độ rực màu) • HUD FPS.

Build: đẩy lên GitHub (nhánh main) -> tab Actions -> "Build APK" -> tải ở Releases hoặc Artifacts.
