package com.hezpor.mouse

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity(), TextureView.SurfaceTextureListener {
    private var mp: MediaPlayer? = null
    private lateinit var tex: TextureView
    private var vw = 0
    private var vh = 0

    private lateinit var soundBtn: Button
    private lateinit var speedTv: TextView
    private lateinit var keepBtn: Button
    private lateinit var hzTv: TextView
    private lateinit var hzSub: TextView
    private lateinit var rawBtn: Button
    private lateinit var pad: HzPad
    private val chips = ArrayList<TextView>()
    private val fxStyleChips = ArrayList<TextView>()
    private val fxModeChips = ArrayList<TextView>()
    private var hueBar: SeekBar? = null
    private var fxPreview: View? = null
    private class Row(val title: String, val tv: TextView, val ok: () -> Boolean)
    private val rows = ArrayList<Row>()
    private var lastHz = 0
    private var lastPeak = 0
    private var lastSrc = "-"
    private var lastUi = 0L

    private val onBinder = Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }
    private val onDead = Shizuku.OnBinderDeadListener { runOnUiThread { refresh() } }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- trạng thái quyền ----------
    private fun shizukuRunning() = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
    private fun shizukuOk() = Sh.ready()
    private fun writeOk() = Settings.System.canWrite(this)
    private fun overlayOk() = Settings.canDrawOverlays(this)
    private fun notifOk() = Build.VERSION.SDK_INT < 33 ||
        checkSelfPermission("android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED
    private fun batteryOk() = getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)

    // ---------- dựng giao diện ----------
    private fun roundBg(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    private fun btn(text: String, color: Int, onClick: () -> Unit) = Button(this).apply {
        this.text = text; isAllCaps = false; setTextColor(Color.WHITE); textSize = 15f
        setTypeface(typeface, Typeface.BOLD)
        background = roundBg(color, 16)
        setOnClickListener { onClick() }
    }

    private fun label(t: String, sp: Float = 14f, bold: Boolean = false) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = sp
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun card(parent: LinearLayout, title: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundBg(0xB3101820.toInt(), 20)
            setPadding(dp(16), dp(14), dp(16), dp(16))
        }
        c.addView(label(title, 17f, true))
        parent.addView(c, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        return c
    }

    private fun addRow(box: LinearLayout, title: String, ok: () -> Boolean, action: () -> Unit) {
        val line = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val tv = label("", 14f)
        line.addView(tv, LinearLayout.LayoutParams(0, -2, 1f))
        line.addView(btn("Cấp", 0xFF1565C0.toInt(), action), LinearLayout.LayoutParams(dp(78), dp(40)))
        box.addView(line, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        rows.add(Row(title, tv, ok))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        FxCfg.load(this)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.BLACK

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        tex = TextureView(this).apply { surfaceTextureListener = this@MainActivity }
        root.addView(tex, FrameLayout.LayoutParams(-1, -1))
        tex.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> applyCrop() }
        root.addView(View(this).apply { setBackgroundColor(0x40000000) }, FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(50), dp(16), dp(30))
        }

        // tiêu đề + nút âm thanh
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(label("HEZPOR MOUSE", 26f, true).apply { setShadowLayer(8f, 0f, 2f, Color.BLACK) })
        titles.addView(label("Tối ưu chuột", 13f).apply { setShadowLayer(6f, 0f, 1f, Color.BLACK) })
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        soundBtn = btn("", 0xAA000000.toInt()) {
            Prefs.setSound(this, !Prefs.sound(this)); applyVolume(); refresh()
        }
        head.addView(soundBtn, LinearLayout.LayoutParams(dp(64), dp(44)))
        col.addView(head, LinearLayout.LayoutParams(-1, -2))

        // ===== 1. Tốc độ chuột =====
        val c1 = card(col, "Tốc độ chuột")
        speedTv = label("", 15f).apply { setPadding(0, dp(8), 0, 0) }
        c1.addView(speedTv)
        c1.addView(SeekBar(this).apply {
            max = 14; progress = Prefs.speed(this@MainActivity) + 7
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    Prefs.setSpeed(this@MainActivity, p - 7); refreshSpeedText()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { applySpeed() }
            })
        }, LinearLayout.LayoutParams(-1, -2))
        c1.addView(label("-7 chậm nhất · 0 mặc định · +7 nhanh nhất. Áp dụng cho chuột đang cắm vào máy.", 12f)
            .apply { setTextColor(0xFFB0BEC5.toInt()) })
        val r1 = LinearLayout(this)
        r1.addView(btn("Áp dụng", 0xFF1565C0.toInt()) { applySpeed() },
            LinearLayout.LayoutParams(0, dp(46), 1f).apply { rightMargin = dp(6) })
        r1.addView(btn("Về mặc định (0)", 0xFF455A64.toInt()) {
            Prefs.setSpeed(this, 0); applySpeed(); recreateSeek()
        }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { leftMargin = dp(6) })
        c1.addView(r1, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        // ===== 2. Hz chuột =====
        val c2 = card(col, "Hz chuột (đo thật)")
        hzTv = label("--- Hz", 34f, true).apply { setPadding(0, dp(6), 0, 0) }
        c2.addView(hzTv)
        hzSub = label("Di chuột hoặc chạm vào vùng thử bên dưới để đo.", 13f)
        c2.addView(hzSub)
        pad = HzPad(this).apply {
            onHz = { hz, peak, src ->
                lastHz = hz; lastPeak = peak; lastSrc = src
                val now = SystemClock.uptimeMillis()
                if (now - lastUi > 100) { lastUi = now; updateHz() }
            }
        }
        pad.setOnCapturedPointerListener { _, e -> pad.onCaptured(e) }
        c2.addView(pad, LinearLayout.LayoutParams(-1, dp(190)).apply { topMargin = dp(10) })
        val r2 = LinearLayout(this)
        rawBtn = btn("", 0xFF455A64.toInt()) { toggleRaw() }
        r2.addView(rawBtn, LinearLayout.LayoutParams(0, dp(44), 1f).apply { rightMargin = dp(6) })
        r2.addView(btn("Đo lại", 0xFF455A64.toInt()) {
            pad.resetPeak(); pad.clearTrail(); lastHz = 0; lastPeak = 0; updateHz()
        }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(6) })
        c2.addView(r2, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        c2.addView(label("Hz mục tiêu để so sánh", 14f, true).apply { setPadding(0, dp(14), 0, dp(6)) })
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val hzList = listOf(100, 200, 300, 400, 500, 600, 700, 800, 900, 1000)
        for (rowIdx in 0 until 2) {
            val line = LinearLayout(this)
            for (k in 0 until 5) {
                val hz = hzList[rowIdx * 5 + k]
                val chip = TextView(this).apply {
                    text = "$hz"; gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 14f
                    setOnClickListener { Prefs.setTarget(this@MainActivity, hz); refresh(); updateHz() }
                    tag = hz
                }
                chips.add(chip)
                line.addView(chip, LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            grid.addView(line, LinearLayout.LayoutParams(-1, -2))
        }
        c2.addView(grid)
        c2.addView(label("Lưu ý: app không đổi được Hz phần cứng của chuột. Hz do chính con chuột và hệ thống quyết định; app chỉ đo để bạn so sánh với mục tiêu.", 12f)
            .apply { setTextColor(0xFFB0BEC5.toInt()); setPadding(0, dp(8), 0, 0) })

        // ===== Hiệu ứng chuột neon =====
        val c4 = card(col, "Hiệu ứng chuột (neon)")
        c4.addView(label("Kiểu hiệu ứng khi di chuột", 13f).apply { setPadding(0, dp(8), 0, dp(2)) })
        fxStyleChips.addAll(chipRow(c4, listOf("Vệt neon", "Đuôi sao", "Tia lửa", "Gợn sóng")) { FxCfg.style = it; fxChanged() })
        c4.addView(label("Màu", 13f).apply { setPadding(0, dp(10), 0, dp(2)) })
        fxModeChips.addAll(chipRow(c4, listOf("Bảy màu", "Đủ màu", "Đủ phổ chạy")) { FxCfg.mode = it; fxChanged() })

        // 7 màu neon bấm chọn nhanh
        val sw = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        for (colr in FxCfg.NEON7) {
            val v = View(this)
            v.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(colr); setStroke(dp(1), 0xAAFFFFFF.toInt()) }
            v.setOnClickListener {
                val hsv = FloatArray(3); Color.colorToHSV(colr, hsv)
                FxCfg.mode = 1; FxCfg.hue = hsv[0].toInt(); hueBar?.progress = FxCfg.hue; fxChanged()
            }
            sw.addView(v, LinearLayout.LayoutParams(0, dp(34), 1f).apply { setMargins(dp(3), dp(6), dp(3), dp(2)) })
        }
        c4.addView(sw, LinearLayout.LayoutParams(-1, -2))

        // thanh chọn màu tự do (đủ màu)
        val prev = View(this)
        fxPreview = prev
        val hueRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        hueRow.addView(label("Chọn màu tự do (kéo thanh)", 13f), LinearLayout.LayoutParams(0, -2, 1f))
        hueRow.addView(prev, LinearLayout.LayoutParams(dp(28), dp(28)))
        c4.addView(hueRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        val strip = View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                IntArray(13) { FxCfg.hueColor(it * 30) }).apply { cornerRadius = dp(5).toFloat() }
        }
        c4.addView(strip, LinearLayout.LayoutParams(-1, dp(10)).apply { topMargin = dp(6) })
        hueBar = SeekBar(this).apply {
            max = 360; progress = FxCfg.hue
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    if (u) { FxCfg.mode = 1; FxCfg.hue = p; fxChanged() }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        c4.addView(hueBar, LinearLayout.LayoutParams(-1, -2))

        fxSlider(c4, "Độ dài vệt", 20, 300, { FxCfg.len }, { FxCfg.len = it })
        fxSlider(c4, "Độ dày", 2, 30, { FxCfg.width }, { FxCfg.width = it })
        fxSlider(c4, "Ổn định / mượt (cao = mượt hơn)", 0, 100, { FxCfg.smooth }, { FxCfg.smooth = it })

        c4.addView(btn("Thử hiệu ứng toàn màn hình", 0xFF6A1B9A.toInt()) {
            startActivity(Intent(this, FxActivity::class.java))
        }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(12) })
        c4.addView(label("Hiệu ứng, con trỏ neon và độ ổn định hoạt động trong vùng thử và màn hình hiệu ứng của app. " +
            "Android không cho app vẽ hiệu ứng đè lên app/game khác khi không có root.", 12f)
            .apply { setTextColor(0xFFB0BEC5.toInt()); setPadding(0, dp(8), 0, 0) })

        // ===== 3. Tối ưu + quyền =====
        val c3 = card(col, "Tối ưu & quyền nâng cao")
        c3.addView(btn("TỐI ƯU NGAY", 0xFF2E7D32.toInt()) { optimizeNow() },
            LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) })
        c3.addView(label("Cấp quyền bằng Shizuku + áp tốc độ chuột + bật chạy nền.", 12f)
            .apply { setTextColor(0xFFB0BEC5.toInt()); setPadding(0, dp(4), 0, dp(4)) })
        addRow(c3, "Shizuku", ::shizukuOk) { onClickShizuku() }
        addRow(c3, "Sửa cài đặt hệ thống", ::writeOk) {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        }
        addRow(c3, "Hiển thị trên ứng dụng khác", ::overlayOk) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        addRow(c3, "Thông báo", ::notifOk) {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }
        addRow(c3, "Không tối ưu pin", ::batteryOk) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (_: Throwable) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        }
        c3.addView(btn("Tự cấp các quyền còn lại bằng Shizuku", 0xFF1565C0.toInt()) { autoGrant() },
            LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(10) })
        keepBtn = btn("", 0xFF455A64.toInt()) { toggleKeep() }
        c3.addView(keepBtn, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(8) })
        c3.addView(label(
            "Để thoát app vẫn chạy: Samsung → Cài đặt → Pin → Giới hạn dùng nền → Ứng dụng không bao giờ ngủ. " +
                "Xiaomi/Redmi → bật Tự khởi động và đặt Tiết kiệm pin = Không hạn chế. Hai mục này app không tự bật được.", 12f)
            .apply { setTextColor(0xFFB0BEC5.toInt()); setPadding(0, dp(10), 0, 0) })

        // ===== Tắt app =====
        col.addView(btn("Tắt app", 0xFFD32F2F.toInt()) {
            Prefs.setKeep(this, false)
            stopService(Intent(this, KeepService::class.java))
            finishAndRemoveTask()
        }, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(18) })

        root.addView(ScrollView(this).apply { addView(col) }, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPerm)
        refresh(); refreshSpeedText(); updateHz()
    }

    // ---------- hiệu ứng neon ----------
    private fun chipRow(parent: LinearLayout, labels: List<String>, onClick: (Int) -> Unit): List<TextView> {
        val line = LinearLayout(this)
        val out = ArrayList<TextView>()
        labels.forEachIndexed { i, text ->
            val t = TextView(this).apply {
                this.text = text; gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 13f
                setOnClickListener { onClick(i) }
            }
            out.add(t)
            line.addView(t, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
        }
        parent.addView(line, LinearLayout.LayoutParams(-1, -2))
        return out
    }

    private fun fxSlider(parent: LinearLayout, title: String, min: Int, max: Int, get: () -> Int, set: (Int) -> Unit) {
        val tv = label("", 13f).apply { setPadding(0, dp(10), 0, 0) }
        fun upd() { tv.text = "$title: ${get()}" }
        upd(); parent.addView(tv)
        val sb = SeekBar(this)
        sb.max = max - min; sb.progress = get() - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                set(p + min); upd(); if (u) fxChanged()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(sb, LinearLayout.LayoutParams(-1, -2))
    }

    private fun fxChanged() { FxCfg.save(this); refreshFx() }

    private fun refreshFx() {
        for ((i, c) in fxStyleChips.withIndex()) c.background = roundBg(if (FxCfg.style == i) 0xFF6A1B9A.toInt() else 0x66455A64, 12)
        for ((i, c) in fxModeChips.withIndex()) c.background = roundBg(if (FxCfg.mode == i) 0xFF6A1B9A.toInt() else 0x66455A64, 12)
        fxPreview?.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            if (FxCfg.mode == 1) setColor(FxCfg.hueColor(FxCfg.hue))
            else { colors = if (FxCfg.mode == 0) FxCfg.NEON7 else IntArray(7) { FxCfg.hueColor(it * 60) }; orientation = GradientDrawable.Orientation.LEFT_RIGHT }
            setStroke(dp(1), 0xAAFFFFFF.toInt())
        }
        pad.applyPointerIcon()
    }

    // ---------- tốc độ chuột ----------
    private fun refreshSpeedText() {
        val v = Prefs.speed(this)
        speedTv.text = "Tốc độ: " + (if (v > 0) "+$v" else "$v") + "   (hệ thống đang đặt: ${Mouse.current(this)})"
    }

    private fun recreateSeek() { recreate() }

    private fun applySpeed() {
        val v = Prefs.speed(this)
        Thread {
            val ok = Mouse.apply(this, v)
            runOnUiThread {
                refreshSpeedText()
                toast(if (ok) "Đã áp tốc độ chuột" else "Chưa áp được: cần Shizuku hoặc quyền Sửa cài đặt hệ thống")
            }
        }.start()
    }

    // ---------- đo Hz ----------
    private fun updateHz() {
        hzTv.text = if (lastHz > 0) "$lastHz Hz" else "--- Hz"
        val t = Prefs.target(this)
        hzSub.text = if (lastHz > 0)
            "Nguồn: $lastSrc · đỉnh $lastPeak Hz · so với mục tiêu $t Hz: ${(lastHz * 100L / t).coerceAtMost(999)}%"
        else "Di chuột hoặc chạm vào vùng thử bên dưới để đo. Mục tiêu: $t Hz"
    }

    private fun toggleRaw() {
        if (pad.hasPointerCapture()) pad.releasePointerCapture()
        else { pad.requestFocus(); pad.requestPointerCapture() }
        rawBtn.postDelayed({ refresh() }, 150)
    }

    override fun onPointerCaptureChanged(hasCapture: Boolean) {
        super.onPointerCaptureChanged(hasCapture); refresh()
    }

    // ---------- Shizuku / quyền ----------
    private fun onClickShizuku() {
        if (!shizukuRunning()) {
            toast("Shizuku chưa chạy, hãy mở và bấm Start")
            packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { startActivity(it) }
            return
        }
        if (shizukuOk()) { toast("Đã được cấp quyền rồi"); return }
        try {
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                toast("Bạn đã chọn từ chối. Mở Shizuku, vào danh sách ứng dụng và bật cho app này")
                packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { startActivity(it) }
            } else Shizuku.requestPermission(100)
        } catch (_: Throwable) { toast("Không xin được quyền, thử lại sau") }
    }

    private fun grantCommands() {
        val p = packageName
        Sh.run("appops set $p SYSTEM_ALERT_WINDOW allow")
        Sh.run("appops set $p WRITE_SETTINGS allow")
        Sh.run("appops set $p RUN_ANY_IN_BACKGROUND allow")
        Sh.run("appops set $p RUN_IN_BACKGROUND allow")
        Sh.run("dumpsys deviceidle whitelist +$p")
        Sh.run("pm grant $p android.permission.POST_NOTIFICATIONS")
    }

    private fun autoGrant() {
        if (!shizukuOk()) { toast("Cần cấp quyền Shizuku trước"); return }
        Thread {
            grantCommands()
            runOnUiThread { refresh(); toast("Đã cấp quyền") }
        }.start()
    }

    private fun optimizeNow() {
        if (!shizukuOk()) {
            toast("Cần bật Shizuku và cấp quyền trước")
            onClickShizuku(); return
        }
        Thread {
            grantCommands()
            Mouse.apply(this, Prefs.speed(this))
            Prefs.setKeep(this, true)
            runOnUiThread {
                startForegroundService(Intent(this, KeepService::class.java))
                refresh(); refreshSpeedText(); toast("Đã tối ưu và bật chạy nền")
            }
        }.start()
    }

    private fun toggleKeep() {
        val i = Intent(this, KeepService::class.java)
        if (Prefs.keep(this) || KeepService.running) {
            Prefs.setKeep(this, false); stopService(i)
        } else {
            Prefs.setKeep(this, true)
            if (Build.VERSION.SDK_INT >= 33 && !notifOk())
                requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
            startForegroundService(i)
        }
        keepBtn.postDelayed({ refresh() }, 300)
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r); refresh()
    }

    private fun refresh() {
        for (r in rows) r.tv.text = (if (r.ok()) "✓ " else "✗ ") + r.title
        keepBtn.text = if (KeepService.running) "Chạy nền (giữ tốc độ): BẬT" else "Chạy nền (giữ tốc độ): TẮT"
        (keepBtn.background as GradientDrawable).setColor(if (KeepService.running) 0xFFEF6C00.toInt() else 0xFF455A64.toInt())
        soundBtn.text = if (Prefs.sound(this)) "🔊" else "🔇"
        rawBtn.text = if (pad.hasPointerCapture()) "Con trỏ thô: BẬT" else "Con trỏ thô: TẮT"
        val t = Prefs.target(this)
        for (c in chips) c.background = roundBg(if (c.tag == t) 0xFF1565C0.toInt() else 0x66455A64, 12)
        refreshFx()
    }

    // ---------- video nền (có âm thanh) ----------
    private fun applyVolume() { val v = if (Prefs.sound(this)) 1f else 0f; try { mp?.setVolume(v, v) } catch (_: Throwable) {} }

    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
        try {
            val p = MediaPlayer()
            val afd = resources.openRawResourceFd(R.raw.bg)
            p.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            p.setSurface(Surface(st))
            p.isLooping = true
            p.setOnVideoSizeChangedListener { _, a, b -> vw = a; vh = b; applyCrop() }
            p.setOnPreparedListener { applyVolume(); it.start() }
            p.prepareAsync()
            mp = p
        } catch (_: Throwable) {}
    }

    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) { applyCrop() }
    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
        try { mp?.release() } catch (_: Throwable) {}
        mp = null
        return true
    }
    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}

    /** Phủ kín màn hình (cắt bớt hai bên hoặc trên dưới). */
    private fun applyCrop() {
        val w = tex.width.toFloat(); val h = tex.height.toFloat()
        if (vw == 0 || vh == 0 || w == 0f || h == 0f) return
        val vr = vw.toFloat() / vh; val sr = w / h
        var sx = 1f; var sy = 1f
        if (vr > sr) sx = vr / sr else sy = sr / vr
        val m = Matrix(); m.setScale(sx, sy, w / 2, h / 2)
        tex.setTransform(m)
    }

    override fun onResume() {
        super.onResume()
        try { mp?.start() } catch (_: Throwable) {}
        applyVolume(); refresh(); refreshSpeedText()
    }

    override fun onPause() {
        // thoát ra thì dừng tiếng/video, dịch vụ chạy nền vẫn giữ tốc độ chuột
        try { mp?.pause() } catch (_: Throwable) {}
        super.onPause()
    }

    override fun onDestroy() {
        try { mp?.release() } catch (_: Throwable) {}
        mp = null
        Shizuku.removeBinderReceivedListener(onBinder)
        Shizuku.removeBinderDeadListener(onDead)
        Shizuku.removeRequestPermissionResultListener(onPerm)
        super.onDestroy()
    }
}
