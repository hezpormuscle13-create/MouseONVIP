package com.hezpor.mouse

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.PointerIcon
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/** Cài đặt hiệu ứng chuột. */
object FxCfg {
    var style = 0     // 0 vệt neon, 1 đuôi sao, 2 tia lửa, 3 gợn sóng
    var mode = 0      // 0 bảy màu, 1 một màu (chọn tự do), 2 đủ phổ chạy
    var hue = 190     // 0..360 (dùng khi mode = 1)
    var len = 120     // 20..300  -> độ dài vệt
    var width = 8     // 2..30    -> độ dày (dp)
    var smooth = 40   // 0..100   -> độ ổn định / mượt

    val NEON7 = intArrayOf(
        0xFFFF0040.toInt(), // đỏ neon
        0xFFFF8A00.toInt(), // cam neon
        0xFFFFEA00.toInt(), // vàng neon
        0xFF39FF14.toInt(), // xanh lá neon
        0xFF00F0FF.toInt(), // lam neon
        0xFF1F51FF.toInt(), // xanh dương neon
        0xFFBF00FF.toInt()  // tím neon
    )

    fun load(c: Context) {
        val p = c.getSharedPreferences("hezpor", 0)
        style = p.getInt("fxStyle", 0); mode = p.getInt("fxMode", 0); hue = p.getInt("fxHue", 190)
        len = p.getInt("fxLen", 120); width = p.getInt("fxWidth", 8); smooth = p.getInt("fxSmooth", 40)
    }

    fun save(c: Context) {
        c.getSharedPreferences("hezpor", 0).edit()
            .putInt("fxStyle", style).putInt("fxMode", mode).putInt("fxHue", hue)
            .putInt("fxLen", len).putInt("fxWidth", width).putInt("fxSmooth", smooth).apply()
    }

    fun hueColor(h: Int): Int = Color.HSVToColor(floatArrayOf(h.toFloat(), 1f, 1f))

    fun seven(p: Float): Int {
        val n = NEON7.size
        val v = p * n
        val i = v.toInt() % n
        val j = (i + 1) % n
        val k = v - v.toInt()
        val a = NEON7[i]; val b = NEON7[j]
        fun ch(s: Int) = (((a shr s) and 255) + ((((b shr s) and 255) - ((a shr s) and 255)) * k)).toInt()
        return Color.rgb(ch(16), ch(8), ch(0))
    }

    /** Màu hiệu ứng tại thời điểm t (ms). */
    fun colorAt(t: Long): Int = when (mode) {
        1 -> hueColor(hue)
        2 -> hueColor(((t / 9) % 360).toInt())
        else -> seven((t % 3500) / 3500f)
    }

    /** Con trỏ chuột neon (dùng làm PointerIcon trong app). */
    fun cursorIcon(): PointerIcon {
        val col = if (mode == 1) hueColor(hue) else NEON7[4]
        val s = 72
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        val cx = s / 2f
        for ((w, a) in listOf(12f to 50, 8f to 110, 4f to 255)) {
            p.strokeWidth = w; p.color = (col and 0x00FFFFFF) or (a shl 24)
            c.drawCircle(cx, cx, 20f, p)
        }
        p.style = Paint.Style.FILL; p.color = Color.WHITE
        c.drawCircle(cx, cx, 4f, p)
        return PointerIcon.create(bmp, cx, cx)
    }
}

/** Vẽ hiệu ứng đường đi neon theo con trỏ. */
class FxRenderer(c: Context) {
    private class P(val x: Float, val y: Float, val t: Long, val color: Int)
    private class Part(var x: Float, var y: Float, var vx: Float, var vy: Float, val t: Long, val life: Long, val color: Int)
    private class Rip(val x: Float, val y: Float, val t: Long, val color: Int)

    private val d = c.resources.displayMetrics.density
    private val pts = ArrayList<P>()
    private val parts = ArrayList<Part>()
    private val rips = ArrayList<Rip>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val rnd = java.util.Random()

    private var sx = 0f; private var sy = 0f
    private var tx = 0f; private var ty = 0f
    private var has = false
    private var lastAdd = 0L
    private var lastRx = -9999f; private var lastRy = -9999f
    private var lastDraw = 0L

    private val GM = floatArrayOf(3.2f, 2.0f, 1.2f)
    private val GA = floatArrayOf(0.10f, 0.22f, 0.50f)

    fun reset() { pts.clear(); parts.clear(); rips.clear(); has = false }

    private fun alpha(col: Int, a: Int) = (col and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)
    private fun mixWhite(col: Int, k: Float): Int {
        fun ch(s: Int) = (((col shr s) and 255) + (255 - ((col shr s) and 255)) * k).toInt()
        return Color.rgb(ch(16), ch(8), ch(0))
    }

    /** Thêm điểm mới (có làm mượt/ổn định theo độ ổn định đã chọn). */
    fun add(x: Float, y: Float, t: Long) {
        tx = x; ty = y; lastAdd = t
        if (!has) { sx = x; sy = y; has = true }
        else {
            val a = (1f - 0.93f * FxCfg.smooth / 100f).coerceIn(0.05f, 1f)
            sx += (x - sx) * a; sy += (y - sy) * a
        }
        push(t)
    }

    private fun push(t: Long) {
        val l = pts.lastOrNull()
        if (l != null && hypot(sx - l.x, sy - l.y) < 0.8f * d) return
        val col = FxCfg.colorAt(t)
        pts.add(P(sx, sy, t, col))
        if (pts.size > 800) pts.removeAt(0)
        when (FxCfg.style) {
            2 -> {
                repeat(2) {
                    val ang = rnd.nextFloat() * 6.2832f
                    val sp = (40f + rnd.nextFloat() * 140f) * d
                    parts.add(Part(sx, sy, cos(ang) * sp, sin(ang) * sp, t, 500L + rnd.nextInt(500), col))
                }
                while (parts.size > 500) parts.removeAt(0)
            }
            3 -> if (hypot(sx - lastRx, sy - lastRy) > 26f * d) {
                rips.add(Rip(sx, sy, t, col)); lastRx = sx; lastRy = sy
                while (rips.size > 40) rips.removeAt(0)
            }
        }
    }

    /** Trả về true nếu còn hiệu ứng đang chạy (để tiếp tục vẽ). */
    fun draw(c: Canvas, now: Long): Boolean {
        // khi dừng tay, đầu vệt trượt nốt về đúng vị trí cuối
        if (has && now - lastAdd > 16 && now - lastAdd < 1500 && (abs(tx - sx) > 0.5f || abs(ty - sy) > 0.5f)) {
            sx += (tx - sx) * 0.3f; sy += (ty - sy) * 0.3f; push(now)
        }
        val life = FxCfg.len * 10L
        while (pts.isNotEmpty() && now - pts[0].t > life) pts.removeAt(0)
        val wBase = FxCfg.width * d

        when (FxCfg.style) {
            0 -> drawLines(c, now, life, wBase)
            1 -> drawComet(c, now, life, wBase)
            2 -> drawSparks(c, now, wBase)
            3 -> drawRipples(c, now, wBase)
        }

        val near = has && now - lastAdd < 1500
        if (near) {
            val col = FxCfg.colorAt(now)
            paint.style = Paint.Style.STROKE
            for (k in 0..2) {
                paint.strokeWidth = (10f - k * 3f) * d * 0.5f + 1f
                paint.color = alpha(col, intArrayOf(50, 110, 255)[k])
                c.drawCircle(sx, sy, 9f * d - k * d, paint)
            }
        }
        lastDraw = now
        return pts.isNotEmpty() || parts.isNotEmpty() || rips.isNotEmpty() || near
    }

    private fun drawLines(c: Canvas, now: Long, life: Long, wBase: Float) {
        paint.style = Paint.Style.STROKE
        for (i in 1 until pts.size) {
            val a = pts[i - 1]; val b = pts[i]
            if (b.t - a.t > 120) continue // không nối hai nét tách rời
            val f = 1f - (now - b.t).toFloat() / life
            if (f <= 0f) continue
            val w = wBase * (0.2f + 0.8f * f)
            for (k in 0..2) {
                paint.strokeWidth = w * GM[k]
                paint.color = alpha(b.color, (255 * GA[k] * f).toInt())
                c.drawLine(a.x, a.y, b.x, b.y, paint)
            }
            paint.strokeWidth = w * 0.4f
            paint.color = alpha(mixWhite(b.color, 0.7f), (255 * f).toInt())
            c.drawLine(a.x, a.y, b.x, b.y, paint)
        }
    }

    private fun drawComet(c: Canvas, now: Long, life: Long, wBase: Float) {
        paint.style = Paint.Style.FILL
        for (p in pts) {
            val f = 1f - (now - p.t).toFloat() / life
            if (f <= 0f) continue
            val r = wBase * (0.15f + 1.0f * f)
            paint.color = alpha(p.color, (255 * 0.10f * f).toInt()); c.drawCircle(p.x, p.y, r * 2.6f, paint)
            paint.color = alpha(p.color, (255 * 0.25f * f).toInt()); c.drawCircle(p.x, p.y, r * 1.7f, paint)
            paint.color = alpha(p.color, (255 * 0.8f * f).toInt()); c.drawCircle(p.x, p.y, r, paint)
            paint.color = alpha(mixWhite(p.color, 0.8f), (255 * f).toInt()); c.drawCircle(p.x, p.y, r * 0.45f, paint)
        }
    }

    private fun drawSparks(c: Canvas, now: Long, wBase: Float) {
        val dt = ((now - lastDraw) / 1000f).coerceIn(0f, 0.05f)
        paint.style = Paint.Style.FILL
        for (i in parts.indices.reversed()) {
            val p = parts[i]
            val age = (now - p.t).toFloat() / p.life
            if (age >= 1f) { parts.removeAt(i); continue }
            p.x += p.vx * dt; p.y += p.vy * dt
            p.vx *= 0.97f; p.vy *= 0.97f
            val r = (wBase * 0.35f) * (1f - age) + 0.8f * d
            val f = 1f - age
            paint.color = alpha(p.color, (255 * 0.15f * f).toInt()); c.drawCircle(p.x, p.y, r * 2.6f, paint)
            paint.color = alpha(p.color, (255 * 0.9f * f).toInt()); c.drawCircle(p.x, p.y, r, paint)
            paint.color = alpha(mixWhite(p.color, 0.8f), (255 * f).toInt()); c.drawCircle(p.x, p.y, r * 0.4f, paint)
        }
    }

    private fun drawRipples(c: Canvas, now: Long, wBase: Float) {
        paint.style = Paint.Style.STROKE
        for (i in rips.indices.reversed()) {
            val r = rips[i]
            val age = (now - r.t) / 700f
            if (age >= 1f) { rips.removeAt(i); continue }
            val f = 1f - age
            val rad = wBase * 0.6f + age * wBase * 7f
            paint.strokeWidth = (3f * d) * f + 1f
            paint.color = alpha(r.color, (255 * 0.18f * f).toInt()); paint.strokeWidth *= 3f; c.drawCircle(r.x, r.y, rad, paint)
            paint.strokeWidth = (3f * d) * f + 1f
            paint.color = alpha(r.color, (255 * f).toInt()); c.drawCircle(r.x, r.y, rad, paint)
        }
    }
}
