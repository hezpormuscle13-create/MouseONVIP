package com.hezpor.mouse

import android.content.Context

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("hezpor", 0)
    fun speed(c: Context) = p(c).getInt("speed", 0)            // -7..7
    fun setSpeed(c: Context, v: Int) = p(c).edit().putInt("speed", v).apply()
    fun keep(c: Context) = p(c).getBoolean("keep", false)
    fun setKeep(c: Context, v: Boolean) = p(c).edit().putBoolean("keep", v).apply()
    fun target(c: Context) = p(c).getInt("target", 1000)       // Hz mục tiêu để so sánh
    fun setTarget(c: Context, v: Int) = p(c).edit().putInt("target", v).apply()
    fun sound(c: Context) = p(c).getBoolean("sound", true)
    fun setSound(c: Context, v: Boolean) = p(c).edit().putBoolean("sound", v).apply()
}
