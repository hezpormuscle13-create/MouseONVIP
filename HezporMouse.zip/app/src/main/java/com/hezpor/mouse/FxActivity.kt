package com.hezpor.mouse

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.view.Gravity
import android.view.InputDevice
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

/** Màn hình đầy đủ để xem hiệu ứng chuột neon. Bấm Back để thoát. */
class FxActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        FxCfg.load(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        val root = FrameLayout(this)
        root.addView(FxFullView(this), FrameLayout.LayoutParams(-1, -1))
        root.addView(TextView(this).apply {
            text = "Di chuột hoặc chạm để xem hiệu ứng · bấm Back để thoát"
            setTextColor(0x88FFFFFF.toInt()); textSize = 12f; gravity = Gravity.CENTER
            setPadding(0, 0, 0, (24 * resources.displayMetrics.density).toInt())
        }, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)
    }
}

class FxFullView(c: Context) : View(c) {
    private val fx = FxRenderer(c)

    init { setBackgroundColor(Color.BLACK) }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        try { pointerIcon = FxCfg.cursorIcon() } catch (_: Throwable) {}
        if (Build.VERSION.SDK_INT >= 31) requestUnbufferedDispatch(InputDevice.SOURCE_CLASS_POINTER)
    }

    private fun addPoints(e: MotionEvent) {
        for (i in 0 until e.historySize)
            fx.add(e.getHistoricalX(i), e.getHistoricalY(i), e.getHistoricalEventTime(i))
        fx.add(e.x, e.y, e.eventTime)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN && Build.VERSION.SDK_INT < 31) requestUnbufferedDispatch(e)
        addPoints(e); invalidate(); return true
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if ((e.source and InputDevice.SOURCE_CLASS_POINTER) == 0) return super.onGenericMotionEvent(e)
        addPoints(e); invalidate(); return true
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(0xFF05070B.toInt())
        if (fx.draw(c, SystemClock.uptimeMillis())) postInvalidateOnAnimation()
    }
}
