package com.hezpor.mouse

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder

/** Dịch vụ nền: cứ vài giây kiểm tra, nếu hệ thống đổi tốc độ chuột thì đặt lại đúng giá trị bạn chọn. */
class KeepService : Service() {
    companion object { @Volatile var running = false }

    private var thread: HandlerThread? = null
    private var h: Handler? = null
    private val tick = object : Runnable {
        override fun run() {
            try {
                val want = Prefs.speed(this@KeepService)
                if (Mouse.current(this@KeepService) != want) Mouse.apply(this@KeepService, want)
            } catch (_: Throwable) {}
            h?.postDelayed(this, 4000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("keep", "Chạy nền", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "keep")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("Hezpor Mouse đang chạy nền")
            .setContentText("Giữ tốc độ chuột đã chọn")
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        running = true
        val t = HandlerThread("keep").also { it.start() }
        thread = t; h = Handler(t.looper)
        h?.post(tick)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onDestroy() {
        running = false
        h?.removeCallbacksAndMessages(null)
        thread?.quitSafely()
        super.onDestroy()
    }
}
