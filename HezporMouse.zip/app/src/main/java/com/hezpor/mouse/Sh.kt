package com.hezpor.mouse

import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings
import rikka.shizuku.Shizuku

/** Chạy lệnh shell bằng quyền Shizuku. */
object Sh {
    fun ready(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun run(cmd: String): Boolean = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        p.waitFor() == 0
    } catch (_: Throwable) { false }
}

/** Tốc độ con trỏ chuột của hệ thống (-7 .. +7). */
object Mouse {
    fun current(c: Context): Int = try {
        Settings.System.getInt(c.contentResolver, "pointer_speed", 0)
    } catch (_: Throwable) { 0 }

    /** Gọi trong luồng nền (có chạy lệnh shell). */
    fun apply(c: Context, v: Int): Boolean {
        val s = v.coerceIn(-7, 7)
        var ok = false
        if (Sh.ready()) ok = Sh.run("settings put system pointer_speed $s")
        if (!ok) try {
            if (Settings.System.canWrite(c)) {
                Settings.System.putInt(c.contentResolver, "pointer_speed", s); ok = true
            }
        } catch (_: Throwable) {}
        return ok
    }
}
