package com.hezpor.mouse

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED && Prefs.keep(c)) {
            try { c.startForegroundService(Intent(c, KeepService::class.java)) } catch (_: Throwable) {}
        }
    }
}
