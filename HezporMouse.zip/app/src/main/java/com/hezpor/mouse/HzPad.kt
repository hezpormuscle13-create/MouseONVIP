package com.hezpor.mouse

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.InputDevice
import android.view.MotionEvent
import android.view.View
import android.os.Build

/** Vùng thử: đo tốc độ báo cáo thật (Hz) của chuột / cảm ứng và vẽ vệt di chuyển. */
class HzPad(c: Context) : View(c) {
    var onHz: ((hz: Int, peak: Int, src: String) -> Unit)? = null

    private val samples = ArrayList<Long>()
    private var peak = 0
    private val trail = ArrayList<FloatArray>()
    private var cx = 0f
    private var cy = 0f

    private val d = resources.displayMetrics.density
    private val grid = Paint().apply { color = 0xFF2A3A44.toInt(); strokeWidth = 1f }
    private val line = Paint().apply {
        color = 0xFF00E5FF.toInt(); strokeWidth = 3f * d; style = Paint.Style.STROKE
        isAntiAlias = true; strokeCap = Paint.Cap.ROUND
    }
    private val dot = Paint().apply { color = Color.WHITE; isAntiAlias = true }

    fun resetPeak() { peak = 0; samples.clear() }
    fun clearTrail() { trail.clear(); invalidate() }

    private fun srcName(e: MotionEvent): String = when {
        (e.source and InputDevice.SOURCE_MOUSE_RELATIVE) == InputDevice.SOURCE_MOUSE_RELATIVE -> "Chuột (thô)"
        (e.source and InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE -> "Chuột"
        (e.source and InputDevice.SOURCE_TOUCHSCREEN) == InputDevice.SOURCE_TOUCHSCREEN -> "Cảm ứng"
        (e.source and InputDevice.SOURCE_STYLUS) == InputDevice.SOURCE_STYLUS -> "Bút"
        else -> "Khác"
    }

    /** Gom mọi mẫu (cả mẫu lịch sử đã gộp trong 1 khung hình) để tính số báo cáo/giây. */
    private fun feed(e: MotionEvent) {
        for (i in 0 until e.historySize) samples.add(e.getHistoricalEventTime(i))
        samples.add(e.eventTime)
        val last = samples[samples.size - 1]
        while (samples.isNotEmpty() && samples[0] < last - 400) samples.removeAt(0)
        if (samples.size >= 4) {
            val span = last - samples[0]
            if (span >= 40) {
                val hz = ((samples.size - 1) * 1000L / span).toInt()
                if (hz > peak) peak = hz
                onHz?.invoke(hz, peak, srcName(e))
            }
        }
    }

    private fun addPoint(x: Float, y: Float) {
        cx = x; cy = y
        trail.add(floatArrayOf(x, y))
        if (trail.size > 180) trail.removeAt(0)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        // Không gộp sự kiện: đo chính xác hơn và giảm trễ trong vùng này
        if (Build.VERSION.SDK_INT >= 31) requestUnbufferedDispatch(InputDevice.SOURCE_CLASS_POINTER)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            parent?.requestDisallowInterceptTouchEvent(true)
            if (Build.VERSION.SDK_INT < 31) requestUnbufferedDispatch(e)
        }
        feed(e); addPoint(e.x, e.y); invalidate()
        return true
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if ((e.source and InputDevice.SOURCE_CLASS_POINTER) == 0) return super.onGenericMotionEvent(e)
        feed(e); addPoint(e.x, e.y); invalidate()
        return true
    }

    /** Chế độ con trỏ thô (requestPointerCapture): lấy chuyển động tương đối, không tăng tốc. */
    fun onCaptured(e: MotionEvent): Boolean {
        feed(e)
        var rx = 0f; var ry = 0f
        for (i in 0 until e.historySize) {
            rx += e.getHistoricalAxisValue(MotionEvent.AXIS_RELATIVE_X, i)
            ry += e.getHistoricalAxisValue(MotionEvent.AXIS_RELATIVE_Y, i)
        }
        rx += e.getAxisValue(MotionEvent.AXIS_RELATIVE_X)
        ry += e.getAxisValue(MotionEvent.AXIS_RELATIVE_Y)
        addPoint((cx + rx).coerceIn(0f, width.toFloat()), (cy + ry).coerceIn(0f, height.toFloat()))
        invalidate()
        return true
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(0xFF0B1218.toInt())
        val s = 40f * d
        var x = 0f; while (x < width) { c.drawLine(x, 0f, x, height.toFloat(), grid); x += s }
        var y = 0f; while (y < height) { c.drawLine(0f, y, width.toFloat(), y, grid); y += s }
        for (i in 1 until trail.size) {
            val a = trail[i - 1]; val b = trail[i]
            line.alpha = 40 + (215 * i / trail.size)
            c.drawLine(a[0], a[1], b[0], b[1], line)
        }
        if (trail.isNotEmpty()) c.drawCircle(cx, cy, 6f * d, dot)
    }
}
