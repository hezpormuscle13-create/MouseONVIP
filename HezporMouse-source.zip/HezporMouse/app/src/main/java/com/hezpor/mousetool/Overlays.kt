package com.hezpor.mousetool

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.util.Random
import kotlin.math.max
import kotlin.math.roundToInt

val NEON: List<Int> = listOf(
    0xFF00E5FF.toInt(), 0xFF39FF14.toInt(), 0xFFFF2079.toInt(), 0xFFFFF01F.toInt(),
    0xFFBF00FF.toInt(), 0xFFFF6A00.toInt(), 0xFFFFFFFF.toInt(), 0xFFFF0000.toInt(),
    0xFF0066FF.toInt(), 0xFF00FFA3.toInt()
)

data class TextItem(
    val id: Long, val text: String, val color: Int, val size: Float, val x: Int, val y: Int,
    val bgOn: Boolean = true, val bgPct: Int = 70
)

object TextStore {
    private const val KEY = "texts_json"

    fun raw(c: Context): String = Prefs.sp(c).getString(KEY, "[]") ?: "[]"

    fun load(c: Context): List<TextItem> {
        val out = ArrayList<TextItem>()
        try {
            val arr = JSONArray(raw(c))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    TextItem(
                        o.getLong("id"), o.getString("text"), o.getInt("color"),
                        o.getDouble("size").toFloat(), o.getInt("x"), o.getInt("y"),
                        o.optBoolean("bgOn", true), o.optInt("bgPct", 70)
                    )
                )
            }
        } catch (e: Throwable) { }
        return out
    }

    fun save(c: Context, list: List<TextItem>) {
        val arr = JSONArray()
        for (t in list) {
            val o = JSONObject()
            o.put("id", t.id)
            o.put("text", t.text)
            o.put("color", t.color)
            o.put("size", t.size.toDouble())
            o.put("x", t.x)
            o.put("y", t.y)
            o.put("bgOn", t.bgOn)
            o.put("bgPct", t.bgPct)
            arr.put(o)
        }
        Prefs.sp(c).edit().putString(KEY, arr.toString()).apply()
    }
}

/** Quản lý các cửa sổ nổi: FPS (kiểu BlueStacks) và các dòng văn bản neon. */
class OverlayManager(private val ctx: Context, private val wm: WindowManager) {
    private val dens = ctx.resources.displayMetrics.density
    private fun dp(v: Int) = (v * dens).toInt()
    private val rnd = Random()

    private var fpsView: TextView? = null
    private var fpsSig = ""
    private val textViews = ArrayList<TextView>()
    private var textSig = ""

    private fun canDraw() = Settings.canDrawOverlays(ctx)

    private fun params(grav: Int, x: Int, y: Int, locked: Boolean): WindowManager.LayoutParams {
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (locked) f = f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            f, PixelFormat.TRANSLUCENT
        )
        lp.gravity = grav
        lp.x = x
        lp.y = y
        return lp
    }

    private fun drag(v: View, lp: WindowManager.LayoutParams, bottom: Boolean, onEnd: () -> Unit) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = max(0, ox + (e.rawX - sx).toInt())
                    val dy = (e.rawY - sy).toInt()
                    lp.y = max(0, if (bottom) oy - dy else oy + dy)
                    try { wm.updateViewLayout(v, lp) } catch (ex: Throwable) { }
                }
                MotionEvent.ACTION_UP -> onEnd()
            }
            true
        }
    }

    // ---------- FPS ----------

    fun syncFps() {
        val on = Prefs.getBool(ctx, K.FPS_ON, false) && canDraw()
        val lock = Prefs.getBool(ctx, K.FPS_LOCK, true)
        val color = Prefs.getInt(ctx, K.FPS_COLOR, 0xFFFFFFFF.toInt())
        val size = Prefs.getFloat(ctx, K.FPS_SIZE, 18f)
        val bgOn = Prefs.getBool(ctx, K.FPS_BG_ON, true)
        val bgPct = Prefs.getFloat(ctx, K.FPS_BG_PCT, 70f).roundToInt()
        val sig = "$on|$lock|$color|$size|$bgOn|$bgPct"
        if (sig == fpsSig) return
        fpsSig = sig
        fpsView?.let { try { wm.removeView(it) } catch (e: Throwable) { } }
        fpsView = null
        if (!on) return

        val tv = TextView(ctx)
        tv.text = "FPS --"
        tv.setTextColor(color)
        tv.textSize = size
        tv.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        tv.letterSpacing = 0.2f
        tv.setShadowLayer(10f, 0f, 0f, color)
        tv.setPadding(dp(10), dp(4), dp(18), dp(4))
        val bg = GradientDrawable()
        bg.setColor(if (bgOn) android.graphics.Color.argb(bgPct * 255 / 100, 0, 0, 0) else 0)
        val r = dp(14).toFloat()
        bg.cornerRadii = floatArrayOf(0f, 0f, r, r, 0f, 0f, 0f, 0f)
        tv.background = bg

        val x = if (lock) 0 else Prefs.getInt(ctx, K.FPS_X, 0)
        val y = if (lock) 0 else Prefs.getInt(ctx, K.FPS_Y, 0)
        val lp = params(Gravity.BOTTOM or Gravity.START, x, y, lock)
        if (!lock) {
            drag(tv, lp, true) {
                Prefs.setInt(ctx, K.FPS_X, lp.x)
                Prefs.setInt(ctx, K.FPS_Y, lp.y)
            }
        }
        try {
            wm.addView(tv, lp)
            fpsView = tv
        } catch (e: Throwable) { }
    }

    private fun fpsValue(): Int {
        if (Prefs.getBool(ctx, K.FPS_FAKE, false)) {
            val base = Prefs.getFloat(ctx, K.FPS_FAKE_VAL, 120f).roundToInt()
            val j = Prefs.getFloat(ctx, K.FPS_JITTER, 0f).roundToInt()
            val d = if (j > 0) rnd.nextInt(2 * j + 1) - j else 0
            return max(1, base + d)
        }
        return if (LiveState.realFps > 0) LiveState.realFps else LiveState.vsyncFps
    }

    fun updateFps() {
        val v = fpsView ?: return
        val n = fpsValue()
        v.text = if (n > 0) "FPS $n" else "FPS --"
    }

    // ---------- Văn bản ----------

    fun syncTexts() {
        val on = Prefs.getBool(ctx, K.TEXT_ON, false) && canDraw()
        val lock = Prefs.getBool(ctx, K.TEXT_LOCK, false)
        val sig = "$on|$lock|" + TextStore.raw(ctx)
        if (sig == textSig) return
        textSig = sig
        clearTexts()
        if (!on) return
        for (item in TextStore.load(ctx)) addText(item, lock)
    }

    private fun clearTexts() {
        for (v in textViews) { try { wm.removeView(v) } catch (e: Throwable) { } }
        textViews.clear()
    }

    private fun addText(item: TextItem, lock: Boolean) {
        val tv = TextView(ctx)
        tv.text = item.text
        tv.setTextColor(item.color)
        tv.textSize = item.size
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setShadowLayer(18f, 0f, 0f, item.color)
        tv.setPadding(dp(8), dp(3), dp(8), dp(3))
        if (item.bgOn) {
            val bgd = GradientDrawable()
            bgd.setColor(android.graphics.Color.argb(item.bgPct * 255 / 100, 0, 0, 0))
            bgd.cornerRadius = dp(10).toFloat()
            tv.background = bgd
        }
        val lp = params(Gravity.TOP or Gravity.START, item.x, item.y, lock)
        if (!lock) {
            drag(tv, lp, false) {
                val list = TextStore.load(ctx).map {
                    if (it.id == item.id) it.copy(x = lp.x, y = lp.y) else it
                }
                TextStore.save(ctx, list)
                textSig = "true|false|" + TextStore.raw(ctx)
            }
        }
        try {
            wm.addView(tv, lp)
            textViews.add(tv)
        } catch (e: Throwable) { }
    }

    fun destroy() {
        fpsView?.let { try { wm.removeView(it) } catch (e: Throwable) { } }
        fpsView = null
        fpsSig = ""
        clearTexts()
        textSig = ""
    }
}
