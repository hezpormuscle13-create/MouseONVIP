package com.hezpor.mousetool

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.provider.Settings
import rikka.shizuku.Shizuku
import java.util.concurrent.TimeUnit
import kotlin.math.ln
import kotlin.math.roundToInt

object K {
    const val SERVICE_ON = "service_on"
    const val BOOT_ON = "boot_on"
    const val WAKE_ON = "wake_on"
    const val SOUND_ON = "sound_on"
    const val HUD_ON = "hud_on"
    const val SYS_HZ_ON = "sys_hz_on"
    const val SPEED_LOCK = "speed_lock"
    const val SPEED_VAL = "speed_val"
    const val POINTER_LOC = "pointer_loc"
    const val SHOW_TOUCH = "show_touch"
    const val BIG_POINTER = "big_pointer"

    const val EMA = "t_ema"
    const val VELWIN = "t_velwin"
    const val MICRO = "t_micro"
    const val ACCEL = "t_accel"
    const val ACCEL_OFF = "t_accel_off"
    const val ACCEL_CAP = "t_accel_cap"
    const val REF_DPI = "t_ref_dpi"
    const val CUR_DPI = "t_cur_dpi"
    const val TREMOR_DZ = "t_tremor_dz"
    const val VDAMP_F = "t_vdamp_f"

    const val HD_ON = "hd_on"
    const val HD_PKG = "hd_pkg"
    const val HD_LABEL = "hd_label"
    const val HD_RES_ID = "hd_res_id"
    const val HD_SAT = "hd_sat"
    const val HD_ACTIVE = "hd_active"
    const val HD_START = "hd_start"
    const val HD_PW = "hd_pw"
    const val HD_PH = "hd_ph"
    const val HD_PD = "hd_pd"
    const val HD_POV = "hd_pov"
    const val HD_SIZE_CHANGED = "hd_size_changed"
    const val FPS_BG_ON = "fps_bg_on"
    const val FPS_BG_PCT = "fps_bg_pct"
    const val FPS_ON = "fps_on"
    const val FPS_FAKE = "fps_fake"
    const val FPS_LOCK = "fps_lock"
    const val FPS_COLOR = "fps_color"
    const val FPS_SIZE = "fps_size"
    const val FPS_FAKE_VAL = "fps_fake_val"
    const val FPS_JITTER = "fps_jitter"
    const val FPS_SPEED = "fps_speed"
    const val FPS_X = "fps_x"
    const val FPS_Y = "fps_y"
    const val TEXT_ON = "text_on"
    const val TEXT_LOCK = "text_lock"
    const val HZ_VAL = "hz_val"
    const val HZ_LOCK = "hz_lock"
    const val FL_PERF = "fl_perf"
    const val FL_CAM = "fl_cam"
    const val FL_GPU = "fl_gpu"
    const val FL_THERMAL = "fl_thermal"
    const val FL_ANIM = "fl_anim"

    const val F_MOTION = "f_motion"
    const val F_OVERSHOOT = "f_overshoot"
    const val F_QUICK = "f_quick"
    const val F_SMOOTH = "f_smooth"
    const val F_VDAMP = "f_vdamp"
    const val F_TREMOR = "f_tremor"
    const val F_DIRASSIST = "f_dirassist"
}

object Prefs {
    fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("hezpor_cfg", Context.MODE_PRIVATE)

    fun getBool(c: Context, k: String, d: Boolean = false): Boolean = sp(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) { sp(c).edit().putBoolean(k, v).apply() }
    fun getInt(c: Context, k: String, d: Int = 0): Int = sp(c).getInt(k, d)
    fun setInt(c: Context, k: String, v: Int) { sp(c).edit().putInt(k, v).apply() }
    fun getFloat(c: Context, k: String, d: Float = 0f): Float = sp(c).getFloat(k, d)
    fun setFloat(c: Context, k: String, v: Float) { sp(c).edit().putFloat(k, v).apply() }
}

/** Trạng thái chia sẻ giữa Service và Activity (cùng process). */
object LiveState {
    @Volatile var serviceRunning = false
    @Volatile var sysHz = 0
    @Volatile var sysHzTime = 0L
    @Volatile var sysDev = ""
    @Volatile var monitorRunning = false
    @Volatile var realFps = 0
    @Volatile var vsyncFps = 0
}

object ShizukuHelper {
    fun available(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun granted(): Boolean = try {
        available() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun request(code: Int) {
        try { Shizuku.requestPermission(code) } catch (e: Throwable) { }
    }

    private fun newProcess(cmd: Array<String>): Process? {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            m.invoke(null, cmd, null, null) as Process
        } catch (e: Throwable) {
            null
        }
    }

    /** Chạy lệnh shell (quyền shell qua Shizuku). Trả về output hoặc null nếu không chạy được. */
    fun exec(cmd: String, timeoutSec: Long = 10): String? {
        if (!granted()) return null
        val p = newProcess(arrayOf("sh", "-c", "($cmd) 2>&1")) ?: return null
        return try {
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor(timeoutSec, TimeUnit.SECONDS)
            out
        } catch (e: Throwable) {
            null
        } finally {
            try { p.destroy() } catch (e: Throwable) { }
        }
    }

    fun stream(cmd: String): Process? {
        if (!granted()) return null
        return newProcess(arrayOf("sh", "-c", cmd))
    }
}

object Sys {
    fun getPointerSpeed(c: Context): Int = try {
        Settings.System.getInt(c.contentResolver, "pointer_speed", 0)
    } catch (e: Throwable) { 0 }

    fun getInt(c: Context, table: String, key: String): Int = try {
        when (table) {
            "secure" -> Settings.Secure.getInt(c.contentResolver, key, 0)
            else -> Settings.System.getInt(c.contentResolver, key, 0)
        }
    } catch (e: Throwable) { 0 }

    /** Ghi setting. Ưu tiên quyền của app, nếu không có thì dùng Shizuku (shell). */
    fun putInt(c: Context, table: String, key: String, v: Int): Boolean {
        try {
            if (table == "system" && Settings.System.canWrite(c)) {
                if (Settings.System.putInt(c.contentResolver, key, v)) return true
            }
            if (table == "secure" &&
                c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED
            ) {
                if (Settings.Secure.putInt(c.contentResolver, key, v)) return true
            }
        } catch (e: Throwable) { }
        if (ShizukuHelper.granted()) {
            ShizukuHelper.exec("settings put $table $key $v")
            return getInt(c, table, key) == v
        }
        return false
    }

    fun getFloat(c: Context, key: String): Float = try {
        Settings.System.getFloat(c.contentResolver, key, 0f)
    } catch (e: Throwable) { 0f }

    /** Ép tần số quét: min = peak = hz. */
    fun setRefresh(c: Context, hz: Int): Boolean {
        val v = hz.toFloat()
        try {
            if (Settings.System.canWrite(c)) {
                Settings.System.putFloat(c.contentResolver, "peak_refresh_rate", v)
                Settings.System.putFloat(c.contentResolver, "min_refresh_rate", v)
                try {
                    if (c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED) {
                        Settings.Secure.putInt(c.contentResolver, "refresh_rate_mode", if (hz <= 60) 0 else 1)
                    }
                } catch (e: Throwable) { }
                return true
            }
        } catch (e: Throwable) { }
        if (ShizukuHelper.granted()) {
            ShizukuHelper.exec(
                "settings put system peak_refresh_rate ${hz}.0; settings put system min_refresh_rate ${hz}.0; " +
                    "settings put secure refresh_rate_mode ${if (hz <= 60) 0 else 1}"
            )
            return true
        }
        return false
    }

    fun clearRefresh(c: Context, maxHz: Int): Boolean {
        if (ShizukuHelper.granted()) {
            ShizukuHelper.exec(
                "settings delete system peak_refresh_rate; settings delete system min_refresh_rate; " +
                    "settings put secure refresh_rate_mode 1"
            )
            return true
        }
        try {
            if (Settings.System.canWrite(c)) {
                Settings.System.putFloat(c.contentResolver, "min_refresh_rate", 0f)
                Settings.System.putFloat(c.contentResolver, "peak_refresh_rate", maxHz.toFloat())
                return true
            }
        } catch (e: Throwable) { }
        return false
    }

    fun setPointerSpeed(c: Context, v: Int): Boolean =
        putInt(c, "system", "pointer_speed", v.coerceIn(-7, 7))
}

data class Tuning(
    val emaMs: Float, val velWin: Int, val micro: Float,
    val accel: Float, val accelOff: Float, val accelCap: Float,
    val refDpi: Float, val curDpi: Float,
    val motionStab: Boolean, val antiOvershoot: Boolean, val quickStart: Boolean,
    val smoothTrans: Boolean, val vDamp: Boolean, val tremor: Boolean, val dirAssist: Boolean,
    val tremorDz: Float, val vDampFactor: Float
) {
    fun gain(v: Float): Float = minOf(accelCap, 1f + accel * maxOf(0f, v - accelOff))

    fun dpiRatio(): Float = if (curDpi <= 0f) 1f else refDpi / curDpi

    /** Android: scale = 2^(speed/4)  =>  speed = 4*log2(mult). */
    fun systemSpeed(): Int {
        val mult = dpiRatio() * gain(20f)
        val s = 4.0 * ln(mult.toDouble()) / ln(2.0)
        return s.roundToInt().coerceIn(-7, 7)
    }

    companion object {
        fun load(c: Context) = Tuning(
            Prefs.getFloat(c, K.EMA, 2f),
            Prefs.getFloat(c, K.VELWIN, 4f).roundToInt(),
            Prefs.getFloat(c, K.MICRO, 2f),
            Prefs.getFloat(c, K.ACCEL, 0.04f),
            Prefs.getFloat(c, K.ACCEL_OFF, 3f),
            Prefs.getFloat(c, K.ACCEL_CAP, 1.4f),
            Prefs.getFloat(c, K.REF_DPI, 800f),
            Prefs.getFloat(c, K.CUR_DPI, 800f),
            Prefs.getBool(c, K.F_MOTION, true),
            Prefs.getBool(c, K.F_OVERSHOOT, false),
            Prefs.getBool(c, K.F_QUICK, true),
            Prefs.getBool(c, K.F_SMOOTH, true),
            Prefs.getBool(c, K.F_VDAMP, false),
            Prefs.getBool(c, K.F_TREMOR, false),
            Prefs.getBool(c, K.F_DIRASSIST, false),
            Prefs.getFloat(c, K.TREMOR_DZ, 1f),
            Prefs.getFloat(c, K.VDAMP_F, 1f)
        )
    }
}

data class ResProfile(val id: Long, val name: String, val w: Int, val h: Int, val d: Int)

object ResStore {
    private const val KEY = "res_profiles"

    fun load(c: Context): List<ResProfile> {
        val out = ArrayList<ResProfile>()
        try {
            val arr = org.json.JSONArray(Prefs.sp(c).getString(KEY, "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(ResProfile(o.getLong("id"), o.getString("name"), o.getInt("w"), o.getInt("h"), o.getInt("d")))
            }
        } catch (e: Throwable) { }
        return out
    }

    fun save(c: Context, list: List<ResProfile>) {
        val arr = org.json.JSONArray()
        for (r in list) {
            val o = org.json.JSONObject()
            o.put("id", r.id); o.put("name", r.name); o.put("w", r.w); o.put("h", r.h); o.put("d", r.d)
            arr.put(o)
        }
        Prefs.sp(c).edit().putString(KEY, arr.toString()).apply()
    }
}

/** Chế độ HD game: đổi phân giải/DPI + độ rực màu khi mở game, tự khôi phục khi thoát game. */
object DisplayCtl {
    class State(val w: Int, val h: Int, val d: Int, val override: Boolean)

    fun read(): State? {
        val so = ShizukuHelper.exec("wm size") ?: return null
        val dn = ShizukuHelper.exec("wm density") ?: return null
        var w = 0; var h = 0; var d = 0; var ov = false
        Regex("""Physical size: (\d+)x(\d+)""").find(so)?.let {
            w = it.groupValues[1].toInt(); h = it.groupValues[2].toInt()
        }
        Regex("""Override size: (\d+)x(\d+)""").find(so)?.let {
            w = it.groupValues[1].toInt(); h = it.groupValues[2].toInt(); ov = true
        }
        Regex("""Physical density: (\d+)""").find(dn)?.let { d = it.groupValues[1].toInt() }
        Regex("""Override density: (\d+)""").find(dn)?.let { d = it.groupValues[1].toInt(); ov = true }
        return if (w > 0 && h > 0 && d > 0) State(w, h, d, ov) else null
    }

    fun saturation(v: Float) {
        ShizukuHelper.exec("service call SurfaceFlinger 1022 f " + String.format(java.util.Locale.US, "%.2f", v))
    }

    fun start(c: Context): Boolean {
        if (!ShizukuHelper.granted()) return false
        val st = read() ?: return false
        Prefs.setInt(c, K.HD_PW, st.w)
        Prefs.setInt(c, K.HD_PH, st.h)
        Prefs.setInt(c, K.HD_PD, st.d)
        Prefs.setBool(c, K.HD_POV, st.override)
        val rid = Prefs.sp(c).getLong(K.HD_RES_ID, 0L)
        val prof = ResStore.load(c).firstOrNull { it.id == rid }
        if (prof != null) ShizukuHelper.exec("wm size ${prof.w}x${prof.h}; wm density ${prof.d}")
        Prefs.setBool(c, K.HD_SIZE_CHANGED, prof != null)
        saturation(Prefs.getFloat(c, K.HD_SAT, 100f) / 100f)
        Prefs.sp(c).edit().putLong(K.HD_START, System.currentTimeMillis()).apply()
        Prefs.setBool(c, K.HD_ACTIVE, true)
        return true
    }

    fun restore(c: Context) {
        if (!Prefs.getBool(c, K.HD_ACTIVE, false)) return
        Prefs.setBool(c, K.HD_ACTIVE, false)
        if (Prefs.getBool(c, K.HD_SIZE_CHANGED, false)) {
            if (Prefs.getBool(c, K.HD_POV, false)) {
                ShizukuHelper.exec(
                    "wm size ${Prefs.getInt(c, K.HD_PW)}x${Prefs.getInt(c, K.HD_PH)}; wm density ${Prefs.getInt(c, K.HD_PD)}"
                )
            } else {
                ShizukuHelper.exec("wm size reset; wm density reset")
            }
        }
        saturation(1f)
    }
}
