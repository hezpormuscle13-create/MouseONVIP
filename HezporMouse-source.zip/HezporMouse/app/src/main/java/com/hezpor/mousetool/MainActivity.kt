package com.hezpor.mousetool

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.text.InputType
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import rikka.shizuku.Shizuku
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private val ACC = 0xFF00E5FF.toInt()
    private val TXT = 0xFFE8EEF2.toInt()
    private val DIM = 0xFF9AA7B0.toInt()
    private val OK = 0xFF3DDC84.toInt()
    private val BAD = 0xFFFF5A5F.toInt()

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val ui = Handler(Looper.getMainLooper())
    private var video: VideoView? = null
    private var player: MediaPlayer? = null

    private lateinit var pad: PadView
    private lateinit var curve: CurveView
    private lateinit var tvHz: TextView
    private lateinit var tvHzSys: TextView
    private lateinit var tvStats: TextView
    private lateinit var tvMap: TextView
    private lateinit var tvRefresh: TextView
    private lateinit var fpsSw: Switch
    private lateinit var tvHd: TextView
    private lateinit var resList: LinearLayout
    private lateinit var svcSwitch: Switch
    private lateinit var speedSl: Sl
    private val statusViews = LinkedHashMap<String, TextView>()

    private var hzMax = 0
    private var hzSum = 0L
    private var hzCnt = 0

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
        ui.post { refreshStatus() }
    }
    private val binderListener = Shizuku.OnBinderReceivedListener { ui.post { refreshStatus() } }
    private val deadListener = Shizuku.OnBinderDeadListener { ui.post { refreshStatus() } }

    private val ticker = object : Runnable {
        override fun run() {
            refreshStatus()
            val fresh = System.currentTimeMillis() - LiveState.sysHzTime < 1500
            tvHzSys.text = if (fresh) "Toàn hệ thống: ${LiveState.sysHz} Hz  (${LiveState.sysDev})"
            else if (!ShizukuHelper.granted()) "Toàn hệ thống: cần Shizuku (bật quyền bên dưới)"
            else if (!LiveState.monitorRunning) "Toàn hệ thống: bật công tắc 'Đo Hz toàn hệ thống' + Dịch vụ nền"
            else "Toàn hệ thống: -- (hãy di chuyển chuột)"
            val on = Prefs.getBool(this@MainActivity, K.SERVICE_ON, false)
            if (svcSwitch.isChecked != on) svcSwitch.isChecked = on
            tvRefresh.text = refreshInfo()
            tvHd.text = hdInfo()
            val fo = Prefs.getBool(this@MainActivity, K.FPS_ON, false)
            if (fpsSw.isChecked != fo) fpsSw.isChecked = fo
            ui.postDelayed(this, 500)
        }
    }

    // ---------------- helpers ----------------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun roundBg(color: Int, radiusDp: Int, stroke: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        if (stroke != 0) g.setStroke(dp(1), stroke)
        return g
    }

    private fun lp(top: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(MATCH, WRAP)
        p.topMargin = dp(top)
        return p
    }

    private fun text(parent: LinearLayout, s: String, size: Float, color: Int, bold: Boolean = false, top: Int = 0): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        parent.addView(t, lp(top))
        return t
    }

    private fun card(parent: LinearLayout, title: String): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(16), dp(14), dp(16), dp(16))
        l.background = roundBg(0xB3101820.toInt(), 20, 0x33FFFFFF)
        parent.addView(l, lp(12))
        text(l, title, 16f, ACC, true)
        return l
    }

    private fun button(parent: LinearLayout, label: String, top: Int = 8, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(Color.BLACK)
        b.background = roundBg(ACC, 12)
        b.setOnClickListener { onClick() }
        parent.addView(b, lp(top))
        return b
    }

    private fun switchRow(
        parent: LinearLayout, label: String, key: String, def: Boolean,
        onChange: ((Boolean) -> Unit)? = null
    ): Switch {
        val s = Switch(this)
        s.text = label
        s.setTextColor(TXT)
        s.textSize = 14f
        s.isChecked = Prefs.getBool(this, key, def)
        s.setOnCheckedChangeListener { _, v ->
            Prefs.setBool(this, key, v)
            onChange?.invoke(v)
        }
        parent.addView(s, lp(8))
        return s
    }

    private inner class Sl(val sb: SeekBar, val min: Float, val step: Float, val show: (Float) -> Unit) {
        fun set(v: Float) {
            sb.progress = ((v - min) / step).roundToInt()
            show(v)
        }
    }

    private fun slider(
        parent: LinearLayout, label: String, key: String,
        min: Float, max: Float, step: Float, def: Float, fmt: String,
        onChange: (Float) -> Unit = {}
    ): Sl {
        val steps = ((max - min) / step).roundToInt()
        val cur = Prefs.getFloat(this, key, def)
        val tv = text(parent, "", 13f, TXT, false, 10)
        val show: (Float) -> Unit = { v -> tv.text = label + ": " + String.format(Locale.US, fmt, v) }
        show(cur)
        val sb = SeekBar(this)
        sb.max = steps
        sb.progress = ((cur - min) / step).roundToInt()
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = min + p * step
                show(v)
                if (fromUser) {
                    Prefs.setFloat(this@MainActivity, key, v)
                    onChange(v)
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(sb, lp(0))
        return Sl(sb, min, step, show)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------------- lifecycle ----------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        val vv = VideoView(this)
        video = vv
        root.addView(vv, FrameLayout.LayoutParams(MATCH, MATCH))
        try {
            vv.setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.bg_video}"))
            vv.setOnPreparedListener { m ->
                player = m
                m.isLooping = true
                applyVolume()
            }
            vv.setOnErrorListener { _, _, _ -> true }
            vv.start()
        } catch (e: Throwable) { }

        val scrim = View(this)
        scrim.setBackgroundColor(0x99000A12.toInt())
        root.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))

        val scroll = ScrollView(this)
        scroll.isFillViewport = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), dp(52), dp(14), dp(40))
        scroll.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        root.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)

        buildHeader(col)
        buildServiceCard(col)
        buildPermissionCard(col)
        buildHzCard(col)
        buildSpeedCard(col)
        buildTuningCard(col)
        buildSystemCard(col)
        buildFlowCard(col)
        buildDisplayCard(col)
        buildRefreshCard(col)
        buildHdCard(col)
        buildFpsCard(col)
        buildTextCard(col)
        buildNotesCard(col)

        try {
            Shizuku.addRequestPermissionResultListener(permListener)
            Shizuku.addBinderReceivedListenerSticky(binderListener)
            Shizuku.addBinderDeadListener(deadListener)
        } catch (e: Throwable) { }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        }
    }

    override fun onResume() {
        super.onResume()
        try { video?.start() } catch (e: Throwable) { }
        ui.removeCallbacks(ticker)
        ui.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(ticker)
        try { video?.pause() } catch (e: Throwable) { }
    }

    override fun onDestroy() {
        try {
            Shizuku.removeRequestPermissionResultListener(permListener)
            Shizuku.removeBinderReceivedListener(binderListener)
            Shizuku.removeBinderDeadListener(deadListener)
        } catch (e: Throwable) { }
        try { video?.stopPlayback() } catch (e: Throwable) { }
        super.onDestroy()
    }

    private fun applyVolume() {
        val v = if (Prefs.getBool(this, K.SOUND_ON, true)) 1f else 0f
        try { player?.setVolume(v, v) } catch (e: Throwable) { }
    }

    // ---------------- UI sections ----------------

    private fun buildHeader(col: LinearLayout) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val img = ImageView(this)
        img.setImageResource(R.drawable.avatar)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        img.clipToOutline = true
        img.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
        }
        row.addView(img, LinearLayout.LayoutParams(dp(72), dp(72)))
        val tcol = LinearLayout(this)
        tcol.orientation = LinearLayout.VERTICAL
        tcol.setPadding(dp(14), 0, 0, 0)
        text(tcol, "Hezpor Mouse", 24f, Color.WHITE, true)
        text(tcol, "Đo Hz • Tốc độ chuột • Chạy nền", 12f, DIM)
        row.addView(tcol, LinearLayout.LayoutParams(0, WRAP, 1f))
        col.addView(row, lp())
    }

    private fun buildServiceCard(col: LinearLayout) {
        val c = card(col, "DỊCH VỤ NỀN (chạy khi thoát app)")
        svcSwitch = switchRow(c, "Bật dịch vụ nền (Foreground Service)", K.SERVICE_ON, false) { on ->
            if (on) MouseService.start(this) else MouseService.stop(this)
        }
        switchRow(c, "Tự chạy lại sau khi khởi động máy", K.BOOT_ON, true)
        switchRow(c, "Giữ CPU thức (WakeLock) – ổn định hơn, tốn pin hơn", K.WAKE_ON, true)
        switchRow(c, "Âm thanh video nền", K.SOUND_ON, true) { applyVolume() }
    }

    private fun buildPermissionCard(col: LinearLayout) {
        val c = card(col, "QUYỀN")
        for ((k, _) in listOf(
            "shizuku" to "Shizuku", "overlay" to "Lớp phủ", "write" to "Ghi cài đặt hệ thống",
            "secure" to "WRITE_SECURE_SETTINGS", "notif" to "Thông báo", "battery" to "Bỏ tối ưu pin",
            "service" to "Dịch vụ nền"
        )) {
            statusViews[k] = text(c, "", 13f, TXT, false, 4)
        }
        button(c, "1. Cấp quyền Shizuku / mở Shizuku") {
            if (!ShizukuHelper.available()) {
                val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                if (i != null) startActivity(i) else toast("Chưa cài Shizuku hoặc Shizuku chưa chạy. Cài Shizuku rồi Start.")
            } else if (!ShizukuHelper.granted()) {
                ShizukuHelper.request(100)
            } else toast("Đã có quyền Shizuku")
        }
        button(c, "2. Cấp TẤT CẢ quyền còn lại bằng Shizuku (1 chạm)") { grantAll() }
        button(c, "Lớp phủ (Hiển thị trên ứng dụng khác)") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        button(c, "Ghi cài đặt hệ thống") {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        }
        button(c, "Thông báo") {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
            else startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        }
        button(c, "Bỏ tối ưu pin (chạy nền ổn định)") {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Throwable) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        button(c, "Cài đặt ứng dụng (Tự khởi động / chạy nền cho Xiaomi, Oppo, Vivo…)") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
    }

    private fun buildHzCard(col: LinearLayout) {
        val c = card(col, "ĐO HZ CHUỘT")
        tvHz = text(c, "-- Hz", 44f, ACC, true, 6)
        tvStats = text(c, "Max: -- | Trung bình: --", 13f, DIM)
        tvHzSys = text(c, "Toàn hệ thống: --", 13f, TXT, false, 6)

        pad = PadView(this)
        c.addView(pad, LinearLayout.LayoutParams(MATCH, dp(190)).apply { topMargin = dp(10) })
        pad.onHz = { hz ->
            if (hz > 0) {
                hzMax = max(hzMax, hz)
                hzSum += hz
                hzCnt++
                tvHz.text = "$hz Hz"
                tvStats.text = "Max: $hzMax Hz | Trung bình: ${hzSum / hzCnt} Hz"
            }
        }
        button(c, "Reset thống kê") {
            hzMax = 0; hzSum = 0; hzCnt = 0
            tvHz.text = "-- Hz"; tvStats.text = "Max: -- | Trung bình: --"
            pad.clearAll()
        }
        switchRow(c, "Đo Hz TOÀN HỆ THỐNG ngoài app (Shizuku)", K.SYS_HZ_ON, false) {
            if (it && !ShizukuHelper.granted()) toast("Cần cấp quyền Shizuku trước")
            if (it) ensureService()
        }
        switchRow(c, "Hiện Hz nổi (HUD) trên mọi ứng dụng", K.HUD_ON, false) {
            if (it && !Settings.canDrawOverlays(this)) {
                toast("Cần cấp quyền Lớp phủ")
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
            if (it) ensureService()
        }
        text(c, "Khung test đo thô theo thời gian sự kiện Android. Đo toàn hệ thống đọc trực tiếp /dev/input (micro giây) nên chính xác hơn.", 11f, DIM, false, 6)
    }

    private fun buildSpeedCard(col: LinearLayout) {
        val c = card(col, "TỐC ĐỘ CON TRỎ CHUỘT (hệ thống)")
        val cur = Sys.getPointerSpeed(this)
        if (!Prefs.sp(this).contains(K.SPEED_VAL)) Prefs.setFloat(this, K.SPEED_VAL, cur.toFloat())
        speedSl = slider(c, "Tốc độ", K.SPEED_VAL, -7f, 7f, 1f, cur.toFloat(), "%.0f") { v ->
            applySpeed(v.roundToInt())
        }
        text(c, "Dải -7 … +7 (0 = mặc định). Giá trị được ghi thẳng vào cài đặt hệ thống nên vẫn giữ nguyên sau khi thoát app.", 11f, DIM, false, 6)
        button(c, "Áp dụng lại ngay") { applySpeed(Prefs.getFloat(this, K.SPEED_VAL, 0f).roundToInt()) }
        button(c, "Về mặc định (0)") {
            Prefs.setFloat(this, K.SPEED_VAL, 0f); speedSl.set(0f); applySpeed(0)
        }
        switchRow(c, "KHÓA tốc độ (dịch vụ nền tự đặt lại nếu bị đổi)", K.SPEED_LOCK, false) {
            if (it) { ensureService(); applySpeed(Prefs.getFloat(this, K.SPEED_VAL, 0f).roundToInt()) }
        }
    }

    private fun applySpeed(v: Int) {
        Thread {
            val ok = Sys.setPointerSpeed(this, v)
            ui.post { if (!ok) toast("Không ghi được. Cấp 'Ghi cài đặt hệ thống' hoặc Shizuku.") }
        }.start()
    }

    private fun onTuningChanged() {
        pad.reload()
        curve.tuning = Tuning.load(this)
        curve.invalidate()
        val t = Tuning.load(this)
        tvMap.text = "→ Tốc độ hệ thống tương đương: ${t.systemSpeed()}  (DPI ${t.refDpi.roundToInt()}/${t.curDpi.roundToInt()}, gain×${String.format(Locale.US, "%.2f", t.gain(20f))})"
    }

    private fun buildTuningCard(col: LinearLayout) {
        val c = card(col, "TRACKING CONTROL")
        curve = CurveView(this)
        c.addView(curve, LinearLayout.LayoutParams(MATCH, dp(130)).apply { topMargin = dp(10) })
        tvMap = text(c, "", 12f, TXT, false, 8)

        val f = { _: Float -> onTuningChanged() }
        text(c, "CORE TUNING", 13f, ACC, true, 12)
        slider(c, "EMA Fast (ms)", K.EMA, 0.5f, 20f, 0.5f, 2f, "%.1f", f)
        slider(c, "Velocity Window", K.VELWIN, 1f, 16f, 1f, 4f, "%.0f", f)
        slider(c, "Micro Threshold", K.MICRO, 0f, 10f, 1f, 2f, "%.0f", f)
        slider(c, "Acceleration", K.ACCEL, 0f, 0.2f, 0.01f, 0.04f, "%.2f", f)
        slider(c, "Accel Offset", K.ACCEL_OFF, 0f, 10f, 0.25f, 3f, "%.2f", f)
        slider(c, "Accel Cap", K.ACCEL_CAP, 1f, 3f, 0.05f, 1.4f, "%.2f", f)
        slider(c, "Ref DPI", K.REF_DPI, 400f, 3200f, 50f, 800f, "%.0f", f)
        slider(c, "Cur DPI", K.CUR_DPI, 400f, 3200f, 50f, 800f, "%.0f", f)
        slider(c, "Tremor Deadzone", K.TREMOR_DZ, 0f, 10f, 0.5f, 1f, "%.1f", f)
        slider(c, "V-Damping Factor", K.VDAMP_F, 0.3f, 1f, 0.05f, 1f, "%.2f", f)

        val g = { _: Boolean -> onTuningChanged() }
        text(c, "BỘ LỌC", 13f, ACC, true, 14)
        switchRow(c, "Motion Stabilization", K.F_MOTION, true, g)
        switchRow(c, "Anti Overshoot", K.F_OVERSHOOT, false, g)
        switchRow(c, "Quick Start", K.F_QUICK, true, g)
        switchRow(c, "Smooth Transition", K.F_SMOOTH, true, g)
        switchRow(c, "Vertical Damping", K.F_VDAMP, false, g)
        switchRow(c, "Tremor Gate", K.F_TREMOR, false, g)
        switchRow(c, "Direction Assist", K.F_DIRASSIST, false, g)

        button(c, "Áp dụng vào tốc độ hệ thống (từ DPI + đường cong)") {
            val s = Tuning.load(this).systemSpeed()
            Prefs.setFloat(this, K.SPEED_VAL, s.toFloat())
            speedSl.set(s.toFloat())
            applySpeed(s)
            toast("Đã đặt tốc độ hệ thống = $s")
        }
        text(c, "Bộ lọc (EMA, cửa sổ vận tốc, tremor, damping…) áp dụng cho chuột trong khung test của app; phần gain + DPI được quy đổi thành tốc độ con trỏ hệ thống. Android không cho app thường chỉnh từng sự kiện chuột của ứng dụng khác.", 11f, DIM, false, 6)
        onTuningChanged()
    }

    private fun buildSystemCard(col: LinearLayout) {
        val c = card(col, "TIỆN ÍCH HỆ THỐNG (có hiệu lực ngoài app)")
        switchRow(c, "Hiện vị trí con trỏ / tọa độ (Pointer location)", K.POINTER_LOC, false) {
            toggleSystem("system", "pointer_location", it)
        }
        switchRow(c, "Hiện điểm chạm (Show touches)", K.SHOW_TOUCH, false) {
            toggleSystem("system", "show_touches", it)
        }
        switchRow(c, "Con trỏ chuột to (Large pointer icon)", K.BIG_POINTER, false) {
            toggleSystem("secure", "accessibility_large_pointer_icon", it)
        }
    }

    private fun toggleSystem(table: String, key: String, on: Boolean) {
        Thread {
            val ok = Sys.putInt(this, table, key, if (on) 1 else 0)
            ui.post { if (!ok) toast("Cần quyền Shizuku hoặc 'Ghi cài đặt hệ thống' (nhấn nút cấp quyền)") }
        }.start()
    }


    // ---------------- Optimizer ----------------

    private val flowSwitches = ArrayList<Switch>()
    private val flowKeys = listOf(K.FL_PERF, K.FL_CAM, K.FL_GPU, K.FL_THERMAL, K.FL_ANIM)

    private fun flowCmd(key: String, on: Boolean): String = when (key) {
        K.FL_PERF ->
            if (on) "cmd power set-fixed-performance-mode-enabled true; settings put global low_power 0"
            else "cmd power set-fixed-performance-mode-enabled false"
        K.FL_CAM -> {
            val pk = "com.sec.android.app.camera com.android.camera com.android.camera2 com.google.android.GoogleCamera " +
                "com.samsung.android.app.screenrecorder com.miui.screenrecorder com.coloros.screenrecorder"
            if (on) "for p in $pk; do pm path \$p >/dev/null 2>&1 && { am force-stop \$p; pm suspend --user 0 \$p; }; done"
            else "for p in $pk; do pm unsuspend --user 0 \$p; done"
        }
        K.FL_GPU -> "service call SurfaceFlinger 1008 i32 ${if (on) 1 else 0}"
        K.FL_THERMAL ->
            if (on) "cmd thermalservice override-status 0" else "cmd thermalservice reset"
        K.FL_ANIM -> {
            val v = if (on) "0.5" else "1.0"
            "settings put global window_animation_scale $v; settings put global transition_animation_scale $v; settings put global animator_duration_scale $v"
        }
        else -> "true"
    }

    private fun flowItem(c: LinearLayout, title: String, tag: String, desc: String, trade: String, key: String) {
        text(c, title, 15f, Color.WHITE, true, 16)
        text(c, "[$tag]", 12f, 0xFFFF8A80.toInt(), true, 2)
        text(c, desc, 12f, DIM, false, 2)
        text(c, "Đánh đổi: $trade", 12f, 0xFFFFB4A8.toInt(), false, 2)
        flowSwitches.add(switchRow(c, "Chọn", key, false))
    }

    private fun buildFlowCard(col: LinearLayout) {
        val c = card(col, "OPTIMIZER (cần Shizuku)")
        text(c, "⚠ Cảnh báo nhiệt độ: ép phần cứng hoạt động hết công suất, máy sẽ ấm hơn, nên có quạt tản nhiệt.", 12f, 0xFFFFD54F.toInt(), false, 8)
        flowItem(c, "⚡ Mở khóa hiệu năng tối đa (High Perf)", "Nóng máy",
            "Ép CPU & GPU chạy xung cao, tắt tiết kiệm pin hãng.",
            "Máy nóng nhanh hơn, hao thêm pin. (Cần Android 12+; máy không hỗ trợ sẽ bỏ qua.)", K.FL_PERF)
        flowItem(c, "📷 Tạm dừng Camera & Ghi màn hình", "Giải phóng RAM",
            "Dừng và treo app camera / ghi màn hình để dồn RAM chơi game.",
            "Không mở được Camera khi đang bật. Tắt công tắc rồi bấm Kích hoạt (hoặc Mặc định) để mở lại.", K.FL_CAM)
        flowItem(c, "🎮 Ép GPU render (Disable HW Overlays)", "Nóng GPU",
            "GPU gánh việc dựng hình thay vì overlay phần cứng.",
            "GPU chạy liên tục nên ấm hơn, tốn pin game 3D. Mất hiệu lực sau khi khởi động lại.", K.FL_GPU)
        flowItem(c, "❄ Bỏ qua bóp xung nhiệt độ (Thermal Override)", "Cân nhắc",
            "Ngăn hệ thống tự động hạ xung CPU/GPU khi máy ấm lên.",
            "Nguy cơ nóng máy cao. Chỉ dùng khi có tản nhiệt và theo dõi nhiệt độ.", K.FL_THERMAL)
        flowItem(c, "✨ Giảm hoạt ảnh hệ thống (0.5x)", "Mượt hơn",
            "Giảm thời gian animation cửa sổ/chuyển cảnh để thao tác nhanh hơn.",
            "Không đáng kể; tắt công tắc để về 1.0x.", K.FL_ANIM)

        button(c, "🚀 KÍCH HOẠT OPTIMIZER", 16) {
            if (!ShizukuHelper.granted()) {
                toast("Cần cấp quyền Shizuku trước")
            } else {
                Thread {
                    for (k in flowKeys) ShizukuHelper.exec(flowCmd(k, Prefs.getBool(this, k, false)), 20)
                    ui.post { toast("Đã áp dụng theo các công tắc") }
                }.start()
            }
        }
        button(c, "↩ Mặc định (tắt hết)") {
            for (sw in flowSwitches) sw.isChecked = false
            if (!ShizukuHelper.granted()) {
                toast("Cần cấp quyền Shizuku trước")
            } else {
                Thread {
                    for (k in flowKeys) ShizukuHelper.exec(flowCmd(k, false), 20)
                    ui.post { toast("Đã khôi phục mặc định") }
                }.start()
            }
        }
    }

    // ---------------- Độ phân giải & DPI ----------------

    private lateinit var etW: EditText
    private lateinit var etH: EditText
    private lateinit var etD: EditText
    private lateinit var tvDisp: TextView
    private var physW = 0
    private var physH = 0
    private var physD = 0
    private var curW = 0
    private var curH = 0
    private var curD = 0

    private fun numEdit(parent: LinearLayout, label: String): EditText {
        text(parent, label, 12f, DIM, false, 8)
        val e = EditText(this)
        e.inputType = InputType.TYPE_CLASS_NUMBER
        e.setTextColor(TXT)
        e.setHintTextColor(DIM)
        e.textSize = 15f
        e.background = roundBg(0xFF0B141B.toInt(), 10, 0x5500E5FF)
        e.setPadding(dp(12), dp(8), dp(12), dp(8))
        parent.addView(e, lp(2))
        return e
    }

    private fun loadDisplay() {
        Thread {
            val dm = resources.displayMetrics
            var pw = dm.widthPixels; var ph = dm.heightPixels; var pd = dm.densityDpi
            var cw = pw; var ch = ph; var cd = pd
            val so = ShizukuHelper.exec("wm size")
            val dn = ShizukuHelper.exec("wm density")
            if (so != null) {
                Regex("""Physical size: (\d+)x(\d+)""").find(so)?.let {
                    pw = it.groupValues[1].toInt(); ph = it.groupValues[2].toInt(); cw = pw; ch = ph
                }
                Regex("""Override size: (\d+)x(\d+)""").find(so)?.let {
                    cw = it.groupValues[1].toInt(); ch = it.groupValues[2].toInt()
                }
            }
            if (dn != null) {
                Regex("""Physical density: (\d+)""").find(dn)?.let { pd = it.groupValues[1].toInt(); cd = pd }
                Regex("""Override density: (\d+)""").find(dn)?.let { cd = it.groupValues[1].toInt() }
            }
            ui.post {
                physW = pw; physH = ph; physD = pd; curW = cw; curH = ch; curD = cd
                tvDisp.text = "Hiện tại: ${cw}x$ch • ${cd} dpi   |   Gốc: ${pw}x$ph • ${pd} dpi"
                if (etW.text.isNullOrEmpty()) { etW.setText("$cw"); etH.setText("$ch"); etD.setText("$cd") }
            }
        }.start()
    }

    private fun buildDisplayCard(col: LinearLayout) {
        val c = card(col, "ĐỘ PHÂN GIẢI & DPI MÀN HÌNH (cần Shizuku)")
        tvDisp = text(c, "Đang đọc…", 12f, TXT, false, 8)
        etW = numEdit(c, "Chiều rộng (px)")
        etH = numEdit(c, "Chiều cao (px)")
        etD = numEdit(c, "DPI (mật độ)")

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (pct in listOf(100, 85, 75, 60)) {
            val b = Button(this)
            b.text = "$pct%"
            b.isAllCaps = false
            b.setTextColor(Color.BLACK)
            b.textSize = 12f
            b.setPadding(0, 0, 0, 0)
            b.background = roundBg(ACC, 10)
            b.setOnClickListener {
                if (physW > 0) {
                    etW.setText("${(physW * pct / 100 / 2) * 2}")
                    etH.setText("${(physH * pct / 100 / 2) * 2}")
                    etD.setText("${physD * pct / 100}")
                }
            }
            row.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(4) })
        }
        c.addView(row, lp(10))

        button(c, "Áp dụng độ phân giải + DPI", 10) { applyDisplay() }
        button(c, "Khôi phục gốc") {
            if (!ShizukuHelper.granted()) toast("Cần cấp quyền Shizuku trước")
            else Thread {
                ShizukuHelper.exec("wm size reset; wm density reset")
                ui.post { etW.setText(""); loadDisplay(); toast("Đã khôi phục độ phân giải gốc") }
            }.start()
        }
        text(c, "Nếu màn hình lỗi, bấm 'Khôi phục gốc' (hoặc chạy lệnh wm size reset / wm density reset). Nút % là tỉ lệ so với độ phân giải gốc (giữ nguyên tỉ lệ khung hình).", 11f, DIM, false, 6)
        text(c, "CẤU HÌNH ĐÃ LƯU", 13f, ACC, true, 14)
        button(c, "💾 Lưu cấu hình hiện tại (đặt tên)", 6) { profileDialog(null) }
        resList = LinearLayout(this)
        resList.orientation = LinearLayout.VERTICAL
        c.addView(resList, lp(6))
        text(c, "Chạm vào tên để áp dụng ngay. Sửa để đổi tên và thông số, Xóa để bỏ cấu hình.", 11f, DIM, false, 6)
        refreshResList()
        loadDisplay()
    }

    private fun refreshResList() {
        resList.removeAllViews()
        for (p in ResStore.load(this)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            val tv = TextView(this)
            tv.text = p.name + "\n" + p.w + "x" + p.h + " • " + p.d + " dpi"
            tv.setTextColor(TXT)
            tv.textSize = 14f
            tv.setPadding(dp(10), dp(8), dp(10), dp(8))
            tv.background = roundBg(0xFF0B141B.toInt(), 10, 0x5500E5FF)
            tv.setOnClickListener {
                etW.setText("${p.w}"); etH.setText("${p.h}"); etD.setText("${p.d}")
                applyDisplay()
            }
            row.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
            val ed = Button(this)
            ed.text = "Sửa"
            ed.isAllCaps = false
            ed.setOnClickListener { profileDialog(p) }
            row.addView(ed, LinearLayout.LayoutParams(WRAP, WRAP))
            val del = Button(this)
            del.text = "Xóa"
            del.isAllCaps = false
            del.setOnClickListener {
                ResStore.save(this, ResStore.load(this).filter { it.id != p.id })
                refreshResList()
            }
            row.addView(del, LinearLayout.LayoutParams(WRAP, WRAP))
            resList.addView(row, lp(6))
        }
    }

    private fun dlgField(parent: LinearLayout, label: String, value: String, number: Boolean): EditText {
        text(parent, label, 12f, DIM, false, 8)
        val e = EditText(this)
        e.setText(value)
        e.setTextColor(TXT)
        if (number) e.inputType = InputType.TYPE_CLASS_NUMBER
        parent.addView(e, lp(2))
        return e
    }

    private fun profileDialog(p: ResProfile?) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(12), dp(20), dp(8))
        val w0 = p?.w ?: etW.text.toString().toIntOrNull() ?: curW
        val h0 = p?.h ?: etH.text.toString().toIntOrNull() ?: curH
        val d0 = p?.d ?: etD.text.toString().toIntOrNull() ?: curD
        val en = dlgField(box, "Tên cấu hình", p?.name ?: "", false)
        val ew = dlgField(box, "Chiều rộng (px)", "$w0", true)
        val eh = dlgField(box, "Chiều cao (px)", "$h0", true)
        val ed = dlgField(box, "DPI", "$d0", true)
        val sc = ScrollView(this)
        sc.addView(box)
        AlertDialog.Builder(this)
            .setTitle(if (p == null) "Lưu cấu hình mới" else "Sửa cấu hình")
            .setView(sc)
            .setPositiveButton("Lưu") { _, _ ->
                val w = ew.text.toString().toIntOrNull()
                val h = eh.text.toString().toIntOrNull()
                val d = ed.text.toString().toIntOrNull()
                if (w == null || h == null || d == null || w !in 200..8000 || h !in 200..8000 || d !in 100..1000) {
                    toast("Giá trị không hợp lệ (rộng/cao 200–8000, DPI 100–1000)")
                } else {
                    val name = en.text.toString().trim().ifEmpty { "${w}x$h • ${d}dpi" }
                    val list = ResStore.load(this).toMutableList()
                    if (p == null) {
                        list.add(ResProfile(System.currentTimeMillis(), name, w, h, d))
                    } else {
                        val i = list.indexOfFirst { it.id == p.id }
                        if (i >= 0) list[i] = p.copy(name = name, w = w, h = h, d = d)
                    }
                    ResStore.save(this, list)
                    refreshResList()
                }
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun applyDisplay() {
        if (!ShizukuHelper.granted()) { toast("Cần cấp quyền Shizuku trước"); return }
        val w = etW.text.toString().toIntOrNull()
        val h = etH.text.toString().toIntOrNull()
        val d = etD.text.toString().toIntOrNull()
        if (w == null || h == null || d == null || w !in 200..8000 || h !in 200..8000 || d !in 100..1000) {
            toast("Giá trị không hợp lệ (rộng/cao 200–8000, DPI 100–1000)")
            return
        }
        Thread {
            ShizukuHelper.exec("wm size ${w}x$h; wm density $d")
            ui.post { loadDisplay(); toast("Đã áp dụng ${w}x$h • $d dpi") }
        }.start()
    }


    // ---------------- Tần số quét ----------------

    private fun supportedHz(): List<Int> = try {
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.supportedModes.map { it.refreshRate.roundToInt() }.distinct().sorted()
    } catch (e: Throwable) { emptyList() }

    private fun refreshInfo(): String {
        val cur = try {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.refreshRate.roundToInt()
        } catch (e: Throwable) { 0 }
        val sup = supportedHz()
        return "Hiện tại: $cur Hz  |  Máy hỗ trợ: " + (if (sup.isEmpty()) "không rõ" else sup.joinToString(", ") { "$it" } + " Hz")
    }

    private fun setHz(hz: Int) {
        Prefs.setFloat(this, K.HZ_VAL, hz.toFloat())
        val sup = supportedHz()
        if (sup.isNotEmpty() && hz !in sup) toast("Máy không báo hỗ trợ ${hz}Hz, vẫn thử áp dụng")
        Thread {
            val ok = Sys.setRefresh(this, hz)
            ui.post { toast(if (ok) "Đã ép $hz Hz" else "Cần quyền Shizuku hoặc 'Ghi cài đặt hệ thống'") }
        }.start()
    }

    private fun buildRefreshCard(col: LinearLayout) {
        val c = card(col, "TẦN SỐ QUÉT MÀN HÌNH (Hz)")
        tvRefresh = text(c, refreshInfo(), 12f, TXT, false, 8)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (hz in listOf(60, 90, 120, 144)) {
            val b = Button(this)
            b.text = "$hz"
            b.isAllCaps = false
            b.textSize = 13f
            b.setPadding(0, 0, 0, 0)
            b.setTextColor(Color.BLACK)
            b.background = roundBg(ACC, 10)
            b.setOnClickListener { setHz(hz) }
            row.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(4) })
        }
        c.addView(row, lp(10))
        button(c, "Tự động (bỏ ép Hz)") {
            val max = supportedHz().maxOrNull() ?: 120
            Thread {
                val ok = Sys.clearRefresh(this, max)
                ui.post { toast(if (ok) "Đã trả về tự động" else "Cần quyền Shizuku hoặc 'Ghi cài đặt hệ thống'") }
            }.start()
        }
        switchRow(c, "KHÓA Hz (dịch vụ nền tự ép lại nếu hệ thống đổi)", K.HZ_LOCK, false) {
            if (it) {
                ensureService()
                val v = Prefs.getFloat(this, K.HZ_VAL, 0f).roundToInt()
                if (v > 0) setHz(v)
            }
        }
        text(c, "Chỉ chọn được mức màn hình hỗ trợ. Một số máy (Samsung, Xiaomi…) có thể giới hạn theo chế độ Mượt mà / ứng dụng; bật KHÓA Hz để giữ.", 11f, DIM, false, 6)
    }


    // ---------------- FPS nổi & Văn bản nổi ----------------

    private fun checkOverlay(on: Boolean) {
        if (!on) return
        if (!Settings.canDrawOverlays(this)) {
            toast("Cần cấp quyền Lớp phủ")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        ensureService()
    }

    private fun colorPicker(parent: LinearLayout, onChange: (Int) -> Unit) {
        val sv = HorizontalScrollView(this)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (cl in NEON) {
            val v = View(this)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(cl)
            g.setStroke(dp(1), 0x88FFFFFF.toInt())
            v.background = g
            v.setOnClickListener { onChange(cl) }
            val lpv = LinearLayout.LayoutParams(dp(36), dp(36))
            lpv.marginEnd = dp(8)
            row.addView(v, lpv)
        }
        sv.addView(row)
        parent.addView(sv, lp(8))

        text(parent, "Màu tùy chỉnh (kéo thanh màu)", 12f, DIM, false, 10)
        val sb = SeekBar(this)
        sb.max = 360
        val rainbow = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(
                0xFFFF0000.toInt(), 0xFFFFFF00.toInt(), 0xFF00FF00.toInt(),
                0xFF00FFFF.toInt(), 0xFF0000FF.toInt(), 0xFFFF00FF.toInt(), 0xFFFF0000.toInt()
            )
        )
        rainbow.cornerRadius = dp(4).toFloat()
        rainbow.setSize(0, dp(8))
        sb.progressDrawable = rainbow
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) onChange(Color.HSVToColor(floatArrayOf(p.toFloat(), 1f, 1f)))
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(sb, lp(2))

        val hexRow = LinearLayout(this)
        hexRow.orientation = LinearLayout.HORIZONTAL
        val hex = EditText(this)
        hex.hint = "#RRGGBB"
        hex.setTextColor(TXT)
        hex.setHintTextColor(DIM)
        hex.textSize = 14f
        hexRow.addView(hex, LinearLayout.LayoutParams(0, WRAP, 1f))
        val ok = Button(this)
        ok.text = "Dùng mã"
        ok.isAllCaps = false
        ok.setOnClickListener {
            try {
                var t = hex.text.toString().trim()
                if (!t.startsWith("#")) t = "#$t"
                onChange(Color.parseColor(t))
            } catch (e: Throwable) { toast("Mã màu không hợp lệ") }
        }
        hexRow.addView(ok, LinearLayout.LayoutParams(WRAP, WRAP))
        parent.addView(hexRow, lp(4))
    }

    private fun buildFpsCard(col: LinearLayout) {
        val c = card(col, "FPS NỔI (góc dưới trái, kiểu BlueStacks)")
        lateinit var fpsBtn: Button
        fpsSw = switchRow(c, "Hiện FPS trên mọi ứng dụng", K.FPS_ON, false) {
            checkOverlay(it)
            fpsBtn.text = if (it) "⏹ TẮT FPS" else "▶ BẬT FPS"
        }
        fpsBtn = button(c, if (fpsSw.isChecked) "⏹ TẮT FPS" else "▶ BẬT FPS") { fpsSw.isChecked = !fpsSw.isChecked }
        switchRow(c, "FPS GIẢ (tự nhập số, tắt = FPS thật)", K.FPS_FAKE, false)
        slider(c, "Số FPS giả", K.FPS_FAKE_VAL, 1f, 360f, 1f, 120f, "%.0f")
        slider(c, "Dao động ±", K.FPS_JITTER, 0f, 30f, 1f, 0f, "%.0f")
        slider(c, "Tốc độ đổi số (ms, nhỏ = nhanh)", K.FPS_SPEED, 50f, 2000f, 50f, 500f, "%.0f")
        slider(c, "Cỡ chữ", K.FPS_SIZE, 10f, 40f, 1f, 18f, "%.0f")
        switchRow(c, "Nền đen cho FPS", K.FPS_BG_ON, true)
        slider(c, "Độ đậm nền (0 = trong suốt, 100 = đen)", K.FPS_BG_PCT, 0f, 100f, 5f, 70f, "%.0f")
        switchRow(c, "KHÓA cố định góc dưới cùng bên trái (tắt để kéo di chuyển)", K.FPS_LOCK, true)
        text(c, "Màu chữ FPS", 13f, TXT, true, 12)
        colorPicker(c) { Prefs.setInt(this, K.FPS_COLOR, it) }
        text(
            c,
            "FPS thật: đọc khung hình của app đang mở qua Shizuku (SurfaceFlinger); nếu không đọc được sẽ hiện tần số quét màn hình. Khi KHÓA, chạm xuyên qua FPS nên không cản thao tác game.",
            11f, DIM, false, 8
        )
    }

    private lateinit var textList: LinearLayout

    private fun buildTextCard(col: LinearLayout) {
        val c = card(col, "VĂN BẢN NỔI (ghi chữ khi live)")
        switchRow(c, "Hiện văn bản trên màn hình", K.TEXT_ON, false) { checkOverlay(it) }
        switchRow(c, "KHÓA vị trí (chạm xuyên qua, không kéo được)", K.TEXT_LOCK, false)
        textList = LinearLayout(this)
        textList.orientation = LinearLayout.VERTICAL
        c.addView(textList, lp(8))
        button(c, "＋ Thêm văn bản") { editTextDialog(null) }
        text(c, "Khi KHÓA tắt: kéo từng dòng chữ trên màn hình để đặt vị trí.", 11f, DIM, false, 6)
        refreshTextList()
    }

    private fun refreshTextList() {
        textList.removeAllViews()
        for (item in TextStore.load(this)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            val tv = TextView(this)
            tv.text = item.text
            tv.setTextColor(item.color)
            tv.setShadowLayer(10f, 0f, 0f, item.color)
            tv.textSize = 16f
            tv.typeface = Typeface.DEFAULT_BOLD
            tv.setOnClickListener { editTextDialog(item) }
            row.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
            val del = Button(this)
            del.text = "Xóa"
            del.isAllCaps = false
            del.setOnClickListener {
                TextStore.save(this, TextStore.load(this).filter { it.id != item.id })
                refreshTextList()
            }
            row.addView(del, LinearLayout.LayoutParams(WRAP, WRAP))
            textList.addView(row, lp(4))
        }
    }

    private fun editTextDialog(item: TextItem?) {
        var color = item?.color ?: NEON[0]
        var size = item?.size ?: 28f
        var bgOn = item?.bgOn ?: true
        var bgPct = item?.bgPct ?: 70
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(12), dp(20), dp(8))

        val et = EditText(this)
        et.hint = "Nội dung văn bản"
        et.setText(item?.text ?: "")
        et.setTextColor(TXT)
        et.setHintTextColor(DIM)
        box.addView(et, lp(0))

        val preview = TextView(this)
        preview.typeface = Typeface.DEFAULT_BOLD
        preview.gravity = Gravity.CENTER
        box.addView(preview, lp(10))
        fun upd() {
            preview.setTextColor(color)
            preview.setShadowLayer(18f, 0f, 0f, color)
            preview.textSize = size
            preview.text = if (et.text.isNullOrEmpty()) "Xem trước" else et.text.toString()
            if (bgOn) {
                val g = GradientDrawable()
                g.setColor(Color.argb(bgPct * 255 / 100, 0, 0, 0))
                g.cornerRadius = dp(10).toFloat()
                preview.background = g
            } else {
                preview.background = roundBg(0xFF808080.toInt(), 10)
            }
        }
        upd()

        text(box, "Cỡ chữ", 12f, DIM, false, 10)
        val sb = SeekBar(this)
        sb.max = 70
        sb.progress = (size.toInt() - 10).coerceIn(0, 70)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { size = 10f + p; upd() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(sb, lp(2))

        val swBg = Switch(this)
        swBg.text = "Nền đen sau chữ"
        swBg.setTextColor(TXT)
        swBg.isChecked = bgOn
        swBg.setOnCheckedChangeListener { _, v -> bgOn = v; upd() }
        box.addView(swBg, lp(12))
        text(box, "Độ đậm nền (0 = trong suốt, 100 = đen)", 12f, DIM, false, 6)
        val sbBg = SeekBar(this)
        sbBg.max = 100
        sbBg.progress = bgPct
        sbBg.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { bgPct = p; upd() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(sbBg, lp(2))

        text(box, "Màu neon", 12f, DIM, false, 10)
        colorPicker(box) { color = it; upd() }

        val scroll = ScrollView(this)
        scroll.addView(box)
        AlertDialog.Builder(this)
            .setTitle(if (item == null) "Thêm văn bản" else "Sửa văn bản")
            .setView(scroll)
            .setPositiveButton("Lưu") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isEmpty()) {
                    toast("Chưa nhập nội dung")
                } else {
                    val list = TextStore.load(this).toMutableList()
                    if (item == null) {
                        list.add(TextItem(System.currentTimeMillis(), t, color, size, dp(40), dp(160) + list.size * dp(56), bgOn, bgPct))
                    } else {
                        val i = list.indexOfFirst { it.id == item.id }
                        if (i >= 0) list[i] = item.copy(text = t, color = color, size = size, bgOn = bgOn, bgPct = bgPct)
                    }
                    TextStore.save(this, list)
                    refreshTextList()
                    if (Prefs.getBool(this, K.TEXT_ON, false)) ensureService()
                }
            }
            .setNegativeButton("Hủy", null)
            .show()
    }


    // ---------------- HD GAME ----------------

    private fun hdInfo(): String {
        val label = Prefs.sp(this).getString(K.HD_LABEL, "") ?: ""
        val rid = Prefs.sp(this).getLong(K.HD_RES_ID, 0L)
        val prof = ResStore.load(this).firstOrNull { it.id == rid }
        val active = Prefs.getBool(this, K.HD_ACTIVE, false)
        return "Game: " + (if (label.isEmpty()) "chưa chọn" else label) +
            "\nPhân giải HD: " + (if (prof == null) "giữ nguyên" else prof.name + " (" + prof.w + "x" + prof.h + ", " + prof.d + " dpi)") +
            "\nĐộ rực màu: " + Prefs.getFloat(this, K.HD_SAT, 100f).roundToInt() + "%" +
            "\nTrạng thái: " + (if (active) "ĐANG BẬT HD" else "bình thường")
    }

    private fun buildHdCard(col: LinearLayout) {
        val c = card(col, "HD GAME (đồ họa khi chơi game, cần Shizuku)")
        tvHd = text(c, hdInfo(), 12f, TXT, false, 8)
        switchRow(c, "Bật HD game (áp dụng khi mở game từ nút bên dưới)", K.HD_ON, false)

        button(c, "🎮 Chọn game", 10) {
            val pm = packageManager
            val it0 = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = pm.queryIntentActivities(it0, 0)
                .map { r -> r.activityInfo.packageName to r.loadLabel(pm).toString() }
                .distinctBy { a -> a.first }
                .filter { a -> a.first != packageName }
                .sortedBy { a -> a.second.lowercase() }
            if (apps.isEmpty()) {
                toast("Không liệt kê được ứng dụng")
            } else {
                AlertDialog.Builder(this)
                    .setTitle("Chọn game")
                    .setItems(apps.map { a -> a.second }.toTypedArray()) { _, i ->
                        Prefs.sp(this).edit()
                            .putString(K.HD_PKG, apps[i].first)
                            .putString(K.HD_LABEL, apps[i].second).apply()
                        tvHd.text = hdInfo()
                    }
                    .show()
            }
        }
        button(c, "🖥 Chọn cấu hình phân giải HD (đã lưu ở mục phân giải)") {
            val list = ResStore.load(this)
            val names = ArrayList<String>()
            names.add("Giữ nguyên phân giải")
            for (r in list) names.add(r.name + "  (" + r.w + "x" + r.h + ", " + r.d + " dpi)")
            AlertDialog.Builder(this)
                .setTitle("Phân giải khi chơi game")
                .setItems(names.toTypedArray()) { _, i ->
                    Prefs.sp(this).edit().putLong(K.HD_RES_ID, if (i == 0) 0L else list[i - 1].id).apply()
                    tvHd.text = hdInfo()
                }
                .show()
        }
        slider(c, "Độ rực màu % (100 = gốc, cao hơn = màu đậm hơn)", K.HD_SAT, 50f, 200f, 5f, 100f, "%.0f") {
            tvHd.text = hdInfo()
        }
        button(c, "Xem thử màu ngay") {
            val v = Prefs.getFloat(this, K.HD_SAT, 100f) / 100f
            Thread { DisplayCtl.saturation(v) }.start()
        }
        button(c, "Đặt lại màu gốc") { Thread { DisplayCtl.saturation(1f) }.start() }

        button(c, "▶ MỞ GAME Ở CHẾ ĐỘ HD", 14) {
            val pkg = Prefs.sp(this).getString(K.HD_PKG, "") ?: ""
            val launch = if (pkg.isEmpty()) null else packageManager.getLaunchIntentForPackage(pkg)
            if (launch == null) {
                toast("Hãy chọn game trước")
            } else {
                val wantHd = Prefs.getBool(this, K.HD_ON, false)
                if (wantHd && !ShizukuHelper.granted()) toast("Cần Shizuku để bật HD, vẫn mở game bình thường")
                ensureService()
                val app = applicationContext
                Thread {
                    if (wantHd) DisplayCtl.start(app)
                    try { Thread.sleep(600) } catch (e: Throwable) { }
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try { app.startActivity(launch) } catch (e: Throwable) { }
                }.start()
            }
        }
        button(c, "↩ Khôi phục bình thường ngay") {
            val app = applicationContext
            Thread {
                DisplayCtl.restore(app)
                ui.post { tvHd.text = hdInfo(); toast("Đã khôi phục") }
            }.start()
        }
        text(
            c,
            "App đổi phân giải/DPI và độ rực màu của máy ngay trước khi mở game, rồi tự khôi phục sau khi bạn thoát game (dịch vụ nền theo dõi). Không chỉnh cài đặt đồ họa bên trong game. Khôi phục tay nếu cần.",
            11f, DIM, false, 8
        )
    }

    private fun buildNotesCard(col: LinearLayout) {
        val c = card(col, "GHI CHÚ")
        text(
            c,
            "• Shizuku mất khi khởi động lại máy: mở Shizuku và Start lại (Android 11+ dùng Wireless debugging).\n" +
            "• Đã cấp WRITE_SECURE_SETTINGS / Ghi cài đặt thì tốc độ chuột vẫn ghi được kể cả khi Shizuku tắt.\n" +
            "• Xiaomi/Oppo/Vivo/Samsung: bật Tự khởi động, bỏ tối ưu pin, khóa app ở màn hình đa nhiệm.\n" +
            "• Cách khác cấp quyền không cần Shizuku (qua máy tính):\n" +
            "  adb shell pm grant com.hezpor.mousetool android.permission.WRITE_SECURE_SETTINGS",
            12f, DIM, false, 6
        )
    }

    // ---------------- permission logic ----------------

    private fun ensureService() {
        if (!Prefs.getBool(this, K.SERVICE_ON, false)) {
            Prefs.setBool(this, K.SERVICE_ON, true)
            svcSwitch.isChecked = true
        }
    }

    private fun grantAll() {
        if (!ShizukuHelper.granted()) {
            toast("Hãy cấp quyền Shizuku trước (nút 1)")
            return
        }
        val p = packageName
        Thread {
            val cmds = listOf(
                "pm grant $p android.permission.WRITE_SECURE_SETTINGS",
                "pm grant $p android.permission.POST_NOTIFICATIONS",
                "appops set $p WRITE_SETTINGS allow",
                "appops set $p SYSTEM_ALERT_WINDOW allow",
                "appops set $p RUN_IN_BACKGROUND allow",
                "appops set $p RUN_ANY_IN_BACKGROUND allow",
                "cmd deviceidle whitelist +$p"
            )
            val out = ShizukuHelper.exec(cmds.joinToString("; "))
            ui.post {
                toast(if (out == null) "Không chạy được lệnh Shizuku" else "Đã gửi lệnh cấp quyền")
                refreshStatus()
            }
        }.start()
    }

    private fun setStatus(key: String, label: String, ok: Boolean, detail: String) {
        val tv = statusViews[key] ?: return
        tv.text = "● $label: $detail"
        tv.setTextColor(if (ok) OK else BAD)
    }

    private fun refreshStatus() {
        val sAvail = ShizukuHelper.available()
        val sGrant = ShizukuHelper.granted()
        setStatus(
            "shizuku", "Shizuku", sGrant,
            if (sGrant) "đã cấp quyền" else if (sAvail) "đang chạy, chưa cấp quyền" else "chưa chạy"
        )
        val ov = Settings.canDrawOverlays(this)
        setStatus("overlay", "Lớp phủ", ov, if (ov) "đã bật" else "chưa cấp")
        val ws = Settings.System.canWrite(this)
        setStatus("write", "Ghi cài đặt hệ thống", ws, if (ws) "đã cấp" else "chưa cấp (có thể dùng Shizuku)")
        val sec = checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED
        setStatus("secure", "WRITE_SECURE_SETTINGS", sec, if (sec) "đã cấp" else "chưa cấp")
        val nt = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        setStatus("notif", "Thông báo", nt, if (nt) "đã cấp" else "chưa cấp")
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val bt = pm.isIgnoringBatteryOptimizations(packageName)
        setStatus("battery", "Bỏ tối ưu pin", bt, if (bt) "đã bỏ" else "chưa")
        setStatus("service", "Dịch vụ nền", LiveState.serviceRunning, if (LiveState.serviceRunning) "đang chạy" else "đang tắt")
    }
}
