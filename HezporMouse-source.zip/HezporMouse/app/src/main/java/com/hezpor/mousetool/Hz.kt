package com.hezpor.mousetool

import kotlin.math.abs
import kotlin.math.hypot

/** Tính tần số lấy mẫu (Hz) từ dấu thời gian (ms) của các sự kiện chuột. */
class HzMeter(private val windowMs: Double = 250.0) {
    private val q = ArrayDeque<Double>()

    fun add(tMs: Double) {
        if (q.isNotEmpty() && tMs - q.last() > 400.0) q.clear()
        q.addLast(tMs)
        while (q.isNotEmpty() && tMs - q.first() > windowMs) q.removeFirst()
    }

    fun hz(): Int {
        if (q.size < 5) return 0
        val span = q.last() - q.first()
        if (span < 20.0) return 0
        return Math.round((q.size - 1) * 1000.0 / span).toInt()
    }

    fun clear() = q.clear()
}

/**
 * Đo Hz toàn hệ thống: chạy `getevent -lt` qua Shizuku (quyền shell đọc được /dev/input),
 * đếm SYN_REPORT của thiết bị có REL_X/REL_Y (chuột) theo timestamp của kernel (micro giây).
 */
class EventMonitor(private val cb: (Int, String) -> Unit) {
    @Volatile private var running = false
    @Volatile private var proc: Process? = null
    private var th: Thread? = null

    private class Dev {
        var rel = false
        var pend = false
        val m = HzMeter()
    }

    private val re = Regex("""^\[\s*(\d+)\.(\d+)\]\s+(\S+?):\s+(\S+)\s+(\S+)\s+(\S+)""")

    fun start() {
        if (running) return
        running = true
        LiveState.monitorRunning = true
        th = Thread { loop() }.apply { isDaemon = true; start() }
    }

    fun stop() {
        running = false
        LiveState.monitorRunning = false
        try { proc?.destroy() } catch (e: Throwable) { }
        th?.interrupt()
        th = null
    }

    private fun loop() {
        val devs = HashMap<String, Dev>()
        while (running) {
            val p = ShizukuHelper.stream("getevent -lt")
            if (p == null) {
                try { Thread.sleep(2000) } catch (e: Throwable) { }
                continue
            }
            proc = p
            try {
                val br = p.inputStream.bufferedReader()
                var lastCb = 0L
                while (running) {
                    val line = br.readLine() ?: break
                    val m = re.find(line) ?: continue
                    val g = m.groupValues
                    val devName = g[3]
                    val type = g[4]
                    val code = g[5]
                    val d = devs.getOrPut(devName) { Dev() }
                    if (type == "EV_REL" && (code == "REL_X" || code == "REL_Y")) {
                        d.rel = true
                        d.pend = true
                    } else if (type == "EV_SYN" && code == "SYN_REPORT") {
                        if (d.rel && d.pend) {
                            d.pend = false
                            val ts = g[1].toDouble() * 1000.0 + g[2].toDouble() / 1000.0
                            d.m.add(ts)
                            val now = System.nanoTime() / 1_000_000L
                            if (now - lastCb > 80) {
                                lastCb = now
                                cb(d.m.hz(), devName)
                            }
                        }
                    }
                }
            } catch (e: Throwable) {
            } finally {
                try { p.destroy() } catch (e: Throwable) { }
                proc = null
            }
            if (running) {
                try { Thread.sleep(1500) } catch (e: Throwable) { }
            }
        }
    }
}

/** Bộ lọc chuột mô phỏng các tham số trong ảnh Tracking Control (áp dụng trong khung test). */
class MouseFilter(var t: Tuning) {
    private var lastT = 0.0
    private var fx = 0f
    private var fy = 0f
    private var px = 0f
    private var py = 0f
    private var gs = 1f
    private val win = ArrayDeque<FloatArray>()

    fun reset() {
        lastT = 0.0; fx = 0f; fy = 0f; px = 0f; py = 0f; gs = 1f; win.clear()
    }

    fun apply(dx: Float, dy: Float, tMs: Double): FloatArray {
        val tn = t
        val rawDt = if (lastT <= 0.0) 1.0 else tMs - lastT
        lastT = tMs
        if (rawDt > 40.0) { // vừa bắt đầu di chuyển lại
            fx = 0f; fy = 0f; px = 0f; py = 0f; win.clear()
        }
        val dt = rawDt.toFloat().coerceIn(0.25f, 50f)
        val justStarted = rawDt > 40.0

        win.addLast(floatArrayOf(dx, dy))
        while (win.size > tn.velWin.coerceAtLeast(1)) win.removeFirst()
        var sx = 0f
        var sy = 0f
        for (w in win) { sx += w[0]; sy += w[1] }
        var ox = dx
        var oy = dy

        if (tn.motionStab) {
            ox = sx / win.size
            oy = sy / win.size
            var alpha = dt / (tn.emaMs + dt)
            if (tn.quickStart && justStarted) alpha = 1f
            fx += alpha * (ox - fx)
            fy += alpha * (oy - fy)
            ox = fx
            oy = fy
        }

        val mag = hypot(ox, oy)
        if (tn.tremor && mag < tn.tremorDz * 0.1f) { ox = 0f; oy = 0f }
        if (mag < tn.micro * 0.02f) { ox = 0f; oy = 0f }

        if (tn.dirAssist) {
            if (abs(ox) > 3f * abs(oy)) oy *= 0.6f
            else if (abs(oy) > 3f * abs(ox)) ox *= 0.6f
        }
        if (tn.vDamp) oy *= tn.vDampFactor
        if (tn.antiOvershoot && (ox * px + oy * py) < 0f && mag > 0.5f) { ox *= 0.5f; oy *= 0.5f }
        px = ox; py = oy

        val v = hypot(dx, dy) / dt * 5f
        var g = tn.gain(v)
        if (tn.smoothTrans) { gs += 0.15f * (g - gs); g = gs } else gs = g
        val k = g * tn.dpiRatio()
        return floatArrayOf(ox * k, oy * k)
    }
}
