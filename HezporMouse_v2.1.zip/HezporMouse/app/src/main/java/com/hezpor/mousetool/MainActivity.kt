package com.hezpor.mousetool

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.text.InputType
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import rikka.shizuku.Shizuku
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private val ACC = 0xFF00C8FF.toInt()
    private val TXT = 0xFFEAF6FF.toInt()
    private val DIM = 0xFF7F9CC4.toInt()
    private val OK = 0xFF3DDC84.toInt()
    private val BAD = 0xFFFF5A5F.toInt()

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val ui = Handler(Looper.getMainLooper())
    private var video: VideoView? = null
    private var player: MediaPlayer? = null

    private lateinit var pad: PadView
    private lateinit var curve: CurveView
    private lateinit var tvHz: TextView
    private lateinit var tvHzSys: TextView
    private lateinit var tvStats: TextView
    private lateinit var tvMap: TextView
    private lateinit var tvRefresh: TextView
    private lateinit var fpsSw: Switch
    private lateinit var resList: LinearLayout
    private lateinit var svcSwitch: Switch
    private lateinit var speedSl: Sl
    private lateinit var nmdPad: NmdPadView
    private lateinit var nmdCurve: NmdCurveView
    private var nmdMon: TextView? = null
    private var nmdRate: TextView? = null
    private val nmdSl = HashMap<String, Sl>()
    private val statusViews = LinkedHashMap<String, TextView>()

    private var hzMax = 0
    private var hzSum = 0L
    private var hzCnt = 0

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
        ui.post { refreshStatus() }
    }
    private val binderListener = Shizuku.OnBinderReceivedListener { ui.post { refreshStatus() } }
    private val deadListener = Shizuku.OnBinderDeadListener { ui.post { refreshStatus() } }

    private val ticker = object : Runnable {
        override fun run() {
            refreshStatus()
            refreshHero()
            val fresh = System.currentTimeMillis() - LiveState.sysHzTime < 1500
            tvHzSys.text = if (fresh) "Toàn hệ thống: ${LiveState.sysHz} Hz  (${LiveState.sysDev})"
            else if (!ShizukuHelper.granted()) "Toàn hệ thống: cần Shizuku (bật quyền bên dưới)"
            else if (!LiveState.monitorRunning) "Toàn hệ thống: bật công tắc 'Đo Hz toàn hệ thống' + Dịch vụ nền"
            else "Toàn hệ thống: -- (hãy di chuyển chuột)"
            val on = Prefs.getBool(this@MainActivity, K.SERVICE_ON, false)
            if (svcSwitch.isChecked != on) svcSwitch.isChecked = on
            tvRefresh.text = refreshInfo()
            val fo = Prefs.getBool(this@MainActivity, K.FPS_ON, false)
            if (fpsSw.isChecked != fo) fpsSw.isChecked = fo
            ui.postDelayed(this, 500)
        }
    }

    // ---------------- helpers ----------------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun roundBg(color: Int, radiusDp: Int, stroke: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        if (stroke != 0) g.setStroke(dp(1), stroke)
        return g
    }

    private fun lp(top: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(MATCH, WRAP)
        p.topMargin = dp(top)
        return p
    }

    private fun text(parent: LinearLayout, s: String, size: Float, color: Int, bold: Boolean = false, top: Int = 0): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        parent.addView(t, lp(top))
        return t
    }

    private fun card(parent: LinearLayout, title: String): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(16), dp(14), dp(16), dp(16))
        val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xEE0F1B4A.toInt(), 0xEE060C24.toInt()))
        g.cornerRadius = dp(18).toFloat()
        g.setStroke(dp(1), 0x8800C8FF.toInt())
        l.background = g
        parent.addView(l, lp(12))
        val t = text(l, title, 14f, ACC, true)
        t.letterSpacing = 0.08f
        t.setShadowLayer(12f, 0f, 0f, ACC)
        val bar = View(this)
        bar.background = roundBg(ACC, 2)
        l.addView(bar, LinearLayout.LayoutParams(dp(28), dp(3)).apply { topMargin = dp(4); bottomMargin = dp(2) })
        return l
    }

    private fun button(parent: LinearLayout, label: String, top: Int = 8, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.typeface = Typeface.DEFAULT_BOLD
        val bg = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF0050E0.toInt(), 0xFF00B4FF.toInt()))
        bg.cornerRadius = dp(12).toFloat()
        b.background = bg
        b.setOnClickListener { onClick() }
        parent.addView(b, lp(top))
        return b
    }

    private fun switchRow(
        parent: LinearLayout, label: String, key: String, def: Boolean,
        onChange: ((Boolean) -> Unit)? = null
    ): Switch {
        val s = Switch(this)
        s.text = label
        s.setTextColor(TXT)
        s.textSize = 14f
        Ui(this).tint(s)
        s.isChecked = Prefs.getBool(this, key, def)
        s.setOnCheckedChangeListener { _, v ->
            Prefs.setBool(this, key, v)
            onChange?.invoke(v)
        }
        parent.addView(s, lp(8))
        return s
    }

    private inner class Sl(val sb: SeekBar, val min: Float, val step: Float, val show: (Float) -> Unit) {
        fun set(v: Float) {
            sb.progress = ((v - min) / step).roundToInt()
            show(v)
        }
    }

    private fun slider(
        parent: LinearLayout, label: String, key: String,
        min: Float, max: Float, step: Float, def: Float, fmt: String,
        onChange: (Float) -> Unit = {}
    ): Sl {
        val steps = ((max - min) / step).roundToInt()
        val cur = Prefs.getFloat(this, key, def)
        val tv = text(parent, "", 13f, TXT, false, 10)
        val show: (Float) -> Unit = { v -> tv.text = label + ": " + String.format(Locale.US, fmt, v) }
        show(cur)
        val sb = SeekBar(this)
        sb.max = steps
        sb.progress = ((cur - min) / step).roundToInt()
        sb.progressTintList = android.content.res.ColorStateList.valueOf(ACC)
        sb.thumbTintList = android.content.res.ColorStateList.valueOf(ACC)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = min + p * step
                show(v)
                if (fromUser) {
                    Prefs.setFloat(this@MainActivity, key, v)
                    onChange(v)
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(sb, lp(0))
        return Sl(sb, min, step, show)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------------- lifecycle ----------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        val vv = VideoView(this)
        video = vv
        root.addView(vv, FrameLayout.LayoutParams(MATCH, MATCH))
        try {
            vv.setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.bg_video}"))
            vv.setOnPreparedListener { m ->
                player = m
                m.isLooping = true
                applyVolume()
            }
            vv.setOnErrorListener { _, _, _ -> true }
            vv.start()
        } catch (e: Throwable) { }

        val scrim = View(this)
        scrim.setBackgroundColor(0xB8030818.toInt())
        root.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))

        val outer = LinearLayout(this)
        outer.orientation = LinearLayout.VERTICAL
        outer.setPadding(dp(14), dp(44), dp(14), 0)
        root.addView(outer, FrameLayout.LayoutParams(MATCH, MATCH))

        val head = LinearLayout(this)
        head.orientation = LinearLayout.VERTICAL
        outer.addView(head, lp())
        buildHeader(head)

        val tabBar = HorizontalScrollView(this)
        tabBar.isHorizontalScrollBarEnabled = false
        val tabRow = LinearLayout(this)
        tabRow.orientation = LinearLayout.HORIZONTAL
        tabBar.addView(tabRow)
        outer.addView(tabBar, lp(10))

        val scroll = ScrollView(this)
        scroll.isFillViewport = false
        scroll.isVerticalScrollBarEnabled = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, 0, 0, dp(40))
        scroll.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        outer.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)

        val tabNames = listOf("Tổng quan", "Hiệu suất", "Chuột", "Hình ảnh", "HUD", "Ghi chú")
        val pages = ArrayList<LinearLayout>()
        for (n in tabNames) {
            val pg = LinearLayout(this)
            pg.orientation = LinearLayout.VERTICAL
            col.addView(pg, lp())
            pages.add(pg)
        }
        buildFooter(col)
        val tabViews = ArrayList<TextView>()
        fun selectTab(i: Int) {
            for (k in pages.indices) pages[k].visibility = if (k == i) View.VISIBLE else View.GONE
            for (k in tabViews.indices) {
                val sel = k == i
                tabViews[k].setTextColor(if (sel) Color.BLACK else TXT)
                tabViews[k].background = roundBg(if (sel) ACC else 0xCC0B1433.toInt(), 18, if (sel) ACC else 0x5500C8FF)
                tabViews[k].setShadowLayer(if (sel) 0f else 0.01f, 0f, 0f, 0)
            }
            scroll.scrollTo(0, 0)
            Prefs.setInt(this, "ui_tab", i)
        }
        for (i in tabNames.indices) {
            val t = TextView(this)
            t.text = tabNames[i]
            t.textSize = 13f
            t.typeface = Typeface.DEFAULT_BOLD
            t.setPadding(dp(16), dp(8), dp(16), dp(8))
            t.setOnClickListener { selectTab(i) }
            val tp = LinearLayout.LayoutParams(WRAP, WRAP)
            tp.marginEnd = dp(8)
            tabRow.addView(t, tp)
            tabViews.add(t)
        }

        // Tổng quan
        buildHeroCard(pages[0])
        buildServiceCard(pages[0])
        buildBubbleCard(pages[0])
        buildPermissionCard(pages[0])
        // Chuột (buildHzCard phải đứng trước buildTuningCard)
        buildHzCard(pages[2])
        buildTuningCard(pages[2])
        buildNmdCard(pages[2])
        buildSystemCard(pages[2])
        // Hiệu suất
        buildRefreshCard(pages[1])
        buildFlowCard(pages[1])
        buildSpeedCard(pages[1])
        // Hình ảnh
        buildGfxCard(pages[3])
        buildDisplayCard(pages[3])
        // HUD
        buildFpsCard(pages[4])
        buildTextCard(pages[4])
        // Ghi chú
        buildNotesCard(pages[5])
        selectTab(Prefs.getInt(this, "ui_tab", 0).coerceIn(0, tabNames.size - 1))
        if (Prefs.getBool(this, K.BUBBLE_ON, true) && Settings.canDrawOverlays(this)) ensureService()

        try {
            Shizuku.addRequestPermissionResultListener(permListener)
            Shizuku.addBinderReceivedListenerSticky(binderListener)
            Shizuku.addBinderDeadListener(deadListener)
        } catch (e: Throwable) { }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        }
    }

    override fun onResume() {
        super.onResume()
        try { video?.start() } catch (e: Throwable) { }
        ui.removeCallbacks(ticker)
        ui.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(ticker)
        try { video?.pause() } catch (e: Throwable) { }
    }

    override fun onDestroy() {
        try {
            Shizuku.removeRequestPermissionResultListener(permListener)
            Shizuku.removeBinderReceivedListener(binderListener)
            Shizuku.removeBinderDeadListener(deadListener)
        } catch (e: Throwable) { }
        try { video?.stopPlayback() } catch (e: Throwable) { }
        try { logoAnim?.cancel() } catch (e: Throwable) { }
        gfxPanel?.shutdown()
        super.onDestroy()
    }

    private fun applyVolume() {
        val v = if (Prefs.getBool(this, K.SOUND_ON, true)) 1f else 0f
        try { player?.setVolume(v, v) } catch (e: Throwable) { }
    }

    // ---------------- UI sections ----------------

    private fun buildHeader(col: LinearLayout) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val img = ImageView(this)
        img.setImageResource(R.drawable.hezpor_logo)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        img.clipToOutline = true
        img.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(v: android.view.View, o: android.graphics.Outline) { o.setOval(0, 0, v.width, v.height) }
        }
        row.addView(img, LinearLayout.LayoutParams(dp(54), dp(54)))
        val tcol = LinearLayout(this)
        tcol.orientation = LinearLayout.VERTICAL
        tcol.setPadding(dp(12), 0, 0, 0)
        text(tcol, "HEZPOR MOUSE", 20f, Color.WHITE, true).apply { letterSpacing = 0.1f; setShadowLayer(18f, 0f, 0f, ACC) }
        text(tcol, "BỘ CÔNG CỤ GAME", 10f, ACC, true).apply { letterSpacing = 0.25f }
        row.addView(tcol, LinearLayout.LayoutParams(0, WRAP, 1f))
        col.addView(row, lp())
    }

    private fun heroTile(parent: LinearLayout, label: String, first: Boolean): TextView {
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        t.gravity = Gravity.CENTER
        t.setPadding(dp(4), dp(10), dp(4), dp(10))
        t.background = roundBg(0x88030818.toInt(), 14, 0x6600C8FF)
        val v = TextView(this)
        v.textSize = 19f
        v.typeface = Typeface.DEFAULT_BOLD
        v.setTextColor(ACC)
        v.gravity = Gravity.CENTER
        v.setShadowLayer(14f, 0f, 0f, ACC)
        t.addView(v, LinearLayout.LayoutParams(MATCH, WRAP))
        val l = TextView(this)
        l.text = label
        l.textSize = 9.5f
        l.letterSpacing = 0.12f
        l.setTextColor(DIM)
        l.typeface = Typeface.DEFAULT_BOLD
        l.gravity = Gravity.CENTER
        t.addView(l, LinearLayout.LayoutParams(MATCH, WRAP))
        val p = LinearLayout.LayoutParams(0, WRAP, 1f)
        if (!first) p.marginStart = dp(8)
        parent.addView(t, p)
        return v
    }

    private fun heroBtn(parent: LinearLayout, label: String, primary: Boolean, first: Boolean, onClick: () -> Unit) {
        val b = TextView(this)
        b.text = label
        b.textSize = 13f
        b.typeface = Typeface.DEFAULT_BOLD
        b.gravity = Gravity.CENTER
        b.letterSpacing = 0.05f
        b.setPadding(dp(6), dp(13), dp(6), dp(13))
        if (primary) {
            val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF0050E0.toInt(), 0xFF00C8FF.toInt()))
            g.cornerRadius = dp(14).toFloat()
            b.background = g
            b.setTextColor(Color.WHITE)
        } else {
            b.background = roundBg(0x99081230.toInt(), 14, ACC)
            b.setTextColor(ACC)
        }
        b.setOnClickListener { onClick() }
        val p = LinearLayout.LayoutParams(0, WRAP, 1f)
        if (!first) p.marginStart = dp(8)
        parent.addView(b, p)
    }

    private fun buildHeroCard(col: LinearLayout) {
        val hero = LinearLayout(this)
        hero.orientation = LinearLayout.VERTICAL
        hero.gravity = Gravity.CENTER_HORIZONTAL
        hero.setPadding(dp(16), dp(20), dp(16), dp(16))
        val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xF0123A8A.toInt(), 0xF0230E5A.toInt(), 0xF0050A1C.toInt()))
        g.cornerRadius = dp(24).toFloat()
        g.setStroke(dp(2), ACC)
        hero.background = g
        col.addView(hero, lp(12))

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.hezpor_logo)
        logo.scaleType = ImageView.ScaleType.CENTER_CROP
        logo.clipToOutline = true
        logo.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(v: android.view.View, o: android.graphics.Outline) { o.setOval(0, 0, v.width, v.height) }
        }
        hero.addView(logo, LinearLayout.LayoutParams(dp(112), dp(112)))
        try {
            val an = android.animation.ValueAnimator.ofFloat(0.94f, 1.04f)
            an.duration = 1400
            an.repeatCount = android.animation.ValueAnimator.INFINITE
            an.repeatMode = android.animation.ValueAnimator.REVERSE
            an.addUpdateListener { v ->
                val f = v.animatedValue as Float
                logo.scaleX = f
                logo.scaleY = f
            }
            an.start()
            logoAnim = an
        } catch (e: Throwable) { }

        text(hero, "HEZPOR MOUSE", 27f, Color.WHITE, true, 8).apply {
            gravity = Gravity.CENTER; letterSpacing = 0.12f; setShadowLayer(26f, 0f, 0f, ACC)
        }
        text(hero, "CHUỘT  •  HZ  •  FPS  •  GRAPHICS", 10.5f, ACC, true, 2).apply {
            gravity = Gravity.CENTER; letterSpacing = 0.2f
        }

        val tiles = LinearLayout(this)
        tiles.orientation = LinearLayout.HORIZONTAL
        hero.addView(tiles, lp(16))
        heroHz = heroTile(tiles, "HZ MÀN HÌNH", true)
        heroShz = heroTile(tiles, "SHIZUKU", false)
        heroSvc = heroTile(tiles, "DỊCH VỤ", false)

        val r1 = LinearLayout(this)
        r1.orientation = LinearLayout.HORIZONTAL
        hero.addView(r1, lp(14))
        heroBtn(r1, "🚀 TĂNG TỐC", true, true) {
            Thread {
                val m = try { Actions.boost(this) } catch (e: Throwable) { "Lỗi: " + (e.message ?: "") }
                ui.post { toast(m) }
            }.start()
        }
        heroBtn(r1, "↩ KHÔI PHỤC", false, false) {
            Thread {
                val m = try { Actions.restoreAll(this) } catch (e: Throwable) { "Lỗi: " + (e.message ?: "") }
                ui.post { toast(m) }
            }.start()
        }
        val r2 = LinearLayout(this)
        r2.orientation = LinearLayout.HORIZONTAL
        hero.addView(r2, lp(8))
        heroBtn(r2, "🎯 MỞ MENU NỔI", false, true) {
            if (!Settings.canDrawOverlays(this)) {
                toast("Cần cấp quyền Lớp phủ")
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                ensureService()
                MouseService.openMenu(this)
            }
        }
        heroBtn(r2, "📊 BẬT/TẮT FPS", false, false) {
            val on = !Prefs.getBool(this, K.FPS_ON, false)
            Prefs.setBool(this, K.FPS_ON, on)
            if (on) ensureService()
            toast(if (on) "FPS nổi: BẬT" else "FPS nổi: TẮT")
        }
        refreshHero()
    }

    private fun refreshHero() {
        try {
            val hz = Actions.currentHz(this)
            heroHz?.text = if (hz > 0) "$hz" else "--"
            val sg = ShizukuHelper.granted()
            heroShz?.text = if (sg) "ON" else "OFF"
            heroShz?.setTextColor(if (sg) OK else BAD)
            heroSvc?.text = if (LiveState.serviceRunning) "ON" else "OFF"
            heroSvc?.setTextColor(if (LiveState.serviceRunning) OK else BAD)
        } catch (e: Throwable) { }
    }

    private fun buildFooter(col: LinearLayout) {
        val f = LinearLayout(this)
        f.orientation = LinearLayout.VERTICAL
        f.gravity = Gravity.CENTER_HORIZONTAL
        f.setPadding(dp(8), dp(22), dp(8), dp(6))
        val line = View(this)
        line.setBackgroundColor(0x5500C8FF)
        f.addView(line, LinearLayout.LayoutParams(dp(120), dp(1)))
        text(f, "© 2026 HEZPOR & LONG SUPRA", 12f, ACC, true, 12).apply {
            gravity = Gravity.CENTER; letterSpacing = 0.12f; setShadowLayer(10f, 0f, 0f, ACC)
        }
        text(f, "Bản quyền thuộc Hezpor & Long Supra.\nMọi quyền được bảo lưu.", 10.5f, DIM, false, 4).apply {
            gravity = Gravity.CENTER
        }
        col.addView(f, lp(8))
    }

    private fun buildServiceCard(col: LinearLayout) {
        val c = card(col, "DỊCH VỤ NỀN")
        svcSwitch = switchRow(c, "Bật dịch vụ nền", K.SERVICE_ON, false) { on ->
            if (on) MouseService.start(this) else MouseService.stop(this)
        }
        switchRow(c, "Tự chạy khi mở máy", K.BOOT_ON, true)
        switchRow(c, "Giữ CPU thức", K.WAKE_ON, true)
        switchRow(c, "Âm thanh video nền", K.SOUND_ON, true) { applyVolume() }
    }

    private fun buildBubbleCard(col: LinearLayout) {
        val c = card(col, "BÓNG NỔI & MENU NHANH")
        val bubSw = switchRow(c, "Hiện bóng nổi", K.BUBBLE_ON, true) { checkOverlay(it) }
        slider(c, "Cỡ bóng", K.BUB_SIZE, 36f, 80f, 2f, 52f, "%.0f")
        slider(c, "Độ đậm bóng", K.BUB_ALPHA, 30f, 100f, 5f, 90f, "%.0f")
        button(c, "Mở menu", 12) {
            if (!Settings.canDrawOverlays(this)) {
                toast("Cần cấp quyền Lớp phủ")
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                ensureService()
                MouseService.openMenu(this)
            }
        }
        button(c, "Đặt lại vị trí") {
            Prefs.sp(this).edit().remove(K.BUB_X).remove(K.BUB_Y).apply()
            if (bubSw.isChecked) {
                bubSw.isChecked = false
                ui.postDelayed({ bubSw.isChecked = true }, 400)
            }
            toast("Đã đặt lại vị trí bóng")
        }
    }

    private fun buildPermissionCard(col: LinearLayout) {
        val c = card(col, "QUYỀN")
        for ((k, _) in listOf(
            "shizuku" to "Shizuku", "overlay" to "Lớp phủ", "write" to "Ghi cài đặt hệ thống",
            "secure" to "WRITE_SECURE_SETTINGS", "notif" to "Thông báo", "battery" to "Bỏ tối ưu pin",
            "service" to "Dịch vụ nền"
        )) {
            statusViews[k] = text(c, "", 13f, TXT, false, 4)
        }
        button(c, "Cấp quyền Shizuku") {
            if (!ShizukuHelper.available()) {
                val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                if (i != null) startActivity(i) else toast("Chưa cài Shizuku hoặc Shizuku chưa chạy. Cài Shizuku rồi Start.")
            } else if (!ShizukuHelper.granted()) {
                ShizukuHelper.request(100)
            } else toast("Đã có quyền Shizuku")
        }
        button(c, "Cấp tất cả quyền (Shizuku)") { grantAll() }
        button(c, "Lớp phủ") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        button(c, "Ghi cài đặt hệ thống") {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        }
        button(c, "Thông báo") {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
            else startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        }
        button(c, "Bỏ tối ưu pin") {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Throwable) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        button(c, "Cài đặt ứng dụng") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
    }

    private fun buildHzCard(col: LinearLayout) {
        val c = card(col, "ĐO HZ CHUỘT")
        tvHz = text(c, "-- Hz", 44f, ACC, true, 6)
        tvStats = text(c, "Max: -- | Trung bình: --", 13f, DIM)
        tvHzSys = text(c, "Toàn hệ thống: --", 13f, TXT, false, 6)

        pad = PadView(this)
        c.addView(pad, LinearLayout.LayoutParams(MATCH, dp(190)).apply { topMargin = dp(10) })
        pad.onHz = { hz ->
            if (hz > 0) {
                hzMax = max(hzMax, hz)
                hzSum += hz
                hzCnt++
                tvHz.text = "$hz Hz"
                tvStats.text = "Max: $hzMax Hz | Trung bình: ${hzSum / hzCnt} Hz"
            }
        }
        button(c, "Reset thống kê") {
            hzMax = 0; hzSum = 0; hzCnt = 0
            tvHz.text = "-- Hz"; tvStats.text = "Max: -- | Trung bình: --"
            pad.clearAll()
        }
        switchRow(c, "Đo Hz TOÀN HỆ THỐNG ngoài app (Shizuku)", K.SYS_HZ_ON, false) {
            if (it && !ShizukuHelper.granted()) toast("Cần cấp quyền Shizuku trước")
            if (it) ensureService()
        }
        switchRow(c, "Hiện Hz nổi (HUD) trên mọi ứng dụng", K.HUD_ON, false) {
            if (it && !Settings.canDrawOverlays(this)) {
                toast("Cần cấp quyền Lớp phủ")
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
            if (it) ensureService()
        }
    }

    private fun buildSpeedCard(col: LinearLayout) {
        val c = card(col, "TỐC ĐỘ CON TRỎ")
        val cur = Sys.getPointerSpeed(this)
        if (!Prefs.sp(this).contains(K.SPEED_VAL)) Prefs.setFloat(this, K.SPEED_VAL, cur.toFloat())
        speedSl = slider(c, "Tốc độ", K.SPEED_VAL, -7f, 7f, 1f, cur.toFloat(), "%.0f") { v ->
            applySpeed(v.roundToInt())
        }
        button(c, "Áp dụng lại ngay") { applySpeed(Prefs.getFloat(this, K.SPEED_VAL, 0f).roundToInt()) }
        button(c, "Về mặc định (0)") {
            Prefs.setFloat(this, K.SPEED_VAL, 0f); speedSl.set(0f); applySpeed(0)
        }
        switchRow(c, "KHÓA tốc độ (dịch vụ nền tự đặt lại nếu bị đổi)", K.SPEED_LOCK, false) {
            if (it) { ensureService(); applySpeed(Prefs.getFloat(this, K.SPEED_VAL, 0f).roundToInt()) }
        }
    }

    private fun applySpeed(v: Int) {
        Thread {
            val ok = Sys.setPointerSpeed(this, v)
            ui.post { if (!ok) toast("Không ghi được. Cấp 'Ghi cài đặt hệ thống' hoặc Shizuku.") }
        }.start()
    }

    private fun onTuningChanged() {
        pad.reload()
        curve.tuning = Tuning.load(this)
        curve.invalidate()
        val t = Tuning.load(this)
        tvMap.text = "→ Tốc độ hệ thống tương đương: ${t.systemSpeed()}  (DPI ${t.refDpi.roundToInt()}/${t.curDpi.roundToInt()}, gain×${String.format(Locale.US, "%.2f", t.gain(20f))})"
    }

    private fun buildTuningCard(col: LinearLayout) {
        val c = card(col, "ĐIỀU KHIỂN CHUỘT")
        curve = CurveView(this)
        c.addView(curve, LinearLayout.LayoutParams(MATCH, dp(130)).apply { topMargin = dp(10) })
        tvMap = text(c, "", 12f, TXT, false, 8)

        val f = { _: Float -> onTuningChanged() }
        text(c, "TINH CHỈNH CỐT LÕI", 13f, ACC, true, 12)
        slider(c, "Làm mượt nhanh – EMA (ms)", K.EMA, 0.5f, 20f, 0.5f, 2f, "%.1f", f)
        slider(c, "Cửa sổ vận tốc", K.VELWIN, 1f, 16f, 1f, 4f, "%.0f", f)
        slider(c, "Ngưỡng cử động nhỏ", K.MICRO, 0f, 10f, 1f, 2f, "%.0f", f)
        slider(c, "Gia tốc", K.ACCEL, 0f, 0.2f, 0.01f, 0.04f, "%.2f", f)
        slider(c, "Ngưỡng bắt đầu tăng tốc", K.ACCEL_OFF, 0f, 10f, 0.25f, 3f, "%.2f", f)
        slider(c, "Giới hạn gia tốc", K.ACCEL_CAP, 1f, 3f, 0.05f, 1.4f, "%.2f", f)
        slider(c, "DPI chuẩn", K.REF_DPI, 400f, 3200f, 50f, 800f, "%.0f", f)
        slider(c, "DPI hiện tại", K.CUR_DPI, 400f, 3200f, 50f, 800f, "%.0f", f)
        slider(c, "Vùng chết chống run tay", K.TREMOR_DZ, 0f, 10f, 0.5f, 1f, "%.1f", f)
        slider(c, "Hệ số giảm rung dọc", K.VDAMP_F, 0.3f, 1f, 0.05f, 1f, "%.2f", f)

        val g = { _: Boolean -> onTuningChanged() }
        text(c, "BỘ LỌC", 13f, ACC, true, 14)
        switchRow(c, "Ổn định chuyển động", K.F_MOTION, true, g)
        switchRow(c, "Chống vọt quá đà", K.F_OVERSHOOT, false, g)
        switchRow(c, "Khởi động nhanh", K.F_QUICK, true, g)
        switchRow(c, "Chuyển tiếp mượt", K.F_SMOOTH, true, g)
        switchRow(c, "Giảm rung chiều dọc", K.F_VDAMP, false, g)
        switchRow(c, "Cổng chống run tay", K.F_TREMOR, false, g)
        switchRow(c, "Hỗ trợ hướng", K.F_DIRASSIST, false, g)

        button(c, "Áp dụng vào tốc độ hệ thống (từ DPI + đường cong)") {
            val s = Tuning.load(this).systemSpeed()
            Prefs.setFloat(this, K.SPEED_VAL, s.toFloat())
            speedSl.set(s.toFloat())
            applySpeed(s)
            toast("Đã đặt tốc độ hệ thống = $s")
        }
        onTuningChanged()
    }


    // ---------------- Tool Mouse ----------------

    private fun nmdChanged() {
        if (!::nmdPad.isInitialized) return
        val c = NmdCfg.load(this)
        nmdPad.reload()
        nmdCurve.cfg = c
        nmdCurve.invalidate()
    }

    private fun nmdSetPreset(vel: Int, base: Float, fast: Float, str: Float, off: Float, cap: Float, bypass: Boolean) {
        Prefs.setBool(this, K.N_BYPASS, bypass)
        val m = mapOf(
            K.N_VELWIN to vel.toFloat(), K.N_BASE_A to base, K.N_FAST_A to fast,
            K.N_STRENGTH to str, K.N_OFFSET to off, K.N_CAP to cap
        )
        for ((k, v) in m) {
            Prefs.setFloat(this, k, v)
            nmdSl[k]?.set(v)
        }
        nmdBypassSw?.isChecked = bypass
        nmdChanged()
    }

    private var nmdBypassSw: Switch? = null

    private val nmdTickR = object : Runnable {
        override fun run() {
            if (isDestroyed || isFinishing) return
            if (::nmdPad.isInitialized && nmdPad.isShown) {
                val f = nmdPad.filter
                val c = nmdPad.filter.c
                nmdCurve.liveVel = f.vel
                nmdCurve.invalidate()
                val sysFresh = System.currentTimeMillis() - LiveState.sysHzTime < 1500
                val padHz = nmdPad.hz
                val rate = if (padHz > 0) padHz else if (sysFresh) LiveState.sysHz else 0
                nmdRate?.text = "Tần số báo cáo (đo được): " + (if (rate > 0) "$rate Hz" else "-- Hz") +
                    "   |   Trình điều khiển: " + (if (ShizukuHelper.granted()) "Shizuku getevent" else "Android MotionEvent")
                nmdMon?.text = String.format(
                    Locale.US,
                    "Thô (X/Y): %.0f / %.0f\nĐầu ra (X/Y): %.2f / %.2f\nVận tốc hiển thị: %.2f px/ms\nHệ số làm mượt: %.2f\nHệ số đường cong: %.2fx\nTrạng thái nắn: %s\nGói/giây (vào/ra/gộp): %d / %d / %d",
                    f.rawX, f.rawY, f.outX, f.outY, f.dispVel, f.alpha, f.gain, f.snapState,
                    f.ppsIn, f.ppsOut, f.ppsDrop
                )
                if (c.bypass) nmdMon?.append("\n(đang bỏ qua bộ lọc)")
            }
            ui.postDelayed(this, 150)
        }
    }

    private fun buildNmdCard(col: LinearLayout) {
        val c = card(col, "TOOL MOUSE")
        text(c, "Luồng xử lý: THÔ → LÀM MƯỢT → ĐƯỜNG CONG → ĐẦU RA → NẮN THẲNG", 12f, ACC, true, 6)
        text(c, "Khung test bên dưới áp dụng đủ cả 5 bước. Công tắc \"toàn hệ thống\" ở cuối áp dụng đường cong lên tốc độ con trỏ thật khi chạy nền.", 11f, DIM, false, 4)

        nmdCurve = NmdCurveView(this)
        nmdPad = NmdPadView(this)
        nmdSl.clear()
        val g = { _: Float -> nmdChanged() }

        fun sl(label: String, key: String, mn: Float, mx: Float, st: Float, def: Float, fmt: String) {
            nmdSl[key] = slider(c, label, key, mn, mx, st, def, fmt, g)
        }

        // Presets
        text(c, "CẤU HÌNH SẴN", 13f, ACC, true, 12)
        Ui(this).chips(c, listOf("BỎ QUA LỌC", "KIỂM SOÁT", "THEO DÕI", "MẠNH"), -1) { i ->
            when (i) {
                0 -> nmdSetPreset(4, 1f, 1f, 0f, 5f, 1f, true)
                1 -> nmdSetPreset(6, 0.7f, 0.95f, 0.03f, 6f, 1.3f, false)
                2 -> nmdSetPreset(4, 0.85f, 1f, 0.05f, 5f, 1.5f, false)
                else -> nmdSetPreset(3, 0.95f, 1f, 0.09f, 3f, 2.0f, false)
            }
            toast("Đã chọn: " + listOf("BỎ QUA LỌC", "KIỂM SOÁT", "THEO DÕI", "MẠNH")[i])
        }
        nmdBypassSw = switchRow(c, "BỎ QUA LỌC (tắt hết bộ lọc, chuột nguyên bản)", K.N_BYPASS, false) { nmdChanged() }

        // Adaptive EMA
        text(c, "LÀM MƯỢT THÍCH ỨNG", 13f, ACC, true, 14)
        sl("Cửa sổ vận tốc (số điểm)", K.N_VELWIN, 1f, 16f, 1f, 4f, "%.0f")
        sl("Độ mượt khi rê chậm", K.N_BASE_A, 0.05f, 1f, 0.05f, 0.85f, "%.2f")
        sl("Độ mượt khi vung nhanh", K.N_FAST_A, 0.05f, 1f, 0.05f, 1.0f, "%.2f")

        // Response curve
        text(c, "ĐƯỜNG CONG PHẢN HỒI (TỰ NHIÊN)", 13f, ACC, true, 14)
        sl("Độ mạnh đường cong", K.N_STRENGTH, 0f, 0.2f, 0.005f, 0.05f, "%.3f")
        sl("Ngưỡng bắt đầu tăng tốc", K.N_OFFSET, 0f, 20f, 0.5f, 5f, "%.1f")
        sl("Mức tăng tối đa", K.N_CAP, 1f, 3f, 0.05f, 1.5f, "%.2fx")
        c.addView(nmdCurve, LinearLayout.LayoutParams(MATCH, dp(130)).apply { topMargin = dp(10) })

        // Device calibration
        text(c, "HIỆU CHỈNH THIẾT BỊ", 13f, ACC, true, 14)
        val dpis = listOf(400, 800, 1200, 1600, 2400, 3200)
        val curDpi = Prefs.getFloat(this, K.N_DPI, 800f).roundToInt()
        text(c, "DPI chuột", 12f, DIM, false, 6)
        Ui(this).chips(c, dpis.map { it.toString() }, dpis.indexOf(curDpi)) { i ->
            Prefs.setFloat(this, K.N_DPI, dpis[i].toFloat())
            toast("DPI = ${dpis[i]}")
            nmdChanged()
        }
        nmdRate = text(c, "Tần số báo cáo (đo được): -- Hz", 12f, TXT, false, 8)
        sl("Gộp tín hiệu rung (ms)", K.N_JITTER, 0f, 8f, 0.25f, 1f, "%.2f")

        // Micro protection
        text(c, "BẢO VỆ CỬ ĐỘNG NHỎ", 13f, ACC, true, 14)
        sl("Ngưỡng (counts)", K.N_MICRO, 0f, 5f, 0.1f, 0f, "%.1f")

        // Snap
        text(c, "NẮN THẲNG ĐƯỜNG KÉO", 13f, ACC, true, 14)
        switchRow(c, "Bật nắn thẳng theo góc", K.N_SNAP_ON, false) { nmdChanged() }
        text(c, "Chế độ nắn", 12f, DIM, false, 6)
        Ui(this).chips(c, listOf("Lượng tử hóa (8 hướng)", "Lượng tử hóa (16 hướng)"), Prefs.getInt(this, K.N_SNAP_MODE, 0)) { i ->
            Prefs.setInt(this, K.N_SNAP_MODE, i)
            nmdChanged()
        }
        sl("Làm mượt hướng", K.N_DIR_A, 0.05f, 1f, 0.05f, 0.65f, "%.2f")
        sl("Ngưỡng góc (°)", K.N_SNAP_TH, 0f, 15f, 0.5f, 4f, "%.1f°")
        sl("Độ mạnh nắn", K.N_SNAP_STR, 0f, 1f, 0.05f, 0.75f, "%.2f")

        // Live monitor + khung test
        text(c, "THEO DÕI TRỰC TIẾP", 13f, ACC, true, 14)
        nmdMon = text(c, "", 12f, TXT, false, 6)
        c.addView(nmdPad, LinearLayout.LayoutParams(MATCH, dp(190)).apply { topMargin = dp(10) })
        button(c, "Reset khung test") { nmdPad.clearAll() }

        // Áp dụng ngoài app
        text(c, "ÁP DỤNG NGOÀI APP", 13f, ACC, true, 14)
        switchRow(c, "Đường cong Tool Mouse lên tốc độ chuột TOÀN HỆ THỐNG (chạy nền, cần Shizuku)", K.NMD_DYN, false) {
            if (it && !ShizukuHelper.granted()) toast("Cần cấp quyền Shizuku trước")
            if (it) ensureService()
        }
        text(c, "Dịch vụ nền đọc chuyển động chuột thật rồi đổi tốc độ con trỏ liên tục theo EMA + đường cong + DPI. Bật mục này thì \"KHÓA tốc độ\" tạm bị bỏ qua. Chỉ có Curve/EMA/DPI/Micro tác dụng ngoài app; Snap và Jitter chỉ có trong khung test vì Android không cho app sửa từng điểm di chuyển của chuột.", 11f, DIM, false, 4)
        button(c, "Áp dụng một lần vào tốc độ hệ thống") {
            val sp = NmdCfg.load(this).systemSpeed()
            Prefs.setFloat(this, K.SPEED_VAL, sp.toFloat())
            if (::speedSl.isInitialized) speedSl.set(sp.toFloat())
            applySpeed(sp)
            toast("Đã đặt tốc độ hệ thống = $sp")
        }

        nmdPad.reload()
        ui.removeCallbacks(nmdTickR)
        ui.post(nmdTickR)
    }

    private fun buildSystemCard(col: LinearLayout) {
        val c = card(col, "TIỆN ÍCH HỆ THỐNG")
        switchRow(c, "Hiện vị trí con trỏ / tọa độ (Pointer location)", K.POINTER_LOC, false) {
            toggleSystem("system", "pointer_location", it)
        }
        switchRow(c, "Hiện điểm chạm (Show touches)", K.SHOW_TOUCH, false) {
            toggleSystem("system", "show_touches", it)
        }
        switchRow(c, "Con trỏ chuột to (Large pointer icon)", K.BIG_POINTER, false) {
            toggleSystem("secure", "accessibility_large_pointer_icon", it)
        }
    }

    private fun toggleSystem(table: String, key: String, on: Boolean) {
        Thread {
            val ok = Sys.putInt(this, table, key, if (on) 1 else 0)
            ui.post { if (!ok) toast("Cần quyền Shizuku hoặc 'Ghi cài đặt hệ thống' (nhấn nút cấp quyền)") }
        }.start()
    }


    // ---------------- Optimizer ----------------

    private val flowSwitches = ArrayList<Switch>()
    private val flowKeys = Actions.flowKeys

    private fun flowCmd(key: String, on: Boolean): String = Actions.flowCmd(key, on)

    private fun flowItem(c: LinearLayout, title: String, tag: String, desc: String, trade: String, key: String) {
        text(c, title, 15f, Color.WHITE, true, 16)
        text(c, "[$tag]", 12f, 0xFFFF8A80.toInt(), true, 2)
        text(c, desc, 12f, DIM, false, 2)
        text(c, "Đánh đổi: $trade", 12f, 0xFFFFB4A8.toInt(), false, 2)
        flowSwitches.add(switchRow(c, "Chọn", key, false))
    }

    private fun buildFlowCard(col: LinearLayout) {
        val c = card(col, "TỐI ƯU HIỆU NĂNG")
        text(c, "⚠ Cảnh báo nhiệt độ: ép phần cứng hoạt động hết công suất, máy sẽ ấm hơn, nên có quạt tản nhiệt.", 12f, 0xFFFFD54F.toInt(), false, 8)
        flowItem(c, "⚡ Mở khóa hiệu năng tối đa (High Perf)", "Nóng máy",
            "Ép CPU & GPU chạy xung cao, tắt tiết kiệm pin hãng.",
            "Máy nóng nhanh hơn, hao thêm pin. (Cần Android 12+; máy không hỗ trợ sẽ bỏ qua.)", K.FL_PERF)
        flowItem(c, "📷 Tạm dừng Camera & Ghi màn hình", "Giải phóng RAM",
            "Dừng và treo app camera / ghi màn hình để dồn RAM chơi game.",
            "Không mở được Camera khi đang bật. Tắt công tắc rồi bấm Kích hoạt (hoặc Mặc định) để mở lại.", K.FL_CAM)
        flowItem(c, "🎮 Ép GPU render (Disable HW Overlays)", "Nóng GPU",
            "GPU gánh việc dựng hình thay vì overlay phần cứng.",
            "GPU chạy liên tục nên ấm hơn, tốn pin game 3D. Mất hiệu lực sau khi khởi động lại.", K.FL_GPU)
        flowItem(c, "❄ Bỏ qua bóp xung nhiệt độ (Thermal Override)", "Cân nhắc",
            "Ngăn hệ thống tự động hạ xung CPU/GPU khi máy ấm lên.",
            "Nguy cơ nóng máy cao. Chỉ dùng khi có tản nhiệt và theo dõi nhiệt độ.", K.FL_THERMAL)
        flowItem(c, "✨ Giảm hoạt ảnh hệ thống (0.5x)", "Mượt hơn",
            "Giảm thời gian animation cửa sổ/chuyển cảnh để thao tác nhanh hơn.",
            "Không đáng kể; tắt công tắc để về 1.0x.", K.FL_ANIM)

        button(c, "🚀 KÍCH HOẠT OPTIMIZER", 16) {
            if (!ShizukuHelper.granted()) {
                toast("Cần cấp quyền Shizuku trước")
            } else {
                Thread {
                    for (k in flowKeys) ShizukuHelper.exec(flowCmd(k, Prefs.getBool(this, k, false)), 20)
                    ui.post { toast("Đã áp dụng theo các công tắc") }
                }.start()
            }
        }
        button(c, "↩ Mặc định (tắt hết)") {
            for (sw in flowSwitches) sw.isChecked = false
            if (!ShizukuHelper.granted()) {
                toast("Cần cấp quyền Shizuku trước")
            } else {
                Thread {
                    for (k in flowKeys) ShizukuHelper.exec(flowCmd(k, false), 20)
                    ui.post { toast("Đã khôi phục mặc định") }
                }.start()
            }
        }
    }

    // ---------------- Độ phân giải & DPI ----------------

    private lateinit var etW: EditText
    private lateinit var etH: EditText
    private lateinit var etD: EditText
    private lateinit var tvDisp: TextView
    private var gfxPanel: GfxPanel? = null
    private var heroHz: TextView? = null
    private var heroShz: TextView? = null
    private var heroSvc: TextView? = null
    private var logoAnim: android.animation.ValueAnimator? = null
    private var physW = 0
    private var physH = 0
    private var physD = 0
    private var curW = 0
    private var curH = 0
    private var curD = 0

    private fun numEdit(parent: LinearLayout, label: String): EditText {
        text(parent, label, 12f, DIM, false, 8)
        val e = EditText(this)
        e.inputType = InputType.TYPE_CLASS_NUMBER
        e.setTextColor(TXT)
        e.setHintTextColor(DIM)
        e.textSize = 15f
        e.background = roundBg(0xFF050C24.toInt(), 10, 0x5500C8FF)
        e.setPadding(dp(12), dp(8), dp(12), dp(8))
        parent.addView(e, lp(2))
        return e
    }

    private fun loadDisplay() {
        Thread {
            val dm = resources.displayMetrics
            var pw = dm.widthPixels; var ph = dm.heightPixels; var pd = dm.densityDpi
            var cw = pw; var ch = ph; var cd = pd
            val so = ShizukuHelper.exec("wm size")
            val dn = ShizukuHelper.exec("wm density")
            if (so != null) {
                Regex("""Physical size: (\d+)x(\d+)""").find(so)?.let {
                    pw = it.groupValues[1].toInt(); ph = it.groupValues[2].toInt(); cw = pw; ch = ph
                }
                Regex("""Override size: (\d+)x(\d+)""").find(so)?.let {
                    cw = it.groupValues[1].toInt(); ch = it.groupValues[2].toInt()
                }
            }
            if (dn != null) {
                Regex("""Physical density: (\d+)""").find(dn)?.let { pd = it.groupValues[1].toInt(); cd = pd }
                Regex("""Override density: (\d+)""").find(dn)?.let { cd = it.groupValues[1].toInt() }
            }
            ui.post {
                physW = pw; physH = ph; physD = pd; curW = cw; curH = ch; curD = cd
                tvDisp.text = "Hiện tại: ${cw}x$ch • ${cd} dpi   |   Gốc: ${pw}x$ph • ${pd} dpi"
                if (etW.text.isNullOrEmpty()) { etW.setText("$cw"); etH.setText("$ch"); etD.setText("$cd") }
            }
        }.start()
    }

    private fun buildDisplayCard(col: LinearLayout) {
        val c = card(col, "PHÂN GIẢI & DPI")
        tvDisp = text(c, "Đang đọc…", 12f, TXT, false, 8)
        etW = numEdit(c, "Chiều rộng (px)")
        etH = numEdit(c, "Chiều cao (px)")
        etD = numEdit(c, "DPI (mật độ)")

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (pct in listOf(100, 85, 75, 60)) {
            val b = Button(this)
            b.text = "$pct%"
            b.isAllCaps = false
            b.setTextColor(Color.BLACK)
            b.textSize = 12f
            b.setPadding(0, 0, 0, 0)
            b.background = roundBg(ACC, 10)
            b.setOnClickListener {
                if (physW > 0) {
                    etW.setText("${(physW * pct / 100 / 2) * 2}")
                    etH.setText("${(physH * pct / 100 / 2) * 2}")
                    etD.setText("${physD * pct / 100}")
                }
            }
            row.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(4) })
        }
        c.addView(row, lp(10))

        button(c, "Áp dụng độ phân giải + DPI", 10) { applyDisplay() }
        button(c, "Khôi phục gốc") {
            if (!ShizukuHelper.granted()) toast("Cần cấp quyền Shizuku trước")
            else Thread {
                ShizukuHelper.exec("wm size reset; wm density reset")
                ui.post { etW.setText(""); loadDisplay(); toast("Đã khôi phục độ phân giải gốc") }
            }.start()
        }
        text(c, "CẤU HÌNH ĐÃ LƯU", 13f, ACC, true, 14)
        button(c, "💾 Lưu cấu hình hiện tại (đặt tên)", 6) { profileDialog(null) }
        resList = LinearLayout(this)
        resList.orientation = LinearLayout.VERTICAL
        c.addView(resList, lp(6))
        refreshResList()
        loadDisplay()
    }

    private fun refreshResList() {
        resList.removeAllViews()
        for (p in ResStore.load(this)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            val tv = TextView(this)
            tv.text = p.name + "\n" + p.w + "x" + p.h + " • " + p.d + " dpi"
            tv.setTextColor(TXT)
            tv.textSize = 14f
            tv.setPadding(dp(10), dp(8), dp(10), dp(8))
            tv.background = roundBg(0xFF050C24.toInt(), 10, 0x5500C8FF)
            tv.setOnClickListener {
                etW.setText("${p.w}"); etH.setText("${p.h}"); etD.setText("${p.d}")
                applyDisplay()
            }
            row.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
            val ed = Button(this)
            ed.text = "Sửa"
            ed.isAllCaps = false
            ed.setOnClickListener { profileDialog(p) }
            row.addView(ed, LinearLayout.LayoutParams(WRAP, WRAP))
            val del = Button(this)
            del.text = "Xóa"
            del.isAllCaps = false
            del.setOnClickListener {
                ResStore.save(this, ResStore.load(this).filter { it.id != p.id })
                refreshResList()
            }
            row.addView(del, LinearLayout.LayoutParams(WRAP, WRAP))
            resList.addView(row, lp(6))
        }
    }

    private fun dlgField(parent: LinearLayout, label: String, value: String, number: Boolean): EditText {
        text(parent, label, 12f, DIM, false, 8)
        val e = EditText(this)
        e.setText(value)
        e.setTextColor(TXT)
        if (number) e.inputType = InputType.TYPE_CLASS_NUMBER
        parent.addView(e, lp(2))
        return e
    }

    private fun profileDialog(p: ResProfile?) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(12), dp(20), dp(8))
        val w0 = p?.w ?: etW.text.toString().toIntOrNull() ?: curW
        val h0 = p?.h ?: etH.text.toString().toIntOrNull() ?: curH
        val d0 = p?.d ?: etD.text.toString().toIntOrNull() ?: curD
        val en = dlgField(box, "Tên cấu hình", p?.name ?: "", false)
        val ew = dlgField(box, "Chiều rộng (px)", "$w0", true)
        val eh = dlgField(box, "Chiều cao (px)", "$h0", true)
        val ed = dlgField(box, "DPI", "$d0", true)
        val sc = ScrollView(this)
        sc.addView(box)
        AlertDialog.Builder(this)
            .setTitle(if (p == null) "Lưu cấu hình mới" else "Sửa cấu hình")
            .setView(sc)
            .setPositiveButton("Lưu") { _, _ ->
                val w = ew.text.toString().toIntOrNull()
                val h = eh.text.toString().toIntOrNull()
                val d = ed.text.toString().toIntOrNull()
                if (w == null || h == null || d == null || w !in 200..8000 || h !in 200..8000 || d !in 100..1000) {
                    toast("Giá trị không hợp lệ (rộng/cao 200–8000, DPI 100–1000)")
                } else {
                    val name = en.text.toString().trim().ifEmpty { "${w}x$h • ${d}dpi" }
                    val list = ResStore.load(this).toMutableList()
                    if (p == null) {
                        list.add(ResProfile(System.currentTimeMillis(), name, w, h, d))
                    } else {
                        val i = list.indexOfFirst { it.id == p.id }
                        if (i >= 0) list[i] = p.copy(name = name, w = w, h = h, d = d)
                    }
                    ResStore.save(this, list)
                    refreshResList()
                }
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun applyDisplay() {
        if (!ShizukuHelper.granted()) { toast("Cần cấp quyền Shizuku trước"); return }
        val w = etW.text.toString().toIntOrNull()
        val h = etH.text.toString().toIntOrNull()
        val d = etD.text.toString().toIntOrNull()
        if (w == null || h == null || d == null || w !in 200..8000 || h !in 200..8000 || d !in 100..1000) {
            toast("Giá trị không hợp lệ (rộng/cao 200–8000, DPI 100–1000)")
            return
        }
        Thread {
            ShizukuHelper.exec("wm size ${w}x$h; wm density $d")
            ui.post { loadDisplay(); toast("Đã áp dụng ${w}x$h • $d dpi") }
        }.start()
    }


    // ---------------- Tần số quét ----------------

    private fun supportedHz(): List<Int> = try {
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.supportedModes.map { it.refreshRate.roundToInt() }.distinct().sorted()
    } catch (e: Throwable) { emptyList() }

    private fun refreshInfo(): String {
        val cur = try {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.refreshRate.roundToInt()
        } catch (e: Throwable) { 0 }
        val sup = supportedHz()
        return "Hiện tại: $cur Hz  |  Máy hỗ trợ: " + (if (sup.isEmpty()) "không rõ" else sup.joinToString(", ") { "$it" } + " Hz")
    }

    private fun setHz(hz: Int) {
        Prefs.setFloat(this, K.HZ_VAL, hz.toFloat())
        val sup = supportedHz()
        if (sup.isNotEmpty() && hz !in sup) toast("Máy không báo hỗ trợ ${hz}Hz, vẫn thử áp dụng")
        Thread {
            val ok = Sys.setRefresh(this, hz)
            ui.post { toast(if (ok) "Đã ép $hz Hz" else "Cần quyền Shizuku hoặc 'Ghi cài đặt hệ thống'") }
        }.start()
    }

    private fun buildRefreshCard(col: LinearLayout) {
        val c = card(col, "TẦN SỐ QUÉT MÀN HÌNH (Hz)")
        tvRefresh = text(c, refreshInfo(), 12f, TXT, false, 8)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (hz in listOf(60, 90, 120, 144)) {
            val b = Button(this)
            b.text = "$hz"
            b.isAllCaps = false
            b.textSize = 13f
            b.setPadding(0, 0, 0, 0)
            b.setTextColor(Color.BLACK)
            b.background = roundBg(ACC, 10)
            b.setOnClickListener { setHz(hz) }
            row.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(4) })
        }
        c.addView(row, lp(10))
        button(c, "Tự động (bỏ ép Hz)") {
            val max = supportedHz().maxOrNull() ?: 120
            Thread {
                val ok = Sys.clearRefresh(this, max)
                ui.post { toast(if (ok) "Đã trả về tự động" else "Cần quyền Shizuku hoặc 'Ghi cài đặt hệ thống'") }
            }.start()
        }
        switchRow(c, "KHÓA Hz (dịch vụ nền tự ép lại nếu hệ thống đổi)", K.HZ_LOCK, false) {
            if (it) {
                ensureService()
                val v = Prefs.getFloat(this, K.HZ_VAL, 0f).roundToInt()
                if (v > 0) setHz(v)
            }
        }
    }


    // ---------------- FPS nổi & Văn bản nổi ----------------

    private fun checkOverlay(on: Boolean) {
        if (!on) return
        if (!Settings.canDrawOverlays(this)) {
            toast("Cần cấp quyền Lớp phủ")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        ensureService()
    }

    private fun colorPicker(parent: LinearLayout, onChange: (Int) -> Unit) {
        val sv = HorizontalScrollView(this)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (cl in NEON) {
            val v = View(this)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(cl)
            g.setStroke(dp(1), 0x88FFFFFF.toInt())
            v.background = g
            v.setOnClickListener { onChange(cl) }
            val lpv = LinearLayout.LayoutParams(dp(36), dp(36))
            lpv.marginEnd = dp(8)
            row.addView(v, lpv)
        }
        sv.addView(row)
        parent.addView(sv, lp(8))

        text(parent, "Màu tùy chỉnh (kéo thanh màu)", 12f, DIM, false, 10)
        val sb = SeekBar(this)
        sb.max = 360
        val rainbow = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(
                0xFFFF0000.toInt(), 0xFFFFFF00.toInt(), 0xFF00FF00.toInt(),
                0xFF00FFFF.toInt(), 0xFF0000FF.toInt(), 0xFFFF00FF.toInt(), 0xFFFF0000.toInt()
            )
        )
        rainbow.cornerRadius = dp(4).toFloat()
        rainbow.setSize(0, dp(8))
        sb.progressDrawable = rainbow
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) onChange(Color.HSVToColor(floatArrayOf(p.toFloat(), 1f, 1f)))
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(sb, lp(2))

        val hexRow = LinearLayout(this)
        hexRow.orientation = LinearLayout.HORIZONTAL
        val hex = EditText(this)
        hex.hint = "#RRGGBB"
        hex.setTextColor(TXT)
        hex.setHintTextColor(DIM)
        hex.textSize = 14f
        hexRow.addView(hex, LinearLayout.LayoutParams(0, WRAP, 1f))
        val ok = Button(this)
        ok.text = "Dùng mã"
        ok.isAllCaps = false
        ok.setOnClickListener {
            try {
                var t = hex.text.toString().trim()
                if (!t.startsWith("#")) t = "#$t"
                onChange(Color.parseColor(t))
            } catch (e: Throwable) { toast("Mã màu không hợp lệ") }
        }
        hexRow.addView(ok, LinearLayout.LayoutParams(WRAP, WRAP))
        parent.addView(hexRow, lp(4))
    }

    private fun buildFpsCard(col: LinearLayout) {
        val c = card(col, "FPS")
        fpsSw = switchRow(c, "Hiện FPS", K.FPS_ON, false) { checkOverlay(it) }
        switchRow(c, "🔒 Khóa chỉnh sửa", K.FPS_LOCK, true)
        val st = FpsStore.load(this)
        val panel = StylePanel(this)
        panel.build(c, st, 8, 48, { FpsStore.save(this, st) }, "Dòng") { box ->
            FpsUi.build(this, panel, box, {}) {
                Prefs.setInt(this, K.FPS_X, 0)
                Prefs.setInt(this, K.FPS_Y, 0)
                toast("Đã về góc dưới trái")
            }
        }
        button(c, "✎ Chỉnh trực tiếp trên màn hình", 14) {
            Prefs.setBool(this, K.FPS_LOCK, false)
            Prefs.setBool(this, K.FPS_ON, true)
            checkOverlay(true)
            toast("Chạm FPS để chỉnh, kéo để di chuyển")
        }
    }

    private lateinit var textList: LinearLayout

    private fun buildTextCard(col: LinearLayout) {
        val c = card(col, "VĂN BẢN NỔI")
        switchRow(c, "Hiện văn bản", K.TEXT_ON, false) { checkOverlay(it) }
        switchRow(c, "🔒 Khóa chỉnh sửa", K.TEXT_LOCK, false)
        textList = LinearLayout(this)
        textList.orientation = LinearLayout.VERTICAL
        c.addView(textList, lp(8))
        button(c, "＋ Thêm văn bản", 10) { editTextDialog(null) }
        refreshTextList()
    }

    private fun refreshTextList() {
        textList.removeAllViews()
        for (item in TextStore.load(this)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(12), dp(8), dp(8), dp(8))
            row.background = roundBg(0xFF0A1230.toInt(), 12, 0x4400C8FF)
            val tv = TextView(this)
            tv.text = item.text
            tv.maxLines = 1
            Fx.apply(tv, item.st.copy(size = 16f), System.currentTimeMillis())
            tv.textSize = 16f
            tv.typeface = Typeface.DEFAULT_BOLD
            tv.setOnClickListener { editTextDialog(item) }
            row.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
            val del = TextView(this)
            del.text = "✕"
            del.textSize = 16f
            del.setTextColor(DIM)
            del.setPadding(dp(12), dp(4), dp(12), dp(4))
            del.setOnClickListener {
                TextStore.save(this, TextStore.load(this).filter { it.id != item.id })
                refreshTextList()
            }
            row.addView(del, LinearLayout.LayoutParams(WRAP, WRAP))
            textList.addView(row, lp(6))
        }
    }

    private fun editTextDialog(item: TextItem?) {
        val st = item?.st?.copy() ?: TextStore.newStyle()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18), dp(14), dp(18), dp(8))

        val et = EditText(this)
        et.hint = "Nội dung"
        et.setText(item?.text ?: "")
        et.setTextColor(TXT)
        et.setHintTextColor(DIM)
        box.addView(et, lp(0))

        val prevBox = FrameLayout(this)
        prevBox.background = roundBg(0xFF182038.toInt(), 12)
        prevBox.setPadding(dp(8), dp(14), dp(8), dp(14))
        val preview = TextView(this)
        preview.gravity = Gravity.CENTER
        prevBox.addView(preview, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        box.addView(prevBox, lp(10))
        val upd = {
            preview.text = if (et.text.isNullOrEmpty()) "Xem trước" else et.text.toString()
            Fx.style(preview, st, resources.displayMetrics.density, System.currentTimeMillis())
        }
        upd()
        et.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) { upd() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        // Xem trước chạy hiệu ứng động
        val anim = object : Runnable {
            override fun run() {
                if (Fx.animated(st.fx)) Fx.apply(preview, st, System.currentTimeMillis())
                ui.postDelayed(this, 50)
            }
        }
        ui.post(anim)

        StylePanel(this).build(box, st, 10, 80, { upd() })

        val scroll = ScrollView(this)
        scroll.addView(box)
        val dlg = AlertDialog.Builder(this)
            .setView(scroll)
            .setPositiveButton("Lưu") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isEmpty()) {
                    toast("Chưa nhập nội dung")
                } else {
                    val list = TextStore.load(this).toMutableList()
                    if (item == null) {
                        list.add(TextItem(System.currentTimeMillis(), t, dp(40), dp(160) + list.size * dp(56), st.copy()))
                    } else {
                        val i = list.indexOfFirst { it.id == item.id }
                        if (i >= 0) list[i] = item.copy(text = t, st = st.copy())
                    }
                    TextStore.save(this, list)
                    refreshTextList()
                    if (Prefs.getBool(this, K.TEXT_ON, false)) ensureService()
                }
            }
            .setNegativeButton("Hủy", null)
            .setOnDismissListener { ui.removeCallbacks(anim) }
            .create()
        dlg.window?.setBackgroundDrawable(roundBg(0xFF070D26.toInt(), 20, 0xAA00C8FF.toInt()))
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(ACC)
        dlg.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(DIM)
    }

    // ---------------- RENDERING GRAPHICS ----------------

    private fun buildGfxCard(col: LinearLayout) {
        val c = card(col, "ĐỒ HỌA RENDER")
        val gp = GfxPanel(this, Ui(this))
        gfxPanel = gp
        gp.build(c, false)
    }

    private fun buildNotesCard(col: LinearLayout) {
        val c = card(col, "GHI CHÚ")
        text(
            c,
            "• Bóng nổi: bật ở tab Tổng quan, cần quyền Lớp phủ. Chạm bóng để mở menu, 'Thu gọn' hoặc chạm ra ngoài để đóng.\n" +
            "• Shizuku mất khi khởi động lại máy: mở Shizuku và Start lại (Android 11+ dùng Wireless debugging).\n" +
            "• Đã cấp WRITE_SECURE_SETTINGS / Ghi cài đặt thì tốc độ chuột vẫn ghi được kể cả khi Shizuku tắt.\n" +
            "• Xiaomi/Oppo/Vivo/Samsung: bật Tự khởi động, bỏ tối ưu pin, khóa app ở màn hình đa nhiệm.\n" +
            "• Cách khác cấp quyền không cần Shizuku (qua máy tính):\n" +
            "  adb shell pm grant com.hezpor.mousetool android.permission.WRITE_SECURE_SETTINGS",
            12f, DIM, false, 6
        )
    }

    // ---------------- permission logic ----------------

    private fun ensureService() {
        if (!Prefs.getBool(this, K.SERVICE_ON, false)) {
            Prefs.setBool(this, K.SERVICE_ON, true)
            svcSwitch.isChecked = true
        }
    }

    private fun grantAll() {
        if (!ShizukuHelper.granted()) {
            toast("Hãy cấp quyền Shizuku trước (nút 1)")
            return
        }
        val p = packageName
        Thread {
            val cmds = listOf(
                "pm grant $p android.permission.WRITE_SECURE_SETTINGS",
                "pm grant $p android.permission.POST_NOTIFICATIONS",
                "appops set $p WRITE_SETTINGS allow",
                "appops set $p SYSTEM_ALERT_WINDOW allow",
                "appops set $p RUN_IN_BACKGROUND allow",
                "appops set $p RUN_ANY_IN_BACKGROUND allow",
                "cmd deviceidle whitelist +$p"
            )
            val out = ShizukuHelper.exec(cmds.joinToString("; "))
            ui.post {
                toast(if (out == null) "Không chạy được lệnh Shizuku" else "Đã gửi lệnh cấp quyền")
                refreshStatus()
            }
        }.start()
    }

    private fun setStatus(key: String, label: String, ok: Boolean, detail: String) {
        val tv = statusViews[key] ?: return
        tv.text = "● $label: $detail"
        tv.setTextColor(if (ok) OK else BAD)
    }

    private fun refreshStatus() {
        val sAvail = ShizukuHelper.available()
        val sGrant = ShizukuHelper.granted()
        setStatus(
            "shizuku", "Shizuku", sGrant,
            if (sGrant) "đã cấp quyền" else if (sAvail) "đang chạy, chưa cấp quyền" else "chưa chạy"
        )
        val ov = Settings.canDrawOverlays(this)
        setStatus("overlay", "Lớp phủ", ov, if (ov) "đã bật" else "chưa cấp")
        val ws = Settings.System.canWrite(this)
        setStatus("write", "Ghi cài đặt hệ thống", ws, if (ws) "đã cấp" else "chưa cấp (có thể dùng Shizuku)")
        val sec = checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED
        setStatus("secure", "WRITE_SECURE_SETTINGS", sec, if (sec) "đã cấp" else "chưa cấp")
        val nt = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        setStatus("notif", "Thông báo", nt, if (nt) "đã cấp" else "chưa cấp")
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val bt = pm.isIgnoringBatteryOptimizations(packageName)
        setStatus("battery", "Bỏ tối ưu pin", bt, if (bt) "đã bỏ" else "chưa")
        setStatus("service", "Dịch vụ nền", LiveState.serviceRunning, if (LiveState.serviceRunning) "đang chạy" else "đang tắt")
    }
}
