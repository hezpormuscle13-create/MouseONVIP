package com.hezpor.mousetool

import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.TextView
import kotlin.math.sin

/** Toàn bộ kiểu hiển thị của một dòng chữ nổi (FPS hoặc văn bản). */
data class StyleSpec(
    var color: Int = 0xFF00C8FF.toInt(),
    var size: Float = 16f,
    var fx: Int = Fx.NEON,
    var fxSpeed: Int = 50,
    var bgOn: Boolean = true,
    var bgPct: Int = 70,
    var bgColor: Int = 0xFF000000.toInt(),
    var bold: Boolean = true,
    var italic: Boolean = false,
    var mono: Boolean = false,
    var spacing: Int = 4,      // 0..40  (x0.01 em)
    var glow: Int = 14,        // 0..40  (bán kính phát sáng)
    var alpha: Int = 100,      // 20..100 (%)
    var rot: Int = 0,          // -90..90 (độ)
    var radius: Int = 10,      // 0..30  (dp, bo góc nền)
    var border: Int = 0        // 0..6   (dp, viền theo màu chữ)
)

/** Hiệu ứng chữ + áp kiểu lên TextView, dùng chung cho FPS, văn bản và xem thử. */
object Fx {
    const val NONE = 0
    const val NEON = 1
    const val RAINBOW = 2
    const val PULSE = 3
    const val BLINK = 4
    const val GRADIENT = 5

    val NAMES = listOf("Tắt", "Neon", "Cầu vồng", "Nhịp", "Nháy", "Chuyển màu")

    fun animated(fx: Int) = fx == RAINBOW || fx == PULSE || fx == BLINK || fx == GRADIENT

    /** Màu + bóng sáng + độ mờ theo thời gian t (ms). Không đụng tới bố cục. */
    fun apply(tv: TextView, st: StyleSpec, t: Long) {
        val sp = st.fxSpeed.coerceIn(1, 100)
        val g = st.glow.toFloat()
        val base = st.color
        val a0 = st.alpha.coerceIn(20, 100) / 100f
        tv.paint.shader = null
        tv.alpha = a0
        when (st.fx) {
            NONE -> {
                tv.setTextColor(base)
                tv.setShadowLayer(if (g > 0f) g else 0.01f, 0f, 0f, if (g > 0f) base else 0)
            }
            NEON -> {
                tv.setTextColor(base)
                tv.setShadowLayer(if (g > 0f) g else 0.01f, 0f, 0f, if (g > 0f) base else 0)
            }
            RAINBOW -> {
                val c = Color.HSVToColor(floatArrayOf(((t * sp / 40L) % 360L).toFloat(), 1f, 1f))
                tv.setTextColor(c)
                tv.setShadowLayer(if (g > 0f) g else 0.01f, 0f, 0f, if (g > 0f) c else 0)
            }
            PULSE -> {
                val ph = 0.5f + 0.5f * sin(t * sp / 8000.0 * Math.PI * 2).toFloat()
                tv.setTextColor(base)
                tv.setShadowLayer(2f + (g + 4f) * ph, 0f, 0f, base)
                tv.alpha = a0 * (0.75f + 0.25f * ph)
            }
            BLINK -> {
                val period = (2200L - sp * 20L).coerceAtLeast(150L)
                tv.setTextColor(base)
                tv.setShadowLayer(if (g > 0f) g * 0.85f else 0.01f, 0f, 0f, if (g > 0f) base else 0)
                tv.alpha = a0 * (if ((t % period) < period / 2) 1f else 0.15f)
            }
            GRADIENT -> {
                val w = tv.width.toFloat().coerceAtLeast(60f)
                val hsv = FloatArray(3)
                Color.colorToHSV(base, hsv)
                val c2 = Color.HSVToColor(floatArrayOf((hsv[0] + 140f) % 360f, 1f, 1f))
                val grad = LinearGradient(0f, 0f, w, 0f, intArrayOf(base, c2, base), null, Shader.TileMode.MIRROR)
                val m = Matrix()
                m.setTranslate(((t * sp / 30L) % (w * 2).toLong()).toFloat(), 0f)
                grad.setLocalMatrix(m)
                tv.paint.shader = grad
                tv.setShadowLayer(if (g > 0f) g * 0.7f else 0.01f, 0f, 0f, if (g > 0f) base else 0)
            }
        }
        tv.invalidate()
    }

    fun font(tv: TextView, st: StyleSpec) {
        tv.textSize = st.size
        val face = if (st.mono) Typeface.MONOSPACE else Typeface.DEFAULT
        val sty = when {
            st.bold && st.italic -> Typeface.BOLD_ITALIC
            st.bold -> Typeface.BOLD
            st.italic -> Typeface.ITALIC
            else -> Typeface.NORMAL
        }
        tv.typeface = Typeface.create(face, sty)
        tv.letterSpacing = st.spacing / 100f
    }

    fun bg(st: StyleSpec, dens: Float, editMode: Boolean, corners: FloatArray?): GradientDrawable {
        val bg = GradientDrawable()
        val a = (st.bgPct.coerceIn(0, 100) * 255 / 100)
        bg.setColor(if (st.bgOn) Color.argb(a, Color.red(st.bgColor), Color.green(st.bgColor), Color.blue(st.bgColor)) else 0)
        if (corners != null) bg.cornerRadii = corners else bg.cornerRadius = st.radius * dens
        if (st.border > 0) bg.setStroke((st.border * dens).toInt().coerceAtLeast(1), st.color)
        else if (editMode) bg.setStroke(dens.toInt().coerceAtLeast(1), 0xFF00C8FF.toInt(), 4 * dens, 3 * dens)
        return bg
    }

    /** Áp toàn bộ kiểu (cỡ, kiểu chữ, nền, xoay...) rồi chạy hiệu ứng. */
    fun style(
        tv: TextView, st: StyleSpec, dens: Float, t: Long,
        editMode: Boolean = false, corners: FloatArray? = null
    ) {
        font(tv, st)
        tv.rotation = st.rot.toFloat()
        tv.background = bg(st, dens, editMode, corners)
        apply(tv, st, t)
    }
}
