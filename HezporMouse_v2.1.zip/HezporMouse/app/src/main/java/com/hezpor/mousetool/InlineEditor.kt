package com.hezpor.mousetool

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Bảng chỉnh nổi trên màn hình: hiện khi chạm vào FPS / văn bản lúc chưa khóa.
 * Dùng StylePanel (tab Chữ • Màu • Hiệu ứng • Nền) + nút Khóa / Xóa / Xong.
 */
class InlineEditor(private val ctx: Context, private val wm: WindowManager) {
    private val dens = ctx.resources.displayMetrics.density
    private fun dp(v: Int) = (v * dens).toInt()
    private var root: FrameLayout? = null

    fun isOpen() = root != null

    fun close() {
        root?.let { try { wm.removeView(it) } catch (e: Throwable) { } }
        root = null
    }

    private fun round(color: Int, r: Int, stroke: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        if (stroke != 0) g.setStroke(dp(1), stroke)
        return g
    }

    private fun btn(text: String, color: Int, onClick: () -> Unit): TextView {
        val b = TextView(ctx)
        b.text = text
        b.textSize = 13f
        b.gravity = Gravity.CENTER
        b.typeface = Typeface.DEFAULT_BOLD
        b.setTextColor(0xFFFFFFFF.toInt())
        b.background = round(color, 12)
        b.setPadding(dp(8), dp(10), dp(8), dp(10))
        b.setOnClickListener { onClick() }
        return b
    }

    fun show(
        title: String,
        spec: StyleSpec,
        minSize: Int,
        maxSize: Int,
        text: String?,
        extraTitle: String?,
        extra: ((LinearLayout) -> Unit)?,
        onText: ((String) -> Unit)?,
        onChange: () -> Unit,
        onLock: () -> Unit,
        onDelete: (() -> Unit)?
    ) {
        close()
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(14), dp(12), dp(14), dp(14))

        val head = TextView(ctx)
        head.text = title
        head.textSize = 15f
        head.setTextColor(Th.ACC)
        head.typeface = Typeface.DEFAULT_BOLD
        box.addView(head, LinearLayout.LayoutParams(-1, -2))

        if (text != null) {
            val et = EditText(ctx)
            et.setText(text)
            et.setTextColor(Th.TXT)
            et.textSize = 15f
            et.addTextChangedListener(object : android.text.TextWatcher {
                override fun afterTextChanged(s: android.text.Editable?) { onText?.invoke(s?.toString() ?: "") }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
            box.addView(et, LinearLayout.LayoutParams(-1, -2))
        }

        StylePanel(ctx).build(box, spec, minSize, maxSize, onChange, extraTitle, extra)

        val btns = LinearLayout(ctx)
        btns.orientation = LinearLayout.HORIZONTAL
        fun bp() = LinearLayout.LayoutParams(0, -2, 1f).also { it.marginEnd = dp(6) }
        btns.addView(btn("🔒 Khóa", 0xFF0055CC.toInt()) { close(); onLock() }, bp())
        if (onDelete != null) btns.addView(btn("Xóa", 0xFF3A1030.toInt()) { close(); onDelete() }, bp())
        btns.addView(btn("Xong", 0xFF00A8E8.toInt()) { close() }, bp())
        box.addView(btns, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(14) })

        val scroll = ScrollView(ctx)
        scroll.addView(box)
        val frame = FrameLayout(ctx)
        frame.background = round(0xF2070D26.toInt(), 20, 0xAA00C8FF.toInt())
        frame.addView(scroll, FrameLayout.LayoutParams(-1, -2))

        val dm = ctx.resources.displayMetrics
        val w = minOf((dm.widthPixels * 0.92f).toInt(), dp(360))
        val h = (dm.heightPixels * 0.7f).toInt()
        var flags = WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (text == null) flags = flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        val lp = WindowManager.LayoutParams(
            w, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.CENTER
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        lp.height = minOf(h, dp(440))
        try {
            wm.addView(frame, lp)
            root = frame
        } catch (e: Throwable) { }
    }
}
