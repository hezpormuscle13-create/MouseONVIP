package com.hezpor.mousetool

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import kotlin.math.roundToInt

/** Hình xem trước: Low Texture (mịn, nét) và Low Pixel (vỡ hạt, phân giải thấp). */
class GfxPreview(ctx: Context, private val pixel: Boolean) : View(ctx) {
    private val p = Paint()
    private val p2 = Paint()
    private var small: Bitmap? = null

    private fun scene(c: Canvas, w: Float, h: Float) {
        p.shader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(0xFF8A6A55.toInt(), 0xFFD9822B.toInt(), 0xFF7A3E12.toInt()),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        p.color = 0xFF6F7378.toInt()
        c.drawRect(w * 0.08f, h * 0.18f, w * 0.30f, h * 0.45f, p)
        c.drawRect(w * 0.66f, h * 0.30f, w * 0.92f, h * 0.45f, p)
        p.color = 0xFF1B1B1F.toInt()
        c.drawRect(w * 0.47f, h * 0.22f, w * 0.51f, h * 0.68f, p)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        small = null
        if (pixel && w > 0 && h > 0) {
            val sw = (w / 9).coerceAtLeast(4)
            val sh = (h / 9).coerceAtLeast(4)
            val b = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
            scene(Canvas(b), sw.toFloat(), sh.toFloat())
            small = b
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val b = small
        if (pixel && b != null) {
            p2.isFilterBitmap = false
            c.drawBitmap(b, null, RectF(0f, 0f, w, h), p2)
        } else {
            scene(c, w, h)
        }
    }
}

/**
 * Bảng "ĐỒ HỌA RENDER": ANGLE + Low Texture / Low Pixel + độ phân giải render + tùy biến sâu.
 * Dùng chung cho app chính và menu nổi.
 */
class GfxPanel(private val ctx: Context, private val ui: Ui) {

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private var host: LinearLayout? = null
    private var showTitle = true
    private var picker = false
    private var checked = false
    private var checking = false
    private var angleSup: Boolean? = null
    private var driver = 0

    private fun toast(s: String) {
        try { Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show() } catch (e: Throwable) { }
    }

    private fun work(rebuild: Boolean = false, job: () -> String?) {
        try {
            io.execute {
                val m = try { job() } catch (e: Throwable) { "Lỗi: " + (e.message ?: "không rõ") }
                main.post {
                    if (m != null) toast(m)
                    if (rebuild) render()
                }
            }
        } catch (e: Throwable) { }
    }

    fun shutdown() {
        try { io.shutdownNow() } catch (e: Throwable) { }
    }

    fun build(parent: LinearLayout, withTitle: Boolean = true) {
        showTitle = withTitle
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        parent.addView(box, ui.lp(0))
        host = box
        render()
    }

    private fun goldTitle(c: LinearLayout, s: String, top: Int = 0) {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val bar = View(ctx)
        bar.setBackgroundColor(Th.GOLD)
        row.addView(bar, LinearLayout.LayoutParams(ui.dp(3), ui.dp(14)))
        val t = TextView(ctx)
        t.text = s.uppercase()
        t.textSize = 12f
        t.setTextColor(Th.GOLD)
        t.typeface = Typeface.DEFAULT_BOLD
        t.letterSpacing = 0.15f
        t.setPadding(ui.dp(8), 0, 0, 0)
        row.addView(t, LinearLayout.LayoutParams(WRAP, WRAP))
        c.addView(row, ui.lp(top))
    }

    private fun setGame(pkg: String, label: String) {
        Prefs.sp(ctx).edit().putString(K.GFX_PKG, pkg).putString(K.GFX_LABEL, label).apply()
        checked = false
        driver = 0
    }

    private fun setMode(m: Int, pkg: String) {
        Prefs.setInt(ctx, K.GFX_MODE, m)
        work(true) { Gfx.applyGame(ctx, pkg) }
    }

    private fun detect() {
        work(true) {
            val p = Gfx.foreground() ?: return@work "Không đọc được game đang mở (cần Shizuku)"
            if (p == ctx.packageName) return@work "Đang ở app Hezpor – hãy mở game rồi bấm lại"
            val pm = ctx.packageManager
            val lb = try { pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString() } catch (e: Throwable) { p }
            setGame(p, lb)
            "Đã chọn: $lb"
        }
    }

    private fun presetCard(name: String, desc: String, pixel: Boolean, selected: Boolean, onClick: () -> Unit): LinearLayout {
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(ui.dp(7), ui.dp(7), ui.dp(7), ui.dp(9))
        card.background = ui.round(0xFF101428.toInt(), 14, if (selected) Th.GOLD else 0x33FFFFFF, if (selected) 2 else 1)
        val pv = GfxPreview(ctx, pixel)
        pv.clipToOutline = true
        pv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, ui.dp(10).toFloat()) }
        }
        card.addView(pv, LinearLayout.LayoutParams(MATCH, ui.dp(66)))
        ui.text(card, name, 13.5f, if (selected) Th.GOLD else Th.TXT, true, 7)
        ui.text(card, desc, 10.5f, Th.DIM, false, 1)
        card.setOnClickListener { onClick() }
        return card
    }

    private fun goldSwitchTint(sw: Switch) {
        val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(st, intArrayOf(Th.GOLD, 0xFFB0B0B8.toInt()))
        sw.trackTintList = ColorStateList(st, intArrayOf(0x66FFC52E, 0x55888890))
    }

    @Suppress("DEPRECATION")
    private fun pickerList(c: LinearLayout) {
        val pm = ctx.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0).map { r ->
            val ai = r.activityInfo.applicationInfo
            val game = ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            Triple(r.activityInfo.packageName, r.loadLabel(pm).toString(), game)
        }.distinctBy { it.first }
            .filter { it.first != ctx.packageName }
            .sortedWith(compareBy<Triple<String, String, Boolean>>({ !it.third }, { it.second.lowercase() }))
        ui.text(c, "Chọn game (game xếp trước)", 12f, Th.TXT, true, 12)
        ui.button(c, "✕ Đóng", false, 6) { picker = false; render() }
        if (apps.isEmpty()) ui.text(c, "Không liệt kê được ứng dụng", 12f, Th.DIM, false, 8)
        for (a in apps) {
            val t = TextView(ctx)
            t.text = (if (a.third) "🎮  " else "     ") + a.second
            t.textSize = 13f
            t.setTextColor(if (a.third) Th.GOLD else Th.TXT)
            t.setPadding(ui.dp(12), ui.dp(10), ui.dp(12), ui.dp(10))
            t.background = ui.round(Th.CARD2, 10)
            t.setOnClickListener {
                setGame(a.first, a.second)
                picker = false
                render()
            }
            c.addView(t, ui.lp(6))
        }
    }

    private fun render() {
        val c = host ?: return
        c.removeAllViews()
        val sp = Prefs.sp(ctx)
        val pkg = sp.getString(K.GFX_PKG, "") ?: ""
        val label = sp.getString(K.GFX_LABEL, "") ?: ""

        if (ShizukuHelper.granted() && !checked && !checking) {
            checking = true
            work(true) {
                angleSup = Gfx.angleSupported()
                driver = if (pkg.isEmpty()) 0 else Gfx.angleMode(pkg)
                checked = true
                checking = false
                null
            }
        }

        if (showTitle) goldTitle(c, "Rendering Graphics")

        // ---- game áp dụng
        ui.text(c, "Game áp dụng: " + (if (label.isEmpty()) "chưa chọn" else label), 12.5f, Th.TXT, true, if (showTitle) 10 else 4)
        val rb = LinearLayout(ctx)
        rb.orientation = LinearLayout.HORIZONTAL
        val l1 = LinearLayout.LayoutParams(0, WRAP, 1f)
        l1.marginEnd = ui.dp(6)
        ui.button(rb, "🎮 Chọn game", false, 0, l1) { picker = !picker; render() }
        ui.button(rb, "📍 Game đang mở", false, 0, LinearLayout.LayoutParams(0, WRAP, 1f)) { detect() }
        c.addView(rb, ui.lp(8))
        if (picker) { pickerList(c); return }

        // ---- ANGLE
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(ui.dp(12), ui.dp(10), ui.dp(10), ui.dp(10))
        row.background = ui.round(Th.CARD2, 12)
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        ui.text(col, "Render bằng ANGLE", 14f, Th.TXT, true, 0)
        val sup = angleSup
        val st: String
        val sc: Int
        if (!ShizukuHelper.granted()) { st = "Cần cấp quyền Shizuku"; sc = Th.BAD }
        else if (sup == null) { st = "Đang kiểm tra…"; sc = Th.DIM }
        else if (sup) { st = "Máy hỗ trợ ANGLE"; sc = Th.OK }
        else { st = "Máy không hỗ trợ ANGLE"; sc = Th.BAD }
        ui.text(col, st, 11f, sc, false, 0)
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        val sw = Switch(ctx)
        goldSwitchTint(sw)
        sw.isChecked = driver == 1
        sw.isEnabled = sup == true
        sw.setOnCheckedChangeListener { _, on ->
            if (pkg.isEmpty()) {
                toast("Hãy chọn game trước")
                main.post { render() }
            } else {
                work(true) {
                    Gfx.setAngleMode(pkg, if (on) 1 else 0)
                    driver = if (on) 1 else 0
                    if (on) "ANGLE BẬT • mở lại game để có hiệu lực" else "ANGLE TẮT • mở lại game để có hiệu lực"
                }
            }
        }
        row.addView(sw, LinearLayout.LayoutParams(WRAP, WRAP))
        c.addView(row, ui.lp(10))

        // ---- Low Texture / Low Pixel
        val mode = Prefs.getInt(ctx, K.GFX_MODE, 0)
        val pr = LinearLayout(ctx)
        pr.orientation = LinearLayout.HORIZONTAL
        val pl = LinearLayout.LayoutParams(0, WRAP, 1f)
        pl.marginEnd = ui.dp(8)
        pr.addView(presetCard("Low Texture", "Giữ độ phân giải gốc, hình nét", false, mode == 0) { setMode(0, pkg) }, pl)
        pr.addView(presetCard("Low Pixel", "Hạ độ phân giải, render nhẹ hơn", true, mode == 1) { setMode(1, pkg) }, LinearLayout.LayoutParams(0, WRAP, 1f))
        c.addView(pr, ui.lp(12))

        // ---- độ phân giải render
        ui.text(c, "Độ phân giải render", 13f, Th.TXT, true, 14)
        val pct = Prefs.getFloat(ctx, K.GFX_SCALE, 70f).roundToInt().coerceIn(30, 100)
        val shown = if (mode == 1) pct else 100
        val readout = TextView(ctx)
        readout.textSize = 12f
        readout.setTextColor(Th.GOLD)
        readout.typeface = Typeface.DEFAULT_BOLD
        readout.gravity = Gravity.CENTER
        fun showPct(v: Int) { readout.text = if (v >= 100) "Gốc" else "$v%" }
        showPct(shown)
        val sb = SeekBar(ctx)
        sb.max = 14
        sb.progress = (100 - shown) / 5
        sb.progressTintList = ColorStateList.valueOf(Th.GOLD)
        sb.thumbTintList = ColorStateList.valueOf(Th.GOLD)
        sb.progressBackgroundTintList = ColorStateList.valueOf(0x44FFFFFF)
        sb.isEnabled = mode == 1
        sb.alpha = if (mode == 1) 1f else 0.45f
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = 100 - p * 5
                showPct(v)
                if (fromUser) Prefs.setFloat(ctx, K.GFX_SCALE, v.toFloat())
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { work { Gfx.applyGame(ctx, pkg) } }
        })
        c.addView(sb, ui.lp(4))
        val lab = LinearLayout(ctx)
        lab.orientation = LinearLayout.HORIZONTAL
        val a1 = TextView(ctx); a1.text = "Gốc"; a1.textSize = 10.5f; a1.setTextColor(Th.GOLD)
        val a3 = TextView(ctx); a3.text = "30%"; a3.textSize = 10.5f; a3.setTextColor(Th.DIM); a3.gravity = Gravity.END
        lab.addView(a1, LinearLayout.LayoutParams(0, WRAP, 1f))
        lab.addView(readout, LinearLayout.LayoutParams(0, WRAP, 1f))
        lab.addView(a3, LinearLayout.LayoutParams(0, WRAP, 1f))
        c.addView(lab, ui.lp(0))
        val steps = listOf(100, 80, 70, 60, 50, 40)
        val names = steps.map { if (it >= 100) "Gốc" else "$it%" }
        ui.chips(c, names, if (mode == 1) steps.indexOf(pct) else 0) { i ->
            if (steps[i] >= 100) {
                Prefs.setInt(ctx, K.GFX_MODE, 0)
            } else {
                Prefs.setInt(ctx, K.GFX_MODE, 1)
                Prefs.setFloat(ctx, K.GFX_SCALE, steps[i].toFloat())
            }
            work(true) { Gfx.applyGame(ctx, pkg) }
        }
        ui.text(c, "Cần mở lại game để đồ họa mới có hiệu lực.", 11.5f, Th.DIM, false, 8)

        // ---- tùy biến sâu
        goldTitle(c, "Tùy biến sâu", 16)
        ui.text(c, "Driver đồ họa của game", 12f, Th.TXT, true, 10)
        ui.chips(c, listOf("Mặc định", "ANGLE", "Native"), driver) { i ->
            if (pkg.isEmpty()) { toast("Hãy chọn game trước") } else {
                work(true) {
                    val ok = Gfx.setAngleMode(pkg, i)
                    driver = i
                    if (ok) "Đã đặt driver • mở lại game" else "Cần cấp quyền Shizuku"
                }
            }
        }
        ui.text(c, "Chế độ game (Game Mode)", 12f, Th.TXT, true, 12)
        ui.chips(c, listOf("Chuẩn", "Hiệu năng", "Pin"), Prefs.getInt(ctx, K.GFX_GMODE, 2).coerceIn(1, 3) - 1) { i ->
            Prefs.setInt(ctx, K.GFX_GMODE, i + 1)
            work(true) { Gfx.applyGame(ctx, pkg) }
        }
        ui.text(c, "Giới hạn FPS của game", 12f, Th.TXT, true, 12)
        val fpsList = listOf(0, 30, 45, 60, 90, 120)
        ui.chips(c, fpsList.map { if (it == 0) "Giữ" else "$it" }, fpsList.indexOf(Prefs.getInt(ctx, K.GFX_FPS, 0)).coerceAtLeast(0)) { i ->
            Prefs.setInt(ctx, K.GFX_FPS, fpsList[i])
            work(true) { Gfx.applyGame(ctx, pkg) }
        }
        ui.toggle(c, "ANGLE cho mọi ứng dụng", "Có thể gây lỗi một số app, mở lại app để có hiệu lực", K.GFX_ALL, false) { on ->
            work {
                if (!ShizukuHelper.granted()) "Cần cấp quyền Shizuku" else { Gfx.setAngleAll(on); if (on) "ANGLE bật cho mọi app" else "Đã tắt ANGLE toàn bộ" }
            }
        }
        val rb2 = LinearLayout(ctx)
        rb2.orientation = LinearLayout.HORIZONTAL
        val m1 = LinearLayout.LayoutParams(0, WRAP, 1f)
        m1.marginEnd = ui.dp(6)
        ui.button(rb2, "↻ Mở lại game", true, 0, m1) { work { Gfx.restartGame(pkg) } }
        ui.button(rb2, "↩ Mặc định game", false, 0, LinearLayout.LayoutParams(0, WRAP, 1f)) {
            Prefs.setInt(ctx, K.GFX_MODE, 0)
            Prefs.setInt(ctx, K.GFX_FPS, 0)
            Prefs.setInt(ctx, K.GFX_GMODE, 2)
            work(true) { Gfx.resetGame(pkg) }
        }
        c.addView(rb2, ui.lp(12))
    }
}
