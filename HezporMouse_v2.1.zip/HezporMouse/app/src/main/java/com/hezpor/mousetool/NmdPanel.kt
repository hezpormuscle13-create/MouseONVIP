package com.hezpor.mousetool

import android.content.Context
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import java.util.Locale
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** Cấu hình Tool Mouse: thô → làm mượt → đường cong → đầu ra → nắn thẳng. */
data class NmdCfg(
    val velWin: Int, val baseA: Float, val fastA: Float,
    val strength: Float, val offset: Float, val cap: Float,
    val dpi: Float, val jitter: Float, val micro: Float,
    val snapOn: Boolean, val snap16: Boolean,
    val dirA: Float, val snapTh: Float, val snapStr: Float,
    val bypass: Boolean
) {
    fun gain(v: Float): Float = min(cap, 1f + strength * max(0f, v - offset))

    fun dpiRatio(): Float = if (dpi <= 0f) 1f else 800f / dpi

    /** Android: scale = 2^(speed/4)  =>  speed = 4*log2(gain). */
    fun speedFor(v: Float): Int {
        val g = (if (bypass) 1f else gain(v)) * dpiRatio()
        val s = 4.0 * ln(max(g, 0.05f).toDouble()) / ln(2.0)
        return s.roundToInt().coerceIn(-7, 7)
    }

    fun systemSpeed(): Int = speedFor(20f)

    companion object {
        fun load(c: Context) = NmdCfg(
            Prefs.getFloat(c, K.N_VELWIN, 4f).roundToInt(),
            Prefs.getFloat(c, K.N_BASE_A, 0.85f),
            Prefs.getFloat(c, K.N_FAST_A, 1.0f),
            Prefs.getFloat(c, K.N_STRENGTH, 0.05f),
            Prefs.getFloat(c, K.N_OFFSET, 5f),
            Prefs.getFloat(c, K.N_CAP, 1.5f),
            Prefs.getFloat(c, K.N_DPI, 800f),
            Prefs.getFloat(c, K.N_JITTER, 1f),
            Prefs.getFloat(c, K.N_MICRO, 0f),
            Prefs.getBool(c, K.N_SNAP_ON, false),
            Prefs.getInt(c, K.N_SNAP_MODE, 0) == 1,
            Prefs.getFloat(c, K.N_DIR_A, 0.65f),
            Prefs.getFloat(c, K.N_SNAP_TH, 4f),
            Prefs.getFloat(c, K.N_SNAP_STR, 0.75f),
            Prefs.getBool(c, K.N_BYPASS, false)
        )
    }
}

/** Bộ lọc Tool Mouse: thô → gộp rung → bảo vệ cử động nhỏ → làm mượt thích ứng → đường cong → nắn thẳng. Dùng trong khung test. */
class NmdFilter(var c: NmdCfg) {
    private val win = ArrayDeque<FloatArray>()
    private var lastOutT = 0.0
    private var ax = 0f
    private var ay = 0f
    private var mx = 0f
    private var my = 0f
    private var ex = 0f
    private var ey = 0f
    private var dirX = 0f
    private var dirY = 0f
    private var locked = false
    private var lockAng = 0f
    private var secStart = 0L
    private var cIn = 0
    private var cOut = 0
    private var cDrop = 0

    @Volatile var rawX = 0f
    @Volatile var rawY = 0f
    @Volatile var outX = 0f
    @Volatile var outY = 0f
    @Volatile var vel = 0f
    @Volatile var dispVel = 0f
    @Volatile var alpha = 1f
    @Volatile var gain = 1f
    @Volatile var snapState = "TẮT"
    @Volatile var lockAngle = Float.NaN
    @Volatile var ppsIn = 0
    @Volatile var ppsOut = 0
    @Volatile var ppsDrop = 0

    fun reset() {
        clearState()
        lastOutT = 0.0
        locked = false
        lockAngle = Float.NaN
    }

    private fun clearState() {
        win.clear()
        ax = 0f; ay = 0f; mx = 0f; my = 0f; ex = 0f; ey = 0f
        dirX = 0f; dirY = 0f
        locked = false
        lockAngle = Float.NaN
    }

    private fun angDiff(a: Float, b: Float): Float {
        var d = (a - b) % 360f
        if (d > 180f) d -= 360f
        if (d < -180f) d += 360f
        return d
    }

    private fun tickSec() {
        val now = SystemClock.elapsedRealtime()
        if (secStart == 0L) secStart = now
        if (now - secStart >= 1000L) {
            ppsIn = cIn; ppsOut = cOut; ppsDrop = cDrop
            cIn = 0; cOut = 0; cDrop = 0
            secStart = now
        }
    }

    fun apply(dx: Float, dy: Float, tMs: Double): FloatArray {
        val cfg = c
        tickSec()
        cIn++
        rawX = dx; rawY = dy

        if (cfg.bypass) {
            outX = dx; outY = dy
            alpha = 1f; gain = 1f; vel = hypot(dx, dy); dispVel = vel
            snapState = "BỎ QUA"
            cOut++
            return floatArrayOf(dx, dy)
        }

        val gap = if (lastOutT <= 0.0) 1000.0 else tMs - lastOutT
        val first = gap > 40.0
        if (first) clearState()

        // Jitter: gộp các sự kiện đến sớm hơn "jitter" ms (không mất chuyển động, chỉ gộp lại)
        if (cfg.jitter > 0f && !first && gap < cfg.jitter) {
            ax += dx; ay += dy
            cDrop++
            return floatArrayOf(0f, 0f)
        }
        val ix = dx + ax
        val iy = dy + ay
        ax = 0f; ay = 0f
        val dt = if (first) 1f else gap.toFloat().coerceIn(0.25f, 40f)
        lastOutT = tMs

        // Vận tốc (cửa sổ N điểm)
        win.addLast(floatArrayOf(ix, iy, dt))
        while (win.size > cfg.velWin.coerceAtLeast(1)) win.removeFirst()
        var sx = 0f
        var sy = 0f
        var st = 0f
        for (w in win) { sx += w[0]; sy += w[1]; st += w[2] }
        val v = hypot(sx, sy) / max(st, 0.25f)

        // Micro protection
        var px = ix
        var py = iy
        if (cfg.micro > 0f) {
            mx += px; my += py
            if (hypot(mx, my) < cfg.micro) {
                px = 0f; py = 0f
            } else {
                px = mx; py = my; mx = 0f; my = 0f
            }
        }

        // Adaptive EMA: chậm -> base alpha, nhanh -> fast alpha
        val vn = (v / 20f).coerceIn(0f, 1f)
        val a = (cfg.baseA + (cfg.fastA - cfg.baseA) * vn).coerceIn(0.02f, 1f)
        ex += a * (px - ex)
        ey += a * (py - ey)

        // Response curve
        val g = cfg.gain(v)
        val k = g * cfg.dpiRatio()
        var ox = ex * k
        var oy = ey * k

        // Line stabilized snap
        if (cfg.snapOn) {
            val sp = hypot(ox, oy)
            if (sp > 0.3f) {
                dirX += cfg.dirA * (ox / sp - dirX)
                dirY += cfg.dirA * (oy / sp - dirY)
                if (hypot(dirX, dirY) > 0.2f) {
                    var ang = Math.toDegrees(atan2(dirY.toDouble(), dirX.toDouble())).toFloat()
                    if (ang < 0f) ang += 360f
                    val step = if (cfg.snap16) 22.5f else 45f
                    val near = (Math.round(ang / step) * step) % 360f
                    val diff = angDiff(ang, near)
                    if (!locked) {
                        if (abs(diff) <= cfg.snapTh) { locked = true; lockAng = near }
                    } else {
                        if (abs(angDiff(ang, lockAng)) > cfg.snapTh * 1.5f) locked = false
                        else if (near != lockAng && abs(diff) <= cfg.snapTh) lockAng = near
                    }
                }
            }
            if (locked) {
                val r = Math.toRadians(lockAng.toDouble())
                val cx = cos(r).toFloat()
                val cy = sin(r).toFloat()
                val proj = ox * cx + oy * cy
                ox += cfg.snapStr * (proj * cx - ox)
                oy += cfg.snapStr * (proj * cy - oy)
                snapState = String.format(Locale.US, "ĐÃ KHÓA %.1f°", lockAng)
                lockAngle = lockAng
            } else {
                snapState = "TỰ DO"
                lockAngle = Float.NaN
            }
        } else {
            snapState = "TẮT"
            lockAngle = Float.NaN
        }

        outX = ox; outY = oy
        vel = v; alpha = a; gain = g
        dispVel = hypot(ox, oy) / dt
        cOut++
        return floatArrayOf(ox, oy)
    }
}

/** Khung test Tool Mouse: chấm trắng = thô, chấm cyan = sau bộ lọc, đường nét đứt = hướng đang khóa. */
class NmdPadView(ctx: Context) : View(ctx) {
    var onUpdate: (() -> Unit)? = null
    val filter = NmdFilter(NmdCfg.load(ctx))
    private val meter = HzMeter()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var rx = 0f
    private var ry = 0f
    private var fx = 0f
    private var fy = 0f
    private var lastX = Float.NaN
    private var lastY = Float.NaN
    private var ready = false
    private val trail = ArrayList<FloatArray>()
    private val d = resources.displayMetrics.density

    val hz: Int get() = meter.hz()

    init {
        isFocusable = true
        isFocusableInTouchMode = true
        isClickable = true
        setOnCapturedPointerListener { _, e -> onCaptured(e); true }
    }

    fun reload() {
        filter.c = NmdCfg.load(context)
        filter.reset()
        invalidate()
    }

    fun clearAll() {
        meter.clear(); filter.reset(); trail.clear(); ready = false; invalidate()
    }

    private fun ensureInit() {
        if (!ready) {
            rx = width / 2f; ry = height / 2f; fx = rx; fy = ry; ready = true
        }
    }

    private fun onCaptured(e: MotionEvent) {
        if (e.actionMasked == MotionEvent.ACTION_BUTTON_PRESS &&
            e.actionButton == MotionEvent.BUTTON_SECONDARY
        ) {
            releasePointerCapture()
            invalidate()
            return
        }
        if (e.actionMasked == MotionEvent.ACTION_MOVE) feed(e, true)
    }

    private fun feed(e: MotionEvent, rel: Boolean) {
        ensureInit()
        val n = e.historySize
        for (i in 0..n) {
            val t = if (i < n) e.getHistoricalEventTime(i) else e.eventTime
            val x = if (i < n) e.getHistoricalX(i) else e.x
            val y = if (i < n) e.getHistoricalY(i) else e.y
            step(x, y, t.toDouble(), rel)
        }
        onUpdate?.invoke()
        invalidate()
    }

    private fun step(x: Float, y: Float, t: Double, rel: Boolean) {
        val dx: Float
        val dy: Float
        if (rel) {
            dx = x; dy = y
        } else {
            dx = if (lastX.isNaN()) 0f else x - lastX
            dy = if (lastY.isNaN()) 0f else y - lastY
            lastX = x; lastY = y
        }
        meter.add(t)
        val o = filter.apply(dx, dy, t)
        rx = (rx + dx).coerceIn(0f, width.toFloat())
        ry = (ry + dy).coerceIn(0f, height.toFloat())
        fx = (fx + o[0]).coerceIn(0f, width.toFloat())
        fy = (fy + o[1]).coerceIn(0f, height.toFloat())
        trail.add(floatArrayOf(fx, fy))
        if (trail.size > 80) trail.removeAt(0)
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if (event.isFromSource(InputDevice.SOURCE_MOUSE)) {
            when (event.actionMasked) {
                MotionEvent.ACTION_HOVER_MOVE -> { feed(event, false); return true }
                MotionEvent.ACTION_HOVER_ENTER, MotionEvent.ACTION_HOVER_EXIT -> {
                    lastX = Float.NaN; lastY = Float.NaN
                }
            }
        }
        return super.onGenericMotionEvent(event)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.isFromSource(InputDevice.SOURCE_MOUSE)) {
            if (event.actionMasked == MotionEvent.ACTION_DOWN && !hasPointerCapture()) {
                requestFocus()
                requestPointerCapture()
                invalidate()
            } else if (event.actionMasked == MotionEvent.ACTION_MOVE) {
                feed(event, false)
            }
        }
        return true
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (hasPointerCapture() && (keyCode == KeyEvent.KEYCODE_ESCAPE || keyCode == KeyEvent.KEYCODE_BACK)) {
            releasePointerCapture()
            invalidate()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        paint.style = Paint.Style.FILL
        paint.color = 0xFF050C24.toInt()
        c.drawRoundRect(RectF(0f, 0f, w, h), 16 * d, 16 * d, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1 * d
        paint.color = 0x5500C8FF
        c.drawRoundRect(RectF(0f, 0f, w, h), 16 * d, 16 * d, paint)

        val la = filter.lockAngle
        if (!la.isNaN() && ready) {
            val r = Math.toRadians(la.toDouble())
            val ux = cos(r).toFloat()
            val uy = sin(r).toFloat()
            paint.color = 0xAAFFC52E.toInt()
            paint.strokeWidth = 1.5f * d
            paint.pathEffect = DashPathEffect(floatArrayOf(6 * d, 6 * d), 0f)
            c.drawLine(fx - ux * 90 * d, fy - uy * 90 * d, fx + ux * 90 * d, fy + uy * 90 * d, paint)
            paint.pathEffect = null
        }
        if (trail.size > 1) {
            paint.strokeWidth = 2 * d
            for (i in 1 until trail.size) {
                paint.color = ((i * 255 / trail.size) shl 24) or 0x0000C8FF
                c.drawLine(trail[i - 1][0], trail[i - 1][1], trail[i][0], trail[i][1], paint)
            }
        }
        paint.style = Paint.Style.FILL
        if (ready) {
            paint.color = 0xFFFFFFFF.toInt()
            c.drawCircle(rx, ry, 4 * d, paint)
            paint.color = 0xFF00C8FF.toInt()
            c.drawCircle(fx, fy, 5 * d, paint)
        }
        paint.color = 0xFF7F9CC4.toInt()
        paint.textSize = 12 * d
        val msg = if (hasPointerCapture()) "Đang bắt chuột — chuột phải / Esc để thoát"
        else "Rê chuột vào đây, hoặc click để bắt chuột (đo thô)"
        c.drawText(msg, 12 * d, h - 12 * d, paint)
    }
}

/** Đồ thị Response Curve (Natural): gain theo vận tốc. */
class NmdCurveView(ctx: Context) : View(ctx) {
    var cfg: NmdCfg = NmdCfg.load(ctx)
    var liveVel = -1f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = resources.displayMetrics.density

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        paint.style = Paint.Style.FILL
        paint.color = 0xFF050C24.toInt()
        c.drawRoundRect(RectF(0f, 0f, w, h), 12 * d, 12 * d, paint)

        val l = 12 * d
        val r = w - 12 * d
        val t = 12 * d
        val b = h - 12 * d
        val maxV = 40f
        val yMin = 0.8f
        val yMax = max(1.6f, cfg.cap + 0.3f)
        fun px(v: Float) = l + (r - l) * (v / maxV)
        fun py(g: Float) = b - (b - t) * ((g - yMin) / (yMax - yMin))

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1 * d
        paint.color = 0x44FFFFFF
        c.drawLine(l, b, r, b, paint)
        c.drawLine(l, t, l, b, paint)
        paint.pathEffect = DashPathEffect(floatArrayOf(6 * d, 6 * d), 0f)
        c.drawLine(l, py(1f), r, py(1f), paint)
        paint.pathEffect = null

        val path = Path()
        var first = true
        var v = 0f
        while (v <= maxV) {
            val gg = if (cfg.bypass) 1f else cfg.gain(v)
            val x = px(v)
            val y = py(gg)
            if (first) { path.moveTo(x, y); first = false } else path.lineTo(x, y)
            v += 0.5f
        }
        paint.strokeWidth = 3 * d
        paint.color = 0xFFB066FF.toInt()
        c.drawPath(path, paint)

        if (liveVel >= 0f) {
            val lv = min(liveVel, maxV)
            val gg = if (cfg.bypass) 1f else cfg.gain(lv)
            paint.style = Paint.Style.FILL
            paint.color = 0xFF00C8FF.toInt()
            c.drawCircle(px(lv), py(gg), 5 * d, paint)
        }
    }
}

/** Điều chỉnh tốc độ con trỏ hệ thống theo vận tốc thật (đọc getevent qua Shizuku) – chạy ngoài app. */
object NmdDyn {
    private val lock = Any()
    private val ts = ArrayDeque<Long>()
    private val mg = ArrayDeque<Double>()
    private var sum = 0.0
    private var vS = 0.0
    private var lastSp = Double.NaN

    fun onMove(dx: Int, dy: Int) {
        val m = Math.sqrt((dx.toLong() * dx + dy.toLong() * dy).toDouble())
        val t = SystemClock.uptimeMillis()
        synchronized(lock) {
            ts.addLast(t)
            mg.addLast(m)
            sum += m
        }
    }

    fun tick(c: NmdCfg): Int {
        synchronized(lock) {
            val now = SystemClock.uptimeMillis()
            val winMs = (c.velWin * 5).toLong().coerceAtLeast(1L)
            while (ts.isNotEmpty() && now - ts.first() > winMs) {
                ts.removeFirst()
                sum -= mg.removeFirst()
            }
            if (ts.isEmpty()) sum = 0.0
            var raw = sum / winMs
            if (sum < c.micro.toDouble()) raw = 0.0
            val vn = (raw / 20.0).coerceIn(0.0, 1.0)
            val a = (c.baseA + (c.fastA - c.baseA) * vn).toDouble().coerceIn(0.02, 1.0)
            vS += a * (raw - vS)
            val g = (if (c.bypass) 1f else c.gain(vS.toFloat())) * c.dpiRatio()
            val target = 4.0 * ln(max(g, 0.05f).toDouble()) / ln(2.0)
            if (lastSp.isNaN() || abs(target - lastSp) > 0.55) lastSp = target
            return lastSp.roundToInt().coerceIn(-7, 7)
        }
    }
}
