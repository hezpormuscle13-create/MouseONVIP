package com.hezpor.mousetool

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import kotlin.math.roundToInt

/** Lưu / đọc kiểu của FPS trong SharedPreferences. */
object FpsStore {
    fun load(c: Context) = StyleSpec(
        color = Prefs.getInt(c, K.FPS_COLOR, 0xFF00C8FF.toInt()),
        size = Prefs.getFloat(c, K.FPS_SIZE, 16f),
        fx = Prefs.getInt(c, K.FPS_FX, Fx.NEON),
        fxSpeed = Prefs.getInt(c, K.FPS_FX_SPEED, 50),
        bgOn = Prefs.getBool(c, K.FPS_BG_ON, true),
        bgPct = Prefs.getFloat(c, K.FPS_BG_PCT, 70f).roundToInt(),
        bgColor = Prefs.getInt(c, K.FPS_BGCOLOR, 0xFF000000.toInt()),
        bold = Prefs.getBool(c, K.FPS_BOLD, true),
        italic = Prefs.getBool(c, K.FPS_ITALIC, false),
        mono = Prefs.getBool(c, K.FPS_MONO, false),
        spacing = Prefs.getInt(c, K.FPS_SPACING, 4),
        glow = Prefs.getInt(c, K.FPS_GLOW, 14),
        alpha = Prefs.getInt(c, K.FPS_ALPHA, 100),
        rot = Prefs.getInt(c, K.FPS_ROT, 0),
        radius = Prefs.getInt(c, K.FPS_RADIUS, 14),
        border = Prefs.getInt(c, K.FPS_BORDER, 0)
    )

    fun save(c: Context, s: StyleSpec) {
        Prefs.sp(c).edit()
            .putInt(K.FPS_COLOR, s.color).putFloat(K.FPS_SIZE, s.size)
            .putInt(K.FPS_FX, s.fx).putInt(K.FPS_FX_SPEED, s.fxSpeed)
            .putBoolean(K.FPS_BG_ON, s.bgOn).putFloat(K.FPS_BG_PCT, s.bgPct.toFloat())
            .putInt(K.FPS_BGCOLOR, s.bgColor)
            .putBoolean(K.FPS_BOLD, s.bold).putBoolean(K.FPS_ITALIC, s.italic).putBoolean(K.FPS_MONO, s.mono)
            .putInt(K.FPS_SPACING, s.spacing).putInt(K.FPS_GLOW, s.glow).putInt(K.FPS_ALPHA, s.alpha)
            .putInt(K.FPS_ROT, s.rot).putInt(K.FPS_RADIUS, s.radius).putInt(K.FPS_BORDER, s.border)
            .apply()
    }
}

/**
 * Bảng chỉnh kiểu có tab (Chữ • Màu • Hiệu ứng • Nền [+ tab riêng]).
 * Dùng chung cho: bảng chỉnh nổi trên màn hình, thẻ trong app, hộp thoại văn bản.
 */
class StylePanel(private val ctx: Context) {
    private val dens = ctx.resources.displayMetrics.density
    private fun dp(v: Int) = (v * dens).toInt()

    private val ACC = Th.ACC
    private val TXT = Th.TXT
    private val DIM = Th.DIM
    private val CHIP = Th.CARD2

    private fun round(color: Int, r: Int, stroke: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        if (stroke != 0) g.setStroke(dp(1), stroke)
        return g
    }

    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(top) }

    fun chip(text: String, on: Boolean, onClick: () -> Unit): TextView {
        val t = TextView(ctx)
        t.text = text
        t.textSize = 12f
        t.gravity = Gravity.CENTER
        t.setPadding(dp(12), dp(6), dp(12), dp(6))
        val painter: (Boolean) -> Unit = { o ->
            t.background = round(if (o) ACC else CHIP, 14, if (o) ACC else 0x5500C8FF)
            t.setTextColor(if (o) 0xFF001018.toInt() else TXT)
        }
        painter(on)
        t.tag = painter
        t.setOnClickListener { onClick() }
        return t
    }

    @Suppress("UNCHECKED_CAST")
    private fun repaint(t: TextView, on: Boolean) { (t.tag as (Boolean) -> Unit)(on) }

    /** Hàng nhãn + giá trị + thanh trượt (nhãn ngắn, giá trị cùng dòng). */
    fun slider(
        p: LinearLayout, label: String, min: Int, max: Int, cur: Int, unit: String = "",
        onV: (Int) -> Unit
    ) {
        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        val l = TextView(ctx); l.text = label; l.textSize = 12f; l.setTextColor(DIM)
        val v = TextView(ctx); v.textSize = 12f; v.setTextColor(ACC); v.gravity = Gravity.END
        head.addView(l, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(v, LinearLayout.LayoutParams(-2, -2))
        p.addView(head, lp(8))
        val sb = SeekBar(ctx)
        sb.max = max - min
        sb.progress = (cur - min).coerceIn(0, max - min)
        v.text = "${sb.progress + min}$unit"
        sb.progressTintList = android.content.res.ColorStateList.valueOf(ACC)
        sb.thumbTintList = android.content.res.ColorStateList.valueOf(ACC)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, pr: Int, fromUser: Boolean) {
                v.text = "${pr + min}$unit"
                if (fromUser) onV(pr + min)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        p.addView(sb, lp(0))
    }

    /** Thanh trượt gắn thẳng vào Prefs. isFloat = khóa đang lưu kiểu Float. */
    fun prefSlider(
        p: LinearLayout, label: String, key: String, min: Int, max: Int, def: Int,
        unit: String = "", isFloat: Boolean = false, onC: () -> Unit
    ) {
        val cur = if (isFloat) Prefs.getFloat(ctx, key, def.toFloat()).roundToInt() else Prefs.getInt(ctx, key, def)
        slider(p, label, min, max, cur, unit) {
            if (isFloat) Prefs.setFloat(ctx, key, it.toFloat()) else Prefs.setInt(ctx, key, it)
            onC()
        }
    }

    fun switchRow(p: LinearLayout, label: String, cur: Boolean, onC: (Boolean) -> Unit): Switch {
        val s = Switch(ctx)
        s.text = label
        s.textSize = 13f
        s.setTextColor(TXT)
        Ui(ctx).tint(s)
        s.isChecked = cur
        s.setOnCheckedChangeListener { _, v -> onC(v) }
        p.addView(s, lp(8))
        return s
    }

    fun dots(p: LinearLayout, colors: List<Int>, onPick: (Int) -> Unit) {
        val sv = HorizontalScrollView(ctx)
        sv.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        for (cl in colors) {
            val v = View(ctx)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(cl)
            g.setStroke(dp(1), 0xAAFFFFFF.toInt())
            v.background = g
            v.setOnClickListener { onPick(cl) }
            val q = LinearLayout.LayoutParams(dp(30), dp(30))
            q.marginEnd = dp(8)
            row.addView(v, q)
        }
        sv.addView(row)
        p.addView(sv, lp(8))
    }

    fun hue(p: LinearLayout, onPick: (Int) -> Unit) {
        val sb = SeekBar(ctx)
        sb.max = 360
        sb.progressDrawable = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(
                0xFFFF0000.toInt(), 0xFFFFFF00.toInt(), 0xFF00FF00.toInt(),
                0xFF00FFFF.toInt(), 0xFF0000FF.toInt(), 0xFFFF00FF.toInt(), 0xFFFF0000.toInt()
            )
        ).also { it.cornerRadius = dp(4).toFloat(); it.setSize(0, dp(8)) }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, pr: Int, u: Boolean) {
                if (u) onPick(Color.HSVToColor(floatArrayOf(pr.toFloat(), 1f, 1f)))
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        p.addView(sb, lp(8))
    }

    private fun hexRow(p: LinearLayout, onPick: (Int) -> Unit) {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val et = EditText(ctx)
        et.hint = "#RRGGBB"
        et.textSize = 13f
        et.setTextColor(TXT)
        et.setHintTextColor(DIM)
        et.setSingleLine(true)
        row.addView(et, LinearLayout.LayoutParams(0, -2, 1f))
        val ok = chip("OK", true) {
            try {
                var s = et.text.toString().trim()
                if (!s.startsWith("#")) s = "#$s"
                onPick(Color.parseColor(s))
            } catch (e: Throwable) { }
        }
        row.addView(ok, LinearLayout.LayoutParams(-2, -2))
        p.addView(row, lp(4))
    }

    /**
     * @param st      kiểu đang sửa (được cập nhật trực tiếp)
     * @param onChange gọi sau mỗi thay đổi
     * @param extraTitle / extra: tab riêng (ví dụ "Dòng" cho FPS), hiện đầu tiên
     */
    fun build(
        parent: LinearLayout, st: StyleSpec, minSize: Int, maxSize: Int,
        onChange: () -> Unit, extraTitle: String? = null, extra: ((LinearLayout) -> Unit)? = null
    ) {
        val names = ArrayList<String>()
        val pages = ArrayList<LinearLayout>()
        fun page(n: String): LinearLayout {
            val l = LinearLayout(ctx)
            l.orientation = LinearLayout.VERTICAL
            names.add(n); pages.add(l)
            return l
        }
        if (extraTitle != null && extra != null) extra(page(extraTitle))

        // --- Chữ ---
        val tx = page("Chữ")
        slider(tx, "Cỡ chữ", minSize, maxSize, st.size.roundToInt()) { st.size = it.toFloat(); onChange() }
        val styleRow = LinearLayout(ctx)
        styleRow.orientation = LinearLayout.HORIZONTAL
        fun addToggle(label: String, get: () -> Boolean, set: (Boolean) -> Unit) {
            val c = chip(label, get()) { }
            c.setOnClickListener { set(!get()); repaint(c, get()); onChange() }
            val q = LinearLayout.LayoutParams(-2, -2); q.marginEnd = dp(8)
            styleRow.addView(c, q)
        }
        addToggle("Đậm", { st.bold }, { st.bold = it })
        addToggle("Nghiêng", { st.italic }, { st.italic = it })
        addToggle("Mono", { st.mono }, { st.mono = it })
        tx.addView(styleRow, lp(10))
        slider(tx, "Giãn chữ", 0, 40, st.spacing) { st.spacing = it; onChange() }
        slider(tx, "Độ mờ", 20, 100, st.alpha, "%") { st.alpha = it; onChange() }
        slider(tx, "Xoay", -90, 90, st.rot, "°") { st.rot = it; onChange() }

        // --- Màu ---
        val co = page("Màu")
        dots(co, NEON) { st.color = it; onChange() }
        hue(co) { st.color = it; onChange() }
        hexRow(co) { st.color = it; onChange() }

        // --- Hiệu ứng ---
        val fx = page("Hiệu ứng")
        val chips = ArrayList<TextView>()
        val fxRow = LinearLayout(ctx)
        fxRow.orientation = LinearLayout.HORIZONTAL
        for ((i, n) in Fx.NAMES.withIndex()) {
            val c = chip(n, i == st.fx) { }
            c.setOnClickListener {
                st.fx = i
                for ((k, o) in chips.withIndex()) repaint(o, k == i)
                onChange()
            }
            val q = LinearLayout.LayoutParams(-2, -2); q.marginEnd = dp(6)
            fxRow.addView(c, q); chips.add(c)
        }
        val fxs = HorizontalScrollView(ctx)
        fxs.isHorizontalScrollBarEnabled = false
        fxs.addView(fxRow)
        fx.addView(fxs, lp(2))
        slider(fx, "Tốc độ", 1, 100, st.fxSpeed) { st.fxSpeed = it; onChange() }
        slider(fx, "Phát sáng", 0, 40, st.glow) { st.glow = it; onChange() }

        // --- Nền ---
        val bg = page("Nền")
        switchRow(bg, "Hiện nền", st.bgOn) { st.bgOn = it; onChange() }
        dots(bg, listOf(0xFF000000.toInt(), 0xFF0A1A4A.toInt(), 0xFF003C8F.toInt(), 0xFF2A0A4A.toInt(), 0xFF3A0A1A.toInt(), 0xFFFFFFFF.toInt())) {
            st.bgColor = it; st.bgOn = true; onChange()
        }
        slider(bg, "Độ đậm", 0, 100, st.bgPct, "%") { st.bgPct = it; onChange() }
        slider(bg, "Bo góc", 0, 30, st.radius, "dp") { st.radius = it; onChange() }
        slider(bg, "Viền", 0, 6, st.border, "dp") { st.border = it; onChange() }

        // --- thanh tab + vùng nội dung ---
        val bar = HorizontalScrollView(ctx)
        bar.isHorizontalScrollBarEnabled = false
        val barRow = LinearLayout(ctx)
        barRow.orientation = LinearLayout.HORIZONTAL
        val tabs = ArrayList<TextView>()
        fun select(i: Int) {
            for (k in pages.indices) pages[k].visibility = if (k == i) View.VISIBLE else View.GONE
            for (k in tabs.indices) repaint(tabs[k], k == i)
        }
        for ((i, n) in names.withIndex()) {
            val c = chip(n, i == 0) { select(i) }
            val q = LinearLayout.LayoutParams(-2, -2); q.marginEnd = dp(6)
            barRow.addView(c, q); tabs.add(c)
        }
        bar.addView(barRow)
        parent.addView(bar, lp(8))
        for (pg in pages) parent.addView(pg, lp(0))
        select(0)
    }
}

/** Các tinh chỉnh riêng của FPS (tab "Dòng"): hai dòng, bố cục, vị trí. */
object FpsUi {
    fun build(ctx: Context, panel: StylePanel, p: LinearLayout, onChange: () -> Unit, onHome: () -> Unit) {
        val dm = ctx.resources.displayMetrics
        panel.switchRow(p, "Dòng trên (số tự đặt)", Prefs.getBool(ctx, K.FPS_PC_ON, true)) { Prefs.setBool(ctx, K.FPS_PC_ON, it); onChange() }
        panel.prefSlider(p, "Số dòng trên", K.FPS_FAKE_VAL, 1, 360, 144, "", true) { onChange() }
        panel.prefSlider(p, "Dao động ±", K.FPS_JITTER, 0, 30, 0, "", true) { onChange() }
        panel.switchRow(p, "Dòng dưới (đo thật)", Prefs.getBool(ctx, K.FPS_REAL_ON, true)) { Prefs.setBool(ctx, K.FPS_REAL_ON, it); onChange() }
        panel.switchRow(p, "Dòng dưới đổi màu theo FPS", Prefs.getBool(ctx, K.FPS_COLOR_AUTO, false)) { Prefs.setBool(ctx, K.FPS_COLOR_AUTO, it); onChange() }
        panel.switchRow(p, "Hiện chữ \"FPS\"", Prefs.getBool(ctx, K.FPS_LABEL, true)) { Prefs.setBool(ctx, K.FPS_LABEL, it); onChange() }
        panel.switchRow(p, "Xếp ngang", Prefs.getBool(ctx, K.FPS_HORIZ, false)) { Prefs.setBool(ctx, K.FPS_HORIZ, it); onChange() }
        panel.prefSlider(p, "Cách dòng", K.FPS_GAP, 0, 24, 2, "dp") { onChange() }
        panel.prefSlider(p, "Tốc độ cập nhật", K.FPS_SPEED, 50, 2000, 500, "ms", true) { onChange() }
        panel.prefSlider(p, "Vị trí X", K.FPS_X, 0, dm.widthPixels, 0, "px") { onChange() }
        panel.prefSlider(p, "Vị trí Y", K.FPS_Y, 0, dm.heightPixels, 0, "px") { onChange() }
        val home = panel.chip("⌊ Về sát góc dưới trái", true) { onHome() }
        p.addView(home, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = (12 * dm.density).toInt() })
    }
}
