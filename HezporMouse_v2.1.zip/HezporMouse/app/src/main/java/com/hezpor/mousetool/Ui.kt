package com.hezpor.mousetool

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import java.util.Locale
import kotlin.math.roundToInt

/** Bảng màu chung (Gaming: nền xanh đen + xanh dương neon). */
object Th {
    val ACC = 0xFF00C8FF.toInt()
    val BG = 0xFF050A1C.toInt()
    val PANEL = 0xFF0B1433.toInt()
    val CARD2 = 0xFF14224F.toInt()
    val TXT = 0xFFEAF6FF.toInt()
    val DIM = 0xFF7F9CC4.toInt()
    val OK = 0xFF3DDC84.toInt()
    val BAD = 0xFFFF5A5F.toInt()
    val GOLD = 0xFFFFC52E.toInt()
}

/** Dựng view bằng code, dùng cho menu nổi. */
class Ui(private val ctx: Context) {
    private val dens = ctx.resources.displayMetrics.density
    private val matchP = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrapP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun dp(v: Int): Int = (v * dens).toInt()

    fun round(color: Int, radiusDp: Int, stroke: Int = 0, strokeDp: Int = 1): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        if (stroke != 0) g.setStroke(dp(strokeDp), stroke)
        return g
    }

    fun oval(color: Int, stroke: Int, strokeDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(color)
        g.setStroke(dp(strokeDp), stroke)
        return g
    }

    fun lp(top: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(matchP, wrapP)
        p.topMargin = dp(top)
        return p
    }

    fun text(parent: LinearLayout, s: String, size: Float, color: Int, bold: Boolean = false, top: Int = 0): TextView {
        val t = TextView(ctx)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        parent.addView(t, lp(top))
        return t
    }

    /** Tiêu đề mục: thanh vàng + chữ vàng in hoa (giống "| RENDERING GRAPHICS"). */
    fun title(parent: LinearLayout, s: String) {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val bar = View(ctx)
        bar.setBackgroundColor(Th.ACC)
        row.addView(bar, LinearLayout.LayoutParams(dp(3), dp(14)))
        val t = TextView(ctx)
        t.text = s.uppercase()
        t.textSize = 12f
        t.setTextColor(Th.ACC)
        t.typeface = Typeface.DEFAULT_BOLD
        t.letterSpacing = 0.15f
        t.setPadding(dp(8), 0, 0, 0)
        row.addView(t, LinearLayout.LayoutParams(wrapP, wrapP))
        parent.addView(row, lp(0))
    }

    fun tint(sw: Switch) {
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(Th.ACC, 0xFFB0B0B8.toInt()))
        sw.trackTintList = ColorStateList(states, intArrayOf(0x6600C8FF, 0x55888890))
    }

    /** Hàng công tắc: tiêu đề + mô tả nhỏ + switch. Ghi thẳng vào Prefs rồi gọi onChange. */
    fun toggle(
        parent: LinearLayout, title: String, sub: String?, key: String, def: Boolean,
        onChange: (Boolean) -> Unit = {}
    ): Switch {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(12), dp(9), dp(10), dp(9))
        row.background = round(Th.CARD2, 12)

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val t = TextView(ctx)
        t.text = title
        t.textSize = 13f
        t.setTextColor(Th.TXT)
        t.typeface = Typeface.DEFAULT_BOLD
        col.addView(t, LinearLayout.LayoutParams(matchP, wrapP))
        if (sub != null) {
            val s = TextView(ctx)
            s.text = sub
            s.textSize = 10.5f
            s.setTextColor(Th.DIM)
            col.addView(s, LinearLayout.LayoutParams(matchP, wrapP))
        }
        row.addView(col, LinearLayout.LayoutParams(0, wrapP, 1f))

        val sw = Switch(ctx)
        tint(sw)
        sw.isChecked = Prefs.getBool(ctx, key, def)
        sw.setOnCheckedChangeListener { _, v ->
            Prefs.setBool(ctx, key, v)
            onChange(v)
        }
        row.addView(sw, LinearLayout.LayoutParams(wrapP, wrapP))
        row.setOnClickListener { sw.toggle() }
        parent.addView(row, lp(8))
        return sw
    }

    /**
     * Thanh trượt. onLive gọi liên tục khi kéo (nhẹ), onStop gọi 1 lần khi thả tay
     * (dùng cho việc nặng như ghi cài đặt hệ thống / chạy lệnh Shizuku).
     */
    fun slider(
        parent: LinearLayout, name: String, key: String,
        min: Float, max: Float, step: Float, def: Float, fmt: String,
        onLive: (Float) -> Unit = {}, onStop: (Float) -> Unit = {}
    ): SeekBar {
        val steps = ((max - min) / step).roundToInt()
        val cur = Prefs.getFloat(ctx, key, def)
        val tv = text(parent, "", 12f, Th.TXT, true, 12)
        fun show(v: Float) {
            tv.text = name + ": " + String.format(Locale.US, fmt, v)
        }
        show(cur)
        val sb = SeekBar(ctx)
        sb.max = steps
        sb.progress = ((cur - min) / step).roundToInt().coerceIn(0, steps)
        sb.progressTintList = ColorStateList.valueOf(Th.ACC)
        sb.thumbTintList = ColorStateList.valueOf(Th.ACC)
        sb.progressBackgroundTintList = ColorStateList.valueOf(0x44FFFFFF)
        var last = cur
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = min + p * step
                show(v)
                if (fromUser) {
                    last = v
                    Prefs.setFloat(ctx, key, v)
                    onLive(v)
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { onStop(last) }
        })
        parent.addView(sb, lp(0))
        return sb
    }

    /** Hàng chip chọn nhanh (cuộn ngang). selected = -1 nếu không chọn mục nào. */
    fun chips(parent: LinearLayout, items: List<String>, selected: Int, onClick: (Int) -> Unit) {
        val sv = HorizontalScrollView(ctx)
        sv.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        for (i in items.indices) {
            val sel = i == selected
            val t = TextView(ctx)
            t.text = items[i]
            t.textSize = 12f
            t.gravity = Gravity.CENTER
            t.typeface = Typeface.DEFAULT_BOLD
            t.setTextColor(if (sel) Color.BLACK else Th.TXT)
            t.background = round(if (sel) Th.ACC else Th.CARD2, 10, if (sel) Th.ACC else 0x6600C8FF)
            t.setPadding(dp(14), dp(8), dp(14), dp(8))
            t.setOnClickListener { onClick(i) }
            val p = LinearLayout.LayoutParams(wrapP, wrapP)
            p.marginEnd = dp(6)
            row.addView(t, p)
        }
        sv.addView(row)
        parent.addView(sv, lp(8))
    }

    fun button(
        parent: LinearLayout, s: String, filled: Boolean = true, top: Int = 8,
        params: LinearLayout.LayoutParams? = null, onClick: () -> Unit
    ): TextView {
        val t = TextView(ctx)
        t.text = s
        t.textSize = 13f
        t.gravity = Gravity.CENTER
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(if (filled) Color.BLACK else Th.ACC)
        t.background = if (filled) round(Th.ACC, 12) else round(Th.CARD2, 12, Th.ACC)
        t.setPadding(dp(10), dp(11), dp(10), dp(11))
        t.setOnClickListener { onClick() }
        parent.addView(t, params ?: lp(top))
        return t
    }

    /** Hàng chấm màu neon để chọn màu. */
    fun colorDots(parent: LinearLayout, onPick: (Int) -> Unit) {
        val sv = HorizontalScrollView(ctx)
        sv.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        for (cl in NEON) {
            val v = View(ctx)
            v.background = oval(cl, 0x88FFFFFF.toInt(), 1)
            v.setOnClickListener { onPick(cl) }
            val p = LinearLayout.LayoutParams(dp(34), dp(34))
            p.marginEnd = dp(8)
            row.addView(v, p)
        }
        sv.addView(row)
        parent.addView(sv, lp(8))
    }
}
