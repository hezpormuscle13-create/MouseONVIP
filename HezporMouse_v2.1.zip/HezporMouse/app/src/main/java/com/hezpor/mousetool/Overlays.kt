package com.hezpor.mousetool

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.SpannableString
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.util.Random
import kotlin.math.max
import kotlin.math.roundToInt

val NEON: List<Int> = listOf(
    0xFF00C8FF.toInt(), 0xFF0066FF.toInt(), 0xFF39FF14.toInt(), 0xFFFF2079.toInt(), 0xFFFFF01F.toInt(),
    0xFFBF00FF.toInt(), 0xFFFF6A00.toInt(), 0xFFFFFFFF.toInt(), 0xFFFF0000.toInt(),
    0xFF00FFA3.toInt()
)

data class TextItem(
    val id: Long, val text: String, val x: Int, val y: Int, val st: StyleSpec
)

object TextStore {
    private const val KEY = "texts_json"

    fun raw(c: Context): String = Prefs.sp(c).getString(KEY, "[]") ?: "[]"

    fun load(c: Context): List<TextItem> {
        val out = ArrayList<TextItem>()
        try {
            val arr = JSONArray(raw(c))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val st = StyleSpec(
                    color = o.getInt("color"),
                    size = o.getDouble("size").toFloat(),
                    fx = o.optInt("fx", Fx.NEON),
                    fxSpeed = o.optInt("fxSpeed", 50),
                    bgOn = o.optBoolean("bgOn", true),
                    bgPct = o.optInt("bgPct", 70),
                    bgColor = o.optInt("bgColor", 0xFF000000.toInt()),
                    bold = o.optBoolean("bold", true),
                    italic = o.optBoolean("italic", false),
                    mono = o.optBoolean("mono", false),
                    spacing = o.optInt("spacing", 0),
                    glow = o.optInt("glow", 18),
                    alpha = o.optInt("alpha", 100),
                    rot = o.optInt("rot", 0),
                    radius = o.optInt("radius", 10),
                    border = o.optInt("border", 0)
                )
                out.add(TextItem(o.getLong("id"), o.getString("text"), o.getInt("x"), o.getInt("y"), st))
            }
        } catch (e: Throwable) { }
        return out
    }

    fun save(c: Context, list: List<TextItem>) {
        val arr = JSONArray()
        for (t in list) {
            val s = t.st
            val o = JSONObject()
            o.put("id", t.id); o.put("text", t.text); o.put("x", t.x); o.put("y", t.y)
            o.put("color", s.color); o.put("size", s.size.toDouble())
            o.put("fx", s.fx); o.put("fxSpeed", s.fxSpeed)
            o.put("bgOn", s.bgOn); o.put("bgPct", s.bgPct); o.put("bgColor", s.bgColor)
            o.put("bold", s.bold); o.put("italic", s.italic); o.put("mono", s.mono)
            o.put("spacing", s.spacing); o.put("glow", s.glow); o.put("alpha", s.alpha)
            o.put("rot", s.rot); o.put("radius", s.radius); o.put("border", s.border)
            arr.put(o)
        }
        Prefs.sp(c).edit().putString(KEY, arr.toString()).apply()
    }

    /** Kiểu mặc định cho dòng chữ mới. */
    fun newStyle() = StyleSpec(color = NEON[0], size = 26f, glow = 18, spacing = 0, radius = 10, bgPct = 60)
}

/**
 * Các cửa sổ nổi:
 *  - HUD FPS: 2 dòng, dính sát góc dưới trái, nhiều tinh chỉnh + hiệu ứng.
 *  - Văn bản nổi.
 * Chưa khóa: chạm để mở bảng chỉnh ngay trên màn hình, kéo để di chuyển. Khóa: chạm xuyên qua.
 */
class OverlayManager(private val ctx: Context, private val wm: WindowManager) {
    private val dens = ctx.resources.displayMetrics.density
    private fun dp(v: Int) = (v * dens).toInt()
    private val rnd = Random()
    private val main = Handler(Looper.getMainLooper())
    private val editor = InlineEditor(ctx, wm)

    // FPS
    private var fpsRoot: LinearLayout? = null
    private var fpsTop: TextView? = null
    private var fpsBot: TextView? = null
    private var fpsLp: WindowManager.LayoutParams? = null
    private var fpsSig = ""
    private var fpsSt = StyleSpec()
    private var botColor = 0

    // Văn bản
    private class TV(val tv: TextView, val lp: WindowManager.LayoutParams, var item: TextItem)
    private val textViews = LinkedHashMap<Long, TV>()
    private var textSig = ""

    private fun canDraw() = Settings.canDrawOverlays(ctx)

    private var fxRunning = false
    private val fxTick = object : Runnable {
        override fun run() {
            val t = SystemClock.uptimeMillis()
            var any = false
            if (fpsRoot != null && Fx.animated(fpsSt.fx)) {
                any = true
                fpsTop?.let { Fx.apply(it, fpsSt, t) }
                fpsBot?.let { Fx.apply(it, botStyle(), t) }
            }
            for (e in textViews.values) {
                if (Fx.animated(e.item.st.fx)) {
                    any = true
                    Fx.apply(e.tv, e.item.st, t)
                }
            }
            if (any) main.postDelayed(this, 50) else fxRunning = false
        }
    }

    private fun startFx() {
        if (!fxRunning) { fxRunning = true; main.post(fxTick) }
    }

    private fun params(grav: Int, x: Int, y: Int, locked: Boolean): WindowManager.LayoutParams {
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        if (locked) f = f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            f, PixelFormat.TRANSLUCENT
        )
        lp.gravity = grav
        lp.x = x
        lp.y = y
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    /** Kéo để di chuyển; chạm nhẹ (không kéo) để mở bảng chỉnh. */
    private fun touch(
        v: View, lp: WindowManager.LayoutParams, bottom: Boolean,
        onEnd: () -> Unit, onTap: () -> Unit
    ) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        var t0 = 0L
        val slop = dp(8)
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false
                    t0 = SystemClock.uptimeMillis()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt()
                    val dy = (e.rawY - sy).toInt()
                    if (!moved && (kotlin.math.abs(dx) > slop || kotlin.math.abs(dy) > slop)) moved = true
                    if (moved) {
                        lp.x = max(0, ox + dx)
                        lp.y = max(0, if (bottom) oy - dy else oy + dy)
                        try { wm.updateViewLayout(v, lp) } catch (ex: Throwable) { }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) onEnd()
                    else if (SystemClock.uptimeMillis() - t0 < 500) onTap()
                }
            }
            true
        }
    }

    // ---------- FPS ----------

    private fun botStyle(): StyleSpec {
        if (!Prefs.getBool(ctx, K.FPS_COLOR_AUTO, false) || botColor == 0) return fpsSt
        return fpsSt.copy(color = botColor)
    }

    private fun makeFpsRow(): TextView {
        val tv = TextView(ctx)
        tv.includeFontPadding = false
        tv.setPadding(0, dp(1), 0, dp(1))
        return tv
    }

    fun syncFps() {
        val on = Prefs.getBool(ctx, K.FPS_ON, false) && canDraw()
        val lock = Prefs.getBool(ctx, K.FPS_LOCK, true)
        val sig = "$on|$lock"
        if (sig != fpsSig) {
            fpsSig = sig
            removeFps()
            if (on) buildFps(lock)
        }
        applyFpsStyle()
    }

    private fun removeFps() {
        fpsRoot?.let { try { wm.removeView(it) } catch (e: Throwable) { } }
        fpsRoot = null; fpsTop = null; fpsBot = null; fpsLp = null
    }

    private fun buildFps(lock: Boolean) {
        val root = LinearLayout(ctx)
        val top = makeFpsRow()
        val bot = makeFpsRow()
        root.addView(top, LinearLayout.LayoutParams(-2, -2))
        root.addView(bot, LinearLayout.LayoutParams(-2, -2))
        // Mặc định sát góc dưới bên trái (0,0)
        val lp = params(
            Gravity.BOTTOM or Gravity.START,
            Prefs.getInt(ctx, K.FPS_X, 0), Prefs.getInt(ctx, K.FPS_Y, 0), lock
        )
        if (!lock) {
            touch(root, lp, true, {
                Prefs.setInt(ctx, K.FPS_X, lp.x)
                Prefs.setInt(ctx, K.FPS_Y, lp.y)
            }) { openFpsEditor() }
        }
        try {
            wm.addView(root, lp)
            fpsRoot = root; fpsTop = top; fpsBot = bot; fpsLp = lp
        } catch (e: Throwable) { }
    }

    private fun applyFpsStyle() {
        val root = fpsRoot ?: return
        val st = FpsStore.load(ctx)
        fpsSt = st
        val lock = Prefs.getBool(ctx, K.FPS_LOCK, true)
        val showTop = Prefs.getBool(ctx, K.FPS_PC_ON, true)
        val showBot = Prefs.getBool(ctx, K.FPS_REAL_ON, true)
        val horiz = Prefs.getBool(ctx, K.FPS_HORIZ, false)
        val gap = dp(Prefs.getInt(ctx, K.FPS_GAP, 2))
        fpsTop?.visibility = if (showTop) View.VISIBLE else View.GONE
        fpsBot?.visibility = if (showBot) View.VISIBLE else View.GONE
        root.visibility = if (showTop || showBot) View.VISIBLE else View.GONE
        root.orientation = if (horiz) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        root.setPadding(dp(8), dp(3), dp(14), dp(3))
        (fpsBot?.layoutParams as? LinearLayout.LayoutParams)?.let {
            it.leftMargin = if (horiz) gap * 3 else 0
            it.topMargin = if (horiz) 0 else gap
            fpsBot?.layoutParams = it
        }
        // Chỉ bo góc trên-phải để dính liền góc màn hình
        val r = st.radius * dens
        root.background = Fx.bg(st, dens, !lock, floatArrayOf(0f, 0f, r, r, 0f, 0f, 0f, 0f))
        root.rotation = st.rot.toFloat()
        val now = SystemClock.uptimeMillis()
        fpsTop?.let { Fx.font(it, st); Fx.apply(it, st, now) }
        fpsBot?.let { Fx.font(it, st); Fx.apply(it, botStyle(), now) }
        // Vị trí từ thanh trượt X / Y
        fpsLp?.let { l ->
            val nx = Prefs.getInt(ctx, K.FPS_X, 0)
            val ny = Prefs.getInt(ctx, K.FPS_Y, 0)
            if (l.x != nx || l.y != ny) {
                l.x = nx; l.y = ny
                try { wm.updateViewLayout(root, l) } catch (e: Throwable) { }
            }
        }
        updateFps()
        if (Fx.animated(st.fx)) startFx()
    }

    private fun topValue(): Int {
        val base = Prefs.getFloat(ctx, K.FPS_FAKE_VAL, 144f).roundToInt()
        val j = Prefs.getFloat(ctx, K.FPS_JITTER, 0f).roundToInt()
        val d = if (j > 0) rnd.nextInt(2 * j + 1) - j else 0
        return max(1, base + d)
    }

    private fun botValue(): Int =
        if (LiveState.realFps > 0) LiveState.realFps else LiveState.vsyncFps

    private fun fpsText(n: Int): CharSequence {
        val num = if (n > 0) n.toString() else "--"
        if (!Prefs.getBool(ctx, K.FPS_LABEL, true)) return num
        val s = SpannableString("FPS  $num")
        s.setSpan(RelativeSizeSpan(0.72f), 0, 3, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return s
    }

    fun updateFps() {
        fpsTop?.text = fpsText(topValue())
        val b = botValue()
        fpsBot?.text = fpsText(b)
        if (Prefs.getBool(ctx, K.FPS_COLOR_AUTO, false)) {
            botColor = when {
                b <= 0 -> 0
                b >= 50 -> 0xFF39FF14.toInt()
                b >= 30 -> 0xFFFFF01F.toInt()
                else -> 0xFFFF2079.toInt()
            }
            fpsBot?.let { Fx.apply(it, botStyle(), SystemClock.uptimeMillis()) }
        }
    }

    private fun openFpsEditor() {
        if (editor.isOpen()) return
        val st = FpsStore.load(ctx)
        val panel = StylePanel(ctx)
        editor.show(
            "FPS", st, 8, 48, null, "Dòng",
            { box ->
                FpsUi.build(ctx, panel, box, { applyFpsStyle() }) {
                    Prefs.setInt(ctx, K.FPS_X, 0); Prefs.setInt(ctx, K.FPS_Y, 0); applyFpsStyle()
                }
            },
            null,
            { FpsStore.save(ctx, st); applyFpsStyle() },
            { Prefs.setBool(ctx, K.FPS_LOCK, true); syncFps() },
            null
        )
    }

    // ---------- Văn bản ----------

    fun syncTexts() {
        val on = Prefs.getBool(ctx, K.TEXT_ON, false) && canDraw()
        val lock = Prefs.getBool(ctx, K.TEXT_LOCK, false)
        val items = if (on) TextStore.load(ctx) else emptyList()
        val sig = "$on|$lock|" + items.joinToString(",") { it.id.toString() }
        if (sig != textSig) {
            textSig = sig
            clearTexts()
            for (item in items) addText(item, lock)
        }
        for (item in items) {
            val e = textViews[item.id] ?: continue
            e.item = item
            styleText(e, lock)
            if (e.lp.x != item.x || e.lp.y != item.y) {
                e.lp.x = item.x; e.lp.y = item.y
                try { wm.updateViewLayout(e.tv, e.lp) } catch (ex: Throwable) { }
            }
        }
        if (items.any { Fx.animated(it.st.fx) }) startFx()
    }

    private fun clearTexts() {
        for (e in textViews.values) { try { wm.removeView(e.tv) } catch (ex: Throwable) { } }
        textViews.clear()
    }

    private fun styleText(e: TV, lock: Boolean) {
        val tv = e.tv
        if (tv.text.toString() != e.item.text) tv.text = e.item.text
        Fx.style(tv, e.item.st, dens, SystemClock.uptimeMillis(), !lock)
    }

    private fun addText(item: TextItem, lock: Boolean) {
        val tv = TextView(ctx)
        tv.setPadding(dp(8), dp(3), dp(8), dp(3))
        val lp = params(Gravity.TOP or Gravity.START, item.x, item.y, lock)
        val e = TV(tv, lp, item)
        if (!lock) {
            touch(tv, lp, false, {
                TextStore.save(ctx, TextStore.load(ctx).map {
                    if (it.id == item.id) it.copy(x = lp.x, y = lp.y) else it
                })
            }) { openTextEditor(item.id) }
        }
        try {
            wm.addView(tv, lp)
            textViews[item.id] = e
            styleText(e, lock)
        } catch (ex: Throwable) { }
    }

    private fun openTextEditor(id: Long) {
        if (editor.isOpen()) return
        val item = TextStore.load(ctx).firstOrNull { it.id == id } ?: return
        val st = item.st.copy()
        var txt = item.text
        fun commit() {
            TextStore.save(ctx, TextStore.load(ctx).map { if (it.id == id) it.copy(text = txt, st = st.copy()) else it })
            syncTexts()
        }
        editor.show(
            "Văn bản", st, 10, 80, item.text, null, null,
            { s -> if (s.isNotEmpty()) { txt = s; commit() } },
            { commit() },
            { Prefs.setBool(ctx, K.TEXT_LOCK, true); syncTexts() },
            {
                TextStore.save(ctx, TextStore.load(ctx).filter { it.id != id })
                syncTexts()
            }
        )
    }

    fun destroy() {
        editor.close()
        main.removeCallbacks(fxTick)
        fxRunning = false
        removeFps()
        fpsSig = ""
        clearTexts()
        textSig = ""
    }
}
