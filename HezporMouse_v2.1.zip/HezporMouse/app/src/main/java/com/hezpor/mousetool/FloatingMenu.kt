package com.hezpor.mousetool

import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.Outline
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Bóng nổi trên mọi app + menu nổi (sidebar bên trái, nội dung bên phải).
 * Chạm bóng để mở/thu menu, kéo để di chuyển (tự hít vào cạnh màn hình).
 */
class FloatingMenu(private val ctx: Context, private val wm: WindowManager) {

    private val ui = Ui(ctx)
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val gfx = GfxPanel(ctx, ui)

    private var bubble: FrameLayout? = null
    private var bubSig = ""
    private var panel: FrameLayout? = null
    private var content: LinearLayout? = null
    private var scroll: ScrollView? = null
    private val sideIcons = ArrayList<TextView>()
    private val sideLabels = ArrayList<TextView>()
    private var tab = 0

    private val tabs = listOf(
        "⚡" to "Hiệu suất",
        "🛠" to "Công cụ",
        "🎨" to "Hình ảnh",
        "📊" to "HUD FPS",
        "✕" to "Thu gọn"
    )

    private fun dm() = ctx.resources.displayMetrics

    private fun toast(s: String) {
        try { Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show() } catch (e: Throwable) { }
    }

    /** Chạy việc nặng (Shizuku / ghi cài đặt) ở luồng nền, rồi báo kết quả + (tuỳ chọn) dựng lại tab. */
    private fun work(rebuild: Boolean = false, job: () -> String?) {
        try {
            io.execute {
                val m = try { job() } catch (e: Throwable) { "Lỗi: " + (e.message ?: "không rõ") }
                main.post {
                    if (m != null) toast(m)
                    if (rebuild && panel != null) selectTab(tab)
                }
            }
        } catch (e: Throwable) { }
    }

    // ---------------------------------------------------------------- bóng nổi

    /** Gọi mỗi khi cấu hình đổi: dựng/xoá bóng theo công tắc + quyền Lớp phủ. */
    fun sync() {
        val on = Prefs.getBool(ctx, K.BUBBLE_ON, true) && Settings.canDrawOverlays(ctx)
        val sig = "$on|" + Prefs.getFloat(ctx, K.BUB_SIZE, 52f) + "|" + Prefs.getFloat(ctx, K.BUB_ALPHA, 90f)
        if (sig == bubSig && (bubble != null) == on) return
        bubSig = sig
        removeBubble()
        if (on) addBubble()
    }

    private fun addBubble() {
        val sizePx = ui.dp(Prefs.getFloat(ctx, K.BUB_SIZE, 52f).roundToInt())
        val alpha = Prefs.getFloat(ctx, K.BUB_ALPHA, 90f) / 100f
        val frame = FrameLayout(ctx)
        frame.setPadding(0, 0, 0, 0)
        val img = ImageView(ctx)
        img.setImageResource(R.drawable.hezpor_logo)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        img.clipToOutline = true
        img.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
        }
        frame.addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        frame.alpha = alpha

        val lp = WindowManager.LayoutParams(
            sizePx, sizePx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val sw = dm().widthPixels
        val sh = dm().heightPixels
        lp.x = Prefs.getInt(ctx, K.BUB_X, sw - sizePx).coerceIn(0, max(0, sw - sizePx))
        lp.y = Prefs.getInt(ctx, K.BUB_Y, ui.dp(180)).coerceIn(0, max(0, sh - sizePx))

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        frame.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = lp.x; startY = lp.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && hypot(dx, dy) > ui.dp(6)) moved = true
                    if (moved) {
                        lp.x = (startX + dx).toInt().coerceIn(0, max(0, dm().widthPixels - sizePx))
                        lp.y = (startY + dy).toInt().coerceIn(0, max(0, dm().heightPixels - sizePx))
                        try { wm.updateViewLayout(frame, lp) } catch (ex: Throwable) { }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel() else snap(frame, lp, sizePx)
                }
            }
            true
        }
        try {
            wm.addView(frame, lp)
            bubble = frame
        } catch (e: Throwable) { }
    }

    private fun snap(v: View, lp: WindowManager.LayoutParams, sizePx: Int) {
        val sw = dm().widthPixels
        val target = if (lp.x + sizePx / 2 < sw / 2) 0 else sw - sizePx
        Prefs.setInt(ctx, K.BUB_X, target)
        Prefs.setInt(ctx, K.BUB_Y, lp.y)
        val a = ValueAnimator.ofInt(lp.x, target)
        a.duration = 180
        a.addUpdateListener { an ->
            lp.x = an.animatedValue as Int
            try { wm.updateViewLayout(v, lp) } catch (ex: Throwable) { }
        }
        a.start()
    }

    private fun removeBubble() {
        val b = bubble ?: return
        try { wm.removeView(b) } catch (e: Throwable) { }
        bubble = null
    }

    // ---------------------------------------------------------------- menu nổi

    fun togglePanel() {
        if (panel != null) closePanel() else openPanel()
    }

    /** Mở menu (dùng cho nút "Mở menu" trong app / thông báo, kể cả khi bóng đang tắt). */
    fun openPanel() {
        if (panel != null) return
        if (!Settings.canDrawOverlays(ctx)) return
        val m = dm()
        val sw = m.widthPixels
        val sh = m.heightPixels
        val land = sw > sh

        val root = FrameLayout(ctx)
        root.setBackgroundColor(0x99000000.toInt())
        root.setOnClickListener { closePanel() }

        val pw = if (land) min(sw - ui.dp(40), ui.dp(640)) else sw - ui.dp(16)
        val ph = if (land) min(sh - ui.dp(24), ui.dp(340)) else min((sh * 0.74f).toInt(), ui.dp(560))

        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.HORIZONTAL
        box.background = ui.round(Th.BG, 22, Th.ACC, 2)
        box.setPadding(ui.dp(6), ui.dp(6), ui.dp(6), ui.dp(6))
        box.isClickable = true

        // ----- sidebar
        sideIcons.clear()
        sideLabels.clear()
        val sideScroll = ScrollView(ctx)
        sideScroll.isVerticalScrollBarEnabled = false
        val side = LinearLayout(ctx)
        side.orientation = LinearLayout.VERTICAL
        side.gravity = Gravity.CENTER_HORIZONTAL
        side.setPadding(0, ui.dp(4), 0, ui.dp(4))
        val av = ImageView(ctx)
        av.setImageResource(R.drawable.hezpor_logo)
        av.scaleType = ImageView.ScaleType.CENTER_CROP
        av.clipToOutline = true
        av.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
        }
        val avLp = LinearLayout.LayoutParams(ui.dp(34), ui.dp(34))
        avLp.bottomMargin = ui.dp(6)
        side.addView(av, avLp)
        for (i in tabs.indices) {
            val item = LinearLayout(ctx)
            item.orientation = LinearLayout.VERTICAL
            item.gravity = Gravity.CENTER_HORIZONTAL
            item.setPadding(0, ui.dp(7), 0, ui.dp(7))
            val ic = TextView(ctx)
            ic.text = tabs[i].first
            ic.textSize = 20f
            ic.gravity = Gravity.CENTER
            val lb = TextView(ctx)
            lb.text = tabs[i].second
            lb.textSize = 10f
            lb.gravity = Gravity.CENTER
            item.addView(ic, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            item.addView(lb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            item.setOnClickListener { selectTab(i) }
            sideIcons.add(ic)
            sideLabels.add(lb)
            side.addView(item, LinearLayout.LayoutParams(ui.dp(66), ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        sideScroll.addView(side, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        box.addView(sideScroll, LinearLayout.LayoutParams(ui.dp(70), ViewGroup.LayoutParams.MATCH_PARENT))

        // ----- nội dung
        val sc = ScrollView(ctx)
        sc.isVerticalScrollBarEnabled = false
        sc.background = ui.round(Th.PANEL, 16)
        val inner = LinearLayout(ctx)
        inner.orientation = LinearLayout.VERTICAL
        inner.setPadding(ui.dp(14), ui.dp(12), ui.dp(14), ui.dp(16))
        sc.addView(inner, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val scLp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
        scLp.marginStart = ui.dp(6)
        box.addView(sc, scLp)

        root.addView(box, FrameLayout.LayoutParams(pw, ph, Gravity.CENTER))
        val hint = TextView(ctx)
        hint.text = "Chạm ra ngoài để thu lại  •  © Hezpor & Long Supra"
        hint.textSize = 10.5f
        hint.setTextColor(0xAAFFFFFF.toInt())
        hint.gravity = Gravity.CENTER
        root.addView(hint, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply { bottomMargin = ui.dp(10) })

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(root, lp)
        } catch (e: Throwable) {
            return
        }
        panel = root
        content = inner
        scroll = sc
        root.alpha = 0f
        root.animate().alpha(1f).setDuration(120).start()
        selectTab(tab)
    }

    fun closePanel() {
        val p = panel ?: return
        try { wm.removeView(p) } catch (e: Throwable) { }
        panel = null
        content = null
        scroll = null
    }

    private fun selectTab(i: Int) {
        if (i == tabs.size - 1) { closePanel(); return }
        tab = i
        for (k in sideIcons.indices) {
            val sel = k == i
            sideIcons[k].alpha = if (sel) 1f else 0.55f
            sideLabels[k].setTextColor(if (sel) Th.ACC else Th.DIM)
        }
        val c = content ?: return
        c.removeAllViews()
        when (i) {
            0 -> pagePerf(c)
            1 -> pageTools(c)
            2 -> pageImage(c)
            3 -> pageHud(c)
        }
        scroll?.scrollTo(0, 0)
    }

    // ---------------------------------------------------------------- trang 1: Hiệu suất

    private fun flowToggle(c: LinearLayout, title: String, sub: String, key: String) {
        val ref = arrayOfNulls<Switch>(1)
        ref[0] = ui.toggle(c, title, sub, key, false) { on ->
            if (on && !ShizukuHelper.granted()) {
                toast("Cần cấp quyền Shizuku (mở app Hezpor → Tổng quan)")
                ref[0]?.isChecked = false
            } else {
                work {
                    Actions.applyFlow(key, on)
                    null
                }
            }
        }
    }

    private fun pagePerf(c: LinearLayout) {
        ui.title(c, "Hiệu suất")

        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        val l1 = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        l1.marginEnd = ui.dp(6)
        ui.button(row, "🚀 Tăng tốc 1 chạm", true, 0, l1) {
            work(true) { Actions.boost(ctx) }
        }
        ui.button(row, "↩ Khôi phục", false, 0, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)) {
            work(true) { Actions.restoreAll(ctx) }
        }
        c.addView(row, ui.lp(10))

        flowToggle(c, "Hiệu năng tối đa", "Ép CPU/GPU xung cao (máy nóng hơn)", K.FL_PERF)
        flowToggle(c, "Giảm hoạt ảnh 0.5x", "Thao tác nhanh hơn", K.FL_ANIM)
        flowToggle(c, "Ép GPU render", "Tắt HW overlay, GPU dựng hình", K.FL_GPU)
        flowToggle(c, "Bỏ bóp xung nhiệt", "Nguy cơ nóng máy, cần tản nhiệt", K.FL_THERMAL)
        flowToggle(c, "Tạm dừng Camera / ghi màn hình", "Giải phóng RAM cho game", K.FL_CAM)

        val sup = Actions.supportedHz(ctx).ifEmpty { listOf(60, 90, 120) }
        val cur = Actions.currentHz(ctx)
        ui.text(c, "Tần số quét (hiện tại: $cur Hz)", 12f, Th.TXT, true, 14)
        val names = ArrayList<String>()
        for (hz in sup) names.add("$hz Hz")
        names.add("Tự động")
        ui.chips(c, names, sup.indexOf(cur)) { i ->
            if (i < sup.size) {
                val hz = sup[i]
                work(true) {
                    val ok = Actions.setHz(ctx, hz)
                    try { Thread.sleep(700) } catch (e: Throwable) { }
                    if (ok) "Đã ép $hz Hz" else "Cần quyền 'Ghi cài đặt hệ thống' hoặc Shizuku"
                }
            } else {
                work(true) {
                    val ok = Actions.autoHz(ctx)
                    try { Thread.sleep(700) } catch (e: Throwable) { }
                    if (ok) "Đã trả về tự động" else "Cần quyền 'Ghi cài đặt hệ thống' hoặc Shizuku"
                }
            }
        }
        ui.toggle(c, "Khóa Hz", "Tự ép lại nếu hệ thống đổi", K.HZ_LOCK, false)
    }

    // ---------------------------------------------------------------- trang 2: Công cụ

    private fun sysToggle(c: LinearLayout, title: String, sub: String?, key: String, table: String, setting: String) {
        val ref = arrayOfNulls<Switch>(1)
        ref[0] = ui.toggle(c, title, sub, key, false) { on ->
            io.execute {
                val ok = Actions.setSystem(ctx, table, setting, on)
                main.post {
                    if (!ok) {
                        toast("Cần quyền 'Ghi cài đặt hệ thống' hoặc Shizuku")
                        if (on) ref[0]?.isChecked = false
                    }
                }
            }
        }
    }

    private fun pageTools(c: LinearLayout) {
        ui.title(c, "Công cụ chơi")

        ui.slider(
            c, "Tốc độ con trỏ chuột", K.SPEED_VAL, -7f, 7f, 1f,
            Sys.getPointerSpeed(ctx).toFloat(), "%.0f"
        ) { v ->
            work {
                if (Sys.setPointerSpeed(ctx, v.roundToInt())) null
                else "Cần quyền 'Ghi cài đặt hệ thống' hoặc Shizuku"
            }
        }
        ui.toggle(c, "Khóa tốc độ chuột", "Dịch vụ nền tự đặt lại nếu bị đổi", K.SPEED_LOCK, false)

        ui.toggle(c, "Hz chuột nổi (HUD)", "Hiện Hz chuột trên mọi ứng dụng", K.HUD_ON, false)
        ui.toggle(c, "Đo Hz toàn hệ thống", "Đọc /dev/input qua Shizuku", K.SYS_HZ_ON, false)
        ui.toggle(c, "Văn bản nổi", null, K.TEXT_ON, false)
        ui.toggle(c, "🔒 Khóa văn bản", null, K.TEXT_LOCK, false)

        sysToggle(c, "Hiện điểm chạm", "Show touches", K.SHOW_TOUCH, "system", "show_touches")
        sysToggle(c, "Vị trí con trỏ / tọa độ", "Pointer location", K.POINTER_LOC, "system", "pointer_location")
        sysToggle(c, "Con trỏ chuột to", "Large pointer icon", K.BIG_POINTER, "secure", "accessibility_large_pointer_icon")

        ui.button(c, "Mở app Hezpor Mouse", false, 14) {
            closePanel()
            try {
                val i = Intent(ctx, MainActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
            } catch (e: Throwable) { }
        }
    }

    // ---------------------------------------------------------------- trang 3: Hình ảnh

    private fun pageImage(c: LinearLayout) {
        gfx.build(c, true)
        c.addView(View(ctx), ui.lp(18))
        ui.title(c, "Màn hình (toàn hệ thống)")
        ui.text(c, "Độ phân giải màn hình", 12f, Th.TXT, true, 10)

        val profiles = ResStore.load(ctx)
        val names = ArrayList<String>()
        names.add("Gốc")
        names.add("85%")
        names.add("75%")
        names.add("60%")
        for (p in profiles) names.add(p.name)
        ui.chips(c, names, -1) { i ->
            work {
                if (!ShizukuHelper.granted()) return@work "Cần cấp quyền Shizuku"
                if (i == 0) {
                    Actions.resetSize()
                    "Đã về độ phân giải gốc"
                } else if (i <= 3) {
                    val pct = intArrayOf(85, 75, 60)[i - 1]
                    val ph = Actions.physical() ?: return@work "Không đọc được độ phân giải gốc"
                    Actions.setSize((ph[0] * pct / 100 / 2) * 2, (ph[1] * pct / 100 / 2) * 2, ph[2] * pct / 100)
                    "Đã đặt $pct%"
                } else {
                    val p = profiles[i - 4]
                    Actions.setSize(p.w, p.h, p.d)
                    "Đã áp dụng " + p.name
                }
            }
        }

        ui.slider(
            c, "Độ rực màu %", K.HD_SAT, 50f, 200f, 5f, 100f, "%.0f"
        ) { v ->
            work {
                if (!ShizukuHelper.granted()) return@work "Cần cấp quyền Shizuku"
                DisplayCtl.saturation(v / 100f)
                null
            }
        }
        ui.button(c, "Đặt lại màu gốc", false, 10) {
            work(true) {
                if (!ShizukuHelper.granted()) return@work "Cần cấp quyền Shizuku"
                Prefs.setFloat(ctx, K.HD_SAT, 100f)
                DisplayCtl.saturation(1f)
                "Đã đặt lại màu gốc"
            }
        }
    }

    // ---------------------------------------------------------------- trang 4: HUD FPS

    private fun pageHud(c: LinearLayout) {
        ui.title(c, "HUD FPS")
        ui.toggle(c, "Hiện FPS", null, K.FPS_ON, false)
        ui.toggle(c, "🔒 Khóa chỉnh sửa", null, K.FPS_LOCK, true)
        val st = FpsStore.load(ctx)
        val panel = StylePanel(ctx)
        panel.build(c, st, 8, 48, { FpsStore.save(ctx, st) }, "Dòng") { box ->
            FpsUi.build(ctx, panel, box, {}) {
                Prefs.setInt(ctx, K.FPS_X, 0)
                Prefs.setInt(ctx, K.FPS_Y, 0)
            }
        }
    }

    // ---------------------------------------------------------------- vòng đời

    /** Xoay màn hình: đóng menu và dựng lại bóng theo kích thước mới. */
    fun onConfigChanged() {
        closePanel()
        bubSig = ""
        sync()
    }

    fun destroy() {
        closePanel()
        removeBubble()
        bubSig = ""
        gfx.shutdown()
        try { io.shutdownNow() } catch (e: Throwable) { }
    }
}
