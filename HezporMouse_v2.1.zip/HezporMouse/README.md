# Hezpor Mouse
App Android: đo Hz chuột (trong app + toàn hệ thống qua Shizuku), chỉnh/khóa tốc độ con trỏ,
HUD Hz/FPS nổi, Optimizer, đổi độ phân giải/màu, **bóng nổi + menu nhanh trên mọi app**, video nền có âm thanh.

Giao diện chia tab: Tổng quan • Hiệu suất • Chuột • Hình ảnh • HUD • Ghi chú.

Bóng nổi: bật ở tab Tổng quan (cần quyền Lớp phủ). Chạm bóng để mở menu, kéo để di chuyển.
Menu nhanh: Hiệu suất (Tăng tốc 1 chạm, Optimizer, Hz) • Công cụ (tốc độ chuột, HUD, điểm chạm) •
Hình ảnh (phân giải, độ rực màu) • HUD FPS.

Build: đẩy lên GitHub (nhánh main) -> tab Actions -> "Build APK" -> tải ở Releases hoặc Artifacts.

## Thay đổi v2.1 – NMD Panel (tab Chuột)
- Thêm thẻ **NMD PANEL – Raw First Mouse Optimizer** theo ảnh: pipeline RAW → EMA → CURVE → OUTPUT → SNAP.
- **Adaptive EMA**: Velocity Window, Base Alpha (Slow), Fast Alpha (Fast).
- **Response Curve (Natural)**: Curve Strength, Input Offset, Output Cap + đồ thị có chấm vận tốc hiện tại.
- **Device Calibration**: DPI (400–3200), Report Rate đo trực tiếp, Jitter/After (ms), Driver; preset **RAW BYPASS / CONTROL / TRACKING / AGGRESSIVE**.
- **Micro Protection** (ngưỡng counts), **Line Stabilized Snap** (Quantized 8/16, Dir Smoothing, Threshold °, Strength).
- **Live Monitor**: Raw, Output, Disp. Vel, EMA Alpha, Curve Gain, Snap State, PPS In/Out/Drop.
- **Ngoài app**: công tắc "Đường cong NMD lên tốc độ chuột TOÀN HỆ THỐNG" – dịch vụ nền đọc getevent (Shizuku) và đổi tốc độ con trỏ theo vận tốc thật.
  Snap và Jitter chỉ chạy trong khung test (Android không cho app sửa từng điểm di chuyển của chuột nếu không root).

## Thay đổi v2.0 (Peak)
- **Logo mới** (adaptive icon neon: lục giác + chuột + tia sét) dùng cho icon app, bóng nổi, menu nổi và tiêu đề. Bóng nổi bật mặc định (cần quyền Lớp phủ).
- **Tổng quan** làm lại kiểu Gaming: thẻ hero có logo động, ô trạng thái (Hz • Shizuku • Dịch vụ), nút nhanh Tăng tốc / Khôi phục / Mở menu / Bật-tắt FPS.
- **HD Game → RENDERING GRAPHICS** (tab Hình ảnh và menu nổi): bật **ANGLE** cho máy hỗ trợ, chế độ **Low Texture / Low Pixel**, độ phân giải render (Gốc → 30%), chọn game hoặc lấy game đang mở.
- **Tùy biến sâu**: driver Mặc định / ANGLE / Native cho từng game, Game Mode (Chuẩn / Hiệu năng / Pin), giới hạn FPS, ANGLE cho mọi app, mở lại game, trả game về mặc định. Cần Shizuku; hạ độ phân giải theo game cần Android 12+.
- Bản quyền: © Hezpor & Long Supra.

## Thay đổi v1.4 (gồm v1.2, v1.3)
- Giao diện gọn hơn, bỏ bớt chữ thừa. Bảng chỉnh có tab: Dòng • Chữ • Màu • Hiệu ứng • Nền (dùng chung cho FPS, văn bản, trong app và trên màn hình).
- Thêm tinh chỉnh: đậm/nghiêng/mono, giãn chữ, độ mờ, xoay, phát sáng, màu nền, bo góc, viền, xếp ngang, đổi màu theo FPS, vị trí X/Y.

## Thay đổi v1.3 (gồm v1.2)
- Giao diện Gaming xanh dương neon; FPS chỉ hiện chữ "FPS" + số (bỏ chữ PC / Real).
- Đã bỏ chức năng **HD Game**.
- **FPS nổi** kiểu PC: 2 dòng `FPS PC` + `FPS Real`, dính sát góc dưới trái màn hình.
- FPS và Văn bản nổi đều có: chỉnh cỡ / màu / nền, **hiệu ứng** (Neon, Cầu vồng, Nhịp, Nháy, Chuyển màu) + tốc độ,
  **chỉnh trực tiếp trên màn hình** (chạm vào khi chưa khóa) và nút **🔒 KHÓA chỉnh sửa**.

---
© 2026 Hezpor & Long Supra. Bản quyền thuộc Hezpor & Long Supra. Mọi quyền được bảo lưu.
